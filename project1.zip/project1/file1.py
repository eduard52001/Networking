from bs4 import BeautifulSoup
import requests


url = 'https://www.marketscreener.com/search/?q=ros+agro+plc+agro'

page = requests.get(url, verify=False)

with open('res.txt', 'wb') as f:
    f.write(page.content)