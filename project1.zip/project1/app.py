from flask import Flask
from flask import request
from flask import render_template
from parse_search import get_search_response, get_financials

app = Flask(__name__, template_folder='templates',
            static_folder='templates/search/MS_files',
            static_url_path='')
app.config['EXPLAIN_TEMPLATE_LOADING'] = True


@app.route("/", methods=['GET', 'POST'])
def start_page():
    if request.method == 'POST':
        search_request = request.form['query']
        search_results = get_search_response(search_request)
        return render_template('/search/search_results_template.html', search_results=search_results)
    return render_template('/search/base.html')


@app.route("/quote/stock/<ticker>/")
def financials(ticker):
    tables = get_financials(ticker)
    return render_template('/search/financials.html', tables=tables)


if __name__ == '__main__':
    app.run()
