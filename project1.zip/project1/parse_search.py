from bs4 import BeautifulSoup
import requests


def get_search_response(search_query):
    url = 'https://www.marketscreener.com/search/?q={}'.format(search_query)
    page = requests.get(url, verify=False)
    soup = BeautifulSoup(page.content, 'html.parser')
    search_results = soup.find('table', {'class': 'table--medium'})
    return search_results


def _unhide_cols(html, prop, replace_with):
    soup = BeautifulSoup(html, 'html.parser')
    for tag in soup.find_all('td', attrs={'class': 'bc2Y'}):
        if tag[prop].contains('hidden'):
            new_tag = tag[prop].replace(';display:none', replace_with)
            tag.replace_with(new_tag)
    return soup.contents


def get_financials(ticker):
    url = 'https://www.marketscreener.com/quote/stock/{}/financials/'.format(ticker)
    page = requests.get(url, verify=False)
    soup = BeautifulSoup(page.content, 'html.parser')
    search_results = soup.find(attrs={'id': 'siteCentre'})
    return search_results

