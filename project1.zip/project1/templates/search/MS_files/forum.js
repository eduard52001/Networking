 
function postAscExec(type)
{

	if (type==1)
	{
	  window.document.getElementById("iAscPost0").style.display="none";
	  window.document.getElementById("iAscPost1").style.display="block";
	  window.document.getElementById("AscPostMod").style.display="block"; 
	  window.document.getElementById("iAscPost2").style.display="none";
	  window.document.getElementById("sub_title").style.display="inline";
	  window.document.getElementById("AC_codezb").value="GE"; 
	  window.document.getElementById("is_owner").style.display="none";
	  window.document.getElementById("show_zone_more_option").style.display="none";
	  
	}
	else if (type==2)
	{
	  window.document.getElementById("iAscPost0").style.display="none";
	  window.document.getElementById("iAscPost1").style.display="none";
	  window.document.getElementById("sub_title").style.display="none";
	  window.document.getElementById("iAscPost2").style.display="inline";
	  window.document.getElementById("is_owner").style.display="block";
	  window.document.getElementById("show_zone_more_option").style.display="block";
	  
	}
}


$( document ).ready(function() {

       $(document).on( "click",".delete_img_post", function() 
       { 
            $(this).closest('form').find('.zone_more_option_image').hide();
            $(this).closest('form').find('.remove_img').val('1');
            $(this).closest('form').find('input[type="file"]').val('');
       });   

       $(document).on( "mouseenter",".to_blue", function() 
       { 
            $(this).attr('src',$(this).attr('src').replace("_gris", "_bleu"));
       });  
       $(document).on( "mouseleave",".to_blue", function() 
       { 
            $(this).attr('src',$(this).attr('src').replace("_bleu", "_gris"));
       }); 
       
       if ($("a.single_image").length)
       $("a.single_image").fancybox();        

       ////////////////////////POST//////////////////////////////////////////////////////////////
 
       $(document).on( "click",".update_post", function() 
       {
			$('.zone_more_option_member').hide();
			if($("#notification").length)
			{
				//INITIALISATION FORMULAIRE
				init_form($(this).closest('.notification'));
				
				
				element = $(this);
				xhr = $.ajax({
                      url: "/mods_a/forum/ajax_forum_action.php",
                      type        : 'POST',
                      dataType    : 'html',
                      data        : 'ajax=1&action=updateInfo&id=' + element.closest('.forum_message').attr('data-id-message'),

                      success : function(code_html, statut){ 
 
						var obj = jQuery.parseJSON(code_html);
					 
					  
						element.closest('.notification').find('input[name=id_message]').val(element.closest('.forum_message').attr('data-id-message'));
						element.closest('.notification').find('.txt_error').hide();
						element.closest('.notification').find('.txt_success').hide();
						element.closest('.notification').find('textarea[name="content"]').val(obj.message_corps);
						element.closest('.notification').find('.loader').hide();
						element.closest('.notification').find('input[type="file"]').val('');
						
						element.closest('.notification').find('.post').html('Modifier');
						
						if(obj.message_opinion!='not_set' && obj.message_opinion!='')
						{
							element.closest('.notification').find('.post_zone_opinion').show();
							element.closest('.notification').find('select[name="opinion"]').val(obj.message_opinion);
							element.closest('.notification').find('input[name="objectif"]').val(obj.message_objectif);
							element.closest('.notification').find('input[name="stop"]').val(obj.message_stop);	
						}
						
						if(obj.message_graf!='')
						{
							element.closest('.notification').find('.zone_more_option_image').show();
							element.closest('.notification').find('.label_image').attr('src','https://www.zonebourse.com/'+obj.message_graf);
						}
						if(obj.message_is_owner=="1")
							element.closest('.notification').find('input[name="is_owner"]').prop( "checked", true );
						else
							element.closest('.notification').find('input[name="is_owner"]').prop( "checked", false );
						
						
                      }
				});
			}
			 
            
       }); 
	   
	   
	   function init_form(formulaire)
	   {
			formulaire.find('.label_image').attr('src','');
		    formulaire.find('.post').html('publier');
			formulaire.find('input[name=id_message]').val("0");
			formulaire.find('.txt_error').hide();
			formulaire.find('.txt_success').hide();
			formulaire.find('textarea[name="content"]').val('');
			formulaire.find('.loader').hide();
			formulaire.find('input[type="file"]').val('');
			formulaire.find('select[name="opinion"]').val('');
			formulaire.find('input[name="objectif"]').val('');
			formulaire.find('input[name="stop"]').val('');	
			formulaire.find('.post_zone_opinion').hide();
			formulaire.find('.zone_more_option_image').hide();
			formulaire.find('input[name="is_owner"]').prop( "checked", false );
	   }
	   
       $(document).on( "click",".post_submit", function() 
       {   
            post($(this),'post');    
       }); 
       
       
       
       $(document).on( "mouseleave",".reco_user", function() 
       {   
            $('.reco_user').hide(); 
       }); 
       $(document).on( "mouseleave",".forum_message", function() 
       {   
            $('.reco_user').hide(); 
       }); 
       
       //MESSAGE USER
       $(document).on( "mouseenter",".action_reco_txt", function() 
       {   
            show_message_user_note($(this),'like');    
       }); 
       $(document).on( "mouseenter",".action_dereco_txt", function() 
       {   
            show_message_user_note($(this),'dislike');    
       });
       
	   //CART MEMBER
	   $(document).on( "mouseover",".show_info_member", function() 
       {  
			$('.user_info').hide();
			showCartMember($(this));    
       });  
	   $(document).on( "mouseleave",".user_info", function() 
       {  
            $('.user_info').hide();
       }); 
	   $(document).on( "mouseleave",".notification", function() 
       {  
            $('.user_info').hide();
       });
	   
	   
	    var xhr2;
       function showCartMember(element)
       {
		   var element2 = element.closest('td').find('.user_info');
 
		   if(element2.html()=='')
		   {
				element2.hide(); 
				var formData = new FormData();
				formData.append("ajax", '1');
				formData.append("action", 'getMemberCart'); 
				formData.append("id", element.attr('data-id')); 
				
				if(xhr2 && xhr2.readyState != 4){
					xhr2.abort();
				}
			
				xhr2 = $.ajax({
						  url: "/mods_a/forum/ajax_forum_action.php",
						  type        : 'POST',
						  dataType    : 'html',
						  data        : formData,
						  processData: false,
						  contentType: false,
						  success : function(code_html, statut){ 
							if(code_html!='')
							{
								element2.show();
								element2.html(code_html);
							}
						  }
				}); 
		   }
		   else
		   {
				element2.show();    
		   }
            
       }
	   
	   
       var xhr;
       function show_message_user_note(element,action)
       {
            $('.reco_user').hide(); 
            var formData = new FormData();
            formData.append("ajax", '1');
            formData.append("action", 'get_message_user_note'); 
            formData.append("recommandation", action); 
            formData.append("id_message", element.closest('.forum_message').attr('data-id-message'));
            
            if(xhr && xhr.readyState != 4){
                xhr.abort();
            }
        
            xhr = $.ajax({
                      url: "/mods_a/forum/ajax_forum_action.php",
                      type        : 'POST',
                      dataType    : 'html',
                      data        : formData,
                      processData: false,
                      contentType: false,
                      success : function(code_html, statut){ 
                        if(code_html=='')
                        {
                            element.closest('div').find('.reco_user').hide();
                            
                        }
                        else
                        {   
                            element.closest('div').find('.reco_user').show();
                            element.closest('div').find('.reco_user').html(code_html); 
                        }
                        
                      }
            });
       }


 
 
       function post(element,action)
       {
           
            $('tr[class="form"]').remove();
            
            var form_context = $('#context').get(0);
            if (element.closest('.forum_message').find('#context_message').length )
                var form_context = element.closest('.forum_message').find('#context_message').get(0);
                
                 
            var form = element.closest('form').get(0);
            
            var formData_context = new FormData(form);
            var formData = jQuery(form_context).serializeArray();
            
            for (var i=0; i<formData.length; i++)
                formData_context.append(formData[i].name, formData[i].value);

            formData_context.append("ajax", '1');
            formData_context.append("action", action); 
            
            
            element.hide();
            element.closest('form').find('.loader').show();
            element.closest('form').find('.txt_success').hide();
            element.closest('form').find('.txt_error').hide();
            $('.txt_success').hide();
       
            var hide_after_post = $('#context').find('input[name="hide_after_post"]').val();
            
            /*ERROR*/
            var error = false; 
            $(this).closest('form').find('textarea[name="content"]').css('border','1px solid silver');
            if($.trim(element.closest('form').find('textarea[name="content"]').val())=='')
            {
                element.closest('form').find('textarea[name="content"]').css('border','1px solid red');
                error = true;
            }
            if(element.closest('form').find('input[name="title"]').length)
            {
                element.closest('form').find('input[name="title"]').css('border','1px solid silver');
                if($.trim(element.closest('form').find('input[name="title"]').val())=='')
                {
                    element.closest('form').find('input[name="title"]').css('border','1px solid red');
                    error = true;
                }
            }
            if(error)
            { 
                element.closest('form').find('.loader').hide();
                element.closest('form').find('.post_submit').show();  
               
                return;
            }
            
            var request = $.ajax({
                  url: "/mods_a/forum/ajax_forum_action.php",
                  type        : 'POST',
                  dataType    : 'html',
                  data        : formData_context,
                  processData: false,
                  contentType: false,
                  success : function(code_html, statut){
						location.reload(true);
                    }
                  
            }); 
       }
	   
	   
	    
	   

       $(document).on( "click",".show_zone_more_option", function() 
       {  
           if($(this).closest('form').find('.post_zone_opinion').is(":visible"))
                $(this).closest('form').find('.post_zone_opinion').hide();
           else
               $(this).closest('form').find('.post_zone_opinion').show();
       });  
       
       //AFFICHE NOM FICHIER
       $(document).on( "change",".file-input", function() 
       { 
            element = $(this);
            input = element[0].files[0];
            
            element.closest('table').find('.zone_more_option_image').find('.txt_error').hide();
            element.closest('table').find('.zone_more_option_image').show(); 
        
            if(input.size>=1000000)
            {
                element.closest('table').find('.prev_img').hide(); 
                element.closest('table').find('.zone_more_option_image').find('.txt_error').show();   
            }
            else
            {
                element.closest('table').find('.prev_img').show(); 
                element.closest('table').find('.zone_more_option_image').find('.txt_error').hide();
                
                var reader = new FileReader();
                reader.onload = function(e) {
                    element.closest('table').find('.label_image').attr('src', e.target.result);
                }
                reader.readAsDataURL(input);
            }
       });   
       
       $(document).on( "click",".more_option_member", function() 
       {  
            var id = $(this).closest('.forum_message').attr('data-id-message');
            var element = $(this);
            var request = $.ajax({
                  url: "/mods_a/forum/ajax_forum_action.php",
                  type        : 'POST',
                  dataType    : 'html',
                  data        : 'ajax=1&action=get_action&id='+id,
                  success : function(code_html, statut){ 
                    element.closest('td').find('.zone_more_option_member').html(code_html);
                  }
            });
           if(element.closest('td').find('.zone_more_option_member').is(":visible"))
                element.closest('td').find('.zone_more_option_member').hide();
           else
                element.closest('td').find('.zone_more_option_member').show();
              
       }); 
        
       
       //SHOW FORUM
       $(document).on( "click",".btn_forum", function() 
       {  
            $('.btn_forum').removeClass('btn_forum_active');
            $(this).addClass('btn_forum_active');
            $('#notification').html('<img width="100" src="http://test.zonebourse.com/images/loading_100.gif" style="margin:auto;display:block;"   alt="loader" >');
            var request = $.ajax({
                  url: "/mods_a/forum/ajax_forum_action.php",
                  type        : 'POST',
                  dataType    : 'html',
                  data        : 'ajax=1&action=show_forum&forum='+$(this).attr('data-forum'),
                  success : function(code_html, statut){ 
                    $('#notification').html(code_html);
                  }
            }); 
       });
       
       //ACTION RECOMMANDER LIKE
       $(document).on( "click",".action_reco", function() 
       {  
            action_reco_dereco($(this),'action_reco');
       });
       //ACTION RECOMMANDER DISLIKE
       $(document).on( "click",".action_dereco", function() 
       {  
            action_reco_dereco($(this),'action_dereco');
       });
       
       function action_reco_dereco(element,type_action)
       {
            var id_message = element.closest('.forum_message').attr('data-id-message');
            var element_action_reco_txt = element.closest('.forum_message').find('.action_reco_txt').first();
            var element_action_dereco_txt = element.closest('.forum_message').find('.action_dereco_txt').first();
            var element_action_reco = element.closest('.forum_message').find('.action_reco').first();
            var element_action_dereco = element.closest('.forum_message').find('.action_dereco').first();

            var request = $.ajax({
                  url: "/mods_a/forum/ajax_forum_action.php",
                  type        : 'POST',
                  dataType    : 'JSON',
                  data        : 'ajax=1&action=' + type_action + '&id_message='+id_message,
                  success : function(code_html, statut){ 
                      if(code_html.nbreco>0)
                        element_action_reco_txt.html(code_html.nbreco);
                      else
                        element_action_reco_txt.html('&nbsp;&nbsp;');
                      if(code_html.nb_dislike>0)
                        element_action_dereco_txt.html(code_html.nb_dislike);
                      else
                        element_action_dereco_txt.html('&nbsp;&nbsp;');
                  }
            }); 
       }
       
       //SUPRRESION POST
       $(document).on( "click",".delete_post", function() 
       {  
			var myElement = $(this);
			var formData_context = new FormData();
			formData_context.append("ajax", '1');
			formData_context.append("action", 'action_delete_post'); 
			formData_context.append("id_message", $(this).attr('data-id'));
			
			 
			var request = $.ajax({
				  url: "/mods_a/forum/ajax_forum_action.php",
				  type        : 'POST',
				  dataType    : 'html',
				  data        : formData_context,
				  processData: false,
				  contentType: false,
				  success : function(returnCode, statut){ 
					
					var obj = jQuery.parseJSON(returnCode);
					if(obj.bMain)
					{
						myElement.closest('.notification').remove();
					}
					else
					{
						myElement.closest('table').remove();
					}
					
				  }
			}); 
       });
       
       
        
});
 
