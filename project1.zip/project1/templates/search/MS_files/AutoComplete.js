function AutoComplete (myAddID,myObjectName,sGetParam)
{
    sGetParam = typeof sGetParam !== 'undefined' ? sGetParam : null;  


this.LoadHisto = function() {
 this.AC_iSel=-1;
 this.AC_http.open("GET", this.AC_url + "__myhisto__", true);
 this.AC_http.onreadystatechange = this.handleHttpRespAC;
 this.AC_http.send(null);       
}

this.ACblur = function() {
   
    if (this.bPlay)
  window.document.getElementById("AC_Result"+this.addID).innerHTML = "";
  
/*  if(this.addID == "_derives" && !document.getElementById("sj_codezb").value)
  {
    debugger;
    window.document.getElementById("autocomplete"+this.addID).style.color = "#a9a9a9";
  }  */
}

this.ACPause = function() {
  this.bPlay = false;
  var tRes;   
  if ((tRes=document.getElementById("AC_tRes"+this.addID)))
  {
   if (this.AC_iSel>=0&&tRes.childNodes[this.AC_iSel])
   {
    tRes.childNodes[this.AC_iSel].className="";
    this.AC_iSel=-1;  
   }
  }
}
this.ACPlay = function() {
  this.bPlay = true;
}
this.ACmouseOver = function(line)
{
 if (!this.AC_http||document.getElementById("type_recherche"+this.addID).value!=0) {
  return;
 }
 var tRes;   
 if ((tRes=document.getElementById("AC_tRes"+this.addID)))
 {
  if (line>=0&&this.AC_iSel>=0&&tRes.childNodes[this.AC_iSel])
   tRes.childNodes[this.AC_iSel].className="";
  if (line>=0&&this.AC_iSel<=tRes.childNodes.length)
  {
   this.AC_iSel=line;
   tRes.childNodes[this.AC_iSel].className="AC_liOn";
  }
 }  
}
this.ACmouseDown = function(line)
{         
 if (!this.AC_http||document.getElementById("type_recherche"+this.addID).value!=0) {   
  return;
 }
 var tRes;   
 if ((tRes=document.getElementById("AC_tRes"+this.addID)))
 { 
  if (this.AC_iSel>=0&&tRes.childNodes[this.AC_iSel])
  {
   if (tRes.childNodes[this.AC_iSel].childNodes.length)
   {
    if (this.objectName=="myAC_pv")
    {
     document.getElementById("autocomplete_pv").value=tRes.childNodes[this.AC_iSel].childNodes[2].innerHTML.replace("<b>","").replace("</b>","").replace("<B>","").replace("</B>","");
     setValeurOrdre(tRes.childNodes[this.AC_iSel].childNodes[0].innerHTML,tRes.childNodes[this.AC_iSel].childNodes[2].innerHTML,tRes.childNodes[this.AC_iSel].childNodes[5].innerHTML);
    }
    else if (this.objectName=="myAC_liste")
    {
     myMaListe.action("add", tRes.childNodes[this.AC_iSel].childNodes[0].innerHTML);
     myMaListe.hideMsg();
    }
    else if (this.objectName=="myAC_derives")
    {
        var sj_name = tRes.childNodes[this.AC_iSel].childNodes[2].innerHTML.replace("<b>","").replace("</b>","").replace("<B>","").replace("</B>",""); 
        var sj_codeZB = tRes.childNodes[this.AC_iSel].childNodes[0].innerHTML;
        document.getElementById("autocomplete"+this.addID).value = sj_name.toUpperCase(); 
        document.getElementById("sj_codezb").value = sj_codeZB; 
        document.getElementById("autocomplete"+this.addID).style.color = "#262626";        
    }     
    else if (this.objectName=="GraDynSearch")
    {
     loadGrafDyna(tRes.childNodes[this.AC_iSel].childNodes[0].innerHTML);
    }      
    else if (this.objectName=="myAC_Chart")
    {
        var codeZB = tRes.childNodes[this.AC_iSel].childNodes[0].innerHTML.split('/');           
        codeZB = codeZB[3].split('-').pop();
        var name = tRes.childNodes[this.AC_iSel].childNodes[2].innerHTML;
        
        clickOnResult([codeZB,name]);    
    }
    else if (this.objectName=="myAC_post")
    {
     document.getElementById("autocomplete_post").value=tRes.childNodes[this.AC_iSel].childNodes[2].innerHTML.replace("<b>","").replace("</b>","").replace("<B>","").replace("</B>","");
     document.getElementById("AC_Result_name").innerHTML = document.getElementById("autocomplete_post").value;
     document.getElementById("AC_codezb").value = tRes.childNodes[this.AC_iSel].childNodes[0].innerHTML;
     postAscExec(2);
    }
    else if (this.objectName=="myAC_currency_from"||this.objectName=="myAC_currency_to")  
    {   
        document.getElementById("autocomplete"+this.addID).value=tRes.childNodes[this.AC_iSel].childNodes[1].innerHTML.replace("<b>","").replace("</b>","").replace("<B>","").replace("</B>","")+" ("+tRes.childNodes[this.AC_iSel].childNodes[2].innerHTML+")";
        this.ACblur(); 
		document.getElementById("change").value=1;
		$("#change").trigger("change"); 
		
        
    }
    else if (this.objectName=="myAC_currency_table")  
    {  
        document.getElementById("autocomplete"+this.addID).value=tRes.childNodes[this.AC_iSel].childNodes[1].innerHTML.replace("<b>","").replace("</b>","").replace("<B>","").replace("</B>","")+" ("+tRes.childNodes[this.AC_iSel].childNodes[2].innerHTML+")";
        this.ACblur();
        $( "#forexButtonflag" ).val('open');    
        $("#changeforex").val(tRes.childNodes[this.AC_iSel].childNodes[2].innerHTML);
        $("#changeforex").trigger("change");
        $("#change").trigger("change");  
    }
    else
    {
     var reg=new RegExp("(&amp;)", "g");
     window.location=tRes.childNodes[this.AC_iSel].childNodes[0].innerHTML.replace(reg,"&");
    }
   }
  }  
 }  
}
this.ACkeyUp = function(evenement) {
 var rechRapide = document.getElementById("autocomplete"+this.addID).value;
 
 if(rechRapide == ""){
  this.ACblur();
  return;
 }
 if (!this.AC_http||document.getElementById("type_recherche"+this.addID).value!=0||rechRapide=="Code, Libell� ou mots cl�s"||rechRapide=="Code ou Libell�") {   
  return;
 }
 
  var touche = window.event ? evenement.keyCode : evenement.which;
  var tRes;
  if (touche==13&&this.AC_iSel==-1&&(this.objectName!="myAC_Chart")&&(this.objectName!="myAC_recherche"))
  {
   document.getElementById("recherche_menu"+this.addID).submit();//document.recherche_menu.submit();
  }
  if ((touche>=48&&touche<=57)||(touche>=65&&touche<=105)||touche==8||touche==32||(touche==1&&(this.objectName=="myAC_currency_table"||this.objectName=="myAC_currency_from"||this.objectName=="myAC_currency_to"))||(touche==0&&(this.objectName=="myAC_currency_table"||this.objectName=="myAC_currency_from"||this.objectName=="myAC_currency_to"))||(!touche&&(this.objectName=="myAC_currency_table"||this.objectName=="myAC_currency_from"||this.objectName=="myAC_currency_to")))
  {
   this.AC_iSel=-1;
   this.AC_http.open("GET", this.AC_url + escape(rechRapide), true);   
   this.AC_http.onreadystatechange = this.handleHttpRespAC;
   this.AC_http.send(null);   
  }
  else if (touche==13)  //enter
  {
   if ((tRes=document.getElementById("AC_tRes"+this.addID)))
   {                            
    if (this.AC_iSel>=0&&tRes.childNodes[this.AC_iSel])
    {
      if (tRes.childNodes[this.AC_iSel].childNodes.length)
      {
       if (this.objectName=="myAC_pv")
       {
            setValeurOrdre(tRes.childNodes[this.AC_iSel].childNodes[0].innerHTML,tRes.childNodes[this.AC_iSel].childNodes[1].innerHTML,tRes.childNodes[this.AC_iSel].childNodes[4].innerHTML);
       }
       else if (this.objectName=="myAC_liste")
       {
            setValeurOrdre(tRes.childNodes[this.AC_iSel].childNodes[0].innerHTML,tRes.childNodes[this.AC_iSel].childNodes[1].innerHTML,tRes.childNodes[this.AC_iSel].childNodes[4].innerHTML);
       }  
       else if (this.objectName=="myAC_Chart")
       {                            
            var codeZB = tRes.childNodes[this.AC_iSel].childNodes[0].innerHTML.split('/');
            codeZB =  codeZB[3].split('-').pop();
            var name = tRes.childNodes[this.AC_iSel].childNodes[2].innerHTML;
            
            clickOnResult([codeZB,name]);    
       }            
       else if (this.objectName=="myAC_post")
       {
        document.getElementById("autocomplete_post").value=tRes.childNodes[this.AC_iSel].childNodes[1].innerHTML.replace("<b>","").replace("</b>","").replace("<B>","").replace("</B>","");
        document.getElementById("AC_Result_name").innerHTML = document.getElementById("autocomplete_post").value;
        document.getElementById("AC_codezb").value = tRes.childNodes[this.AC_iSel].childNodes[0].innerHTML;
        postAscExec(2);
       }
       else if (this.objectName=="myAC_currency_from"||this.objectName=="myAC_currency_to"||this.objectName=="myAC_currency_table")
       {
        document.getElementById("autocomplete"+this.addID).value=tRes.childNodes[this.AC_iSel].childNodes[1].innerHTML.replace("<b>","").replace("</b>","").replace("<B>","").replace("</B>","")+" ("+tRes.childNodes[this.AC_iSel].childNodes[2].innerHTML+")";
        this.ACblur();
        myForex.Exec(0,1);
       }
       else
       {
         var reg=new RegExp("(&amp;)", "g");
         window.location=tRes.childNodes[this.AC_iSel].childNodes[0].innerHTML.replace(reg,"&");
       }
      }   
    }
   }
  }
  else if (touche==40||touche==38)
  {
   if ((tRes=document.getElementById("AC_tRes"+this.addID)))
   {
    if (this.AC_iSel>=0&&tRes.childNodes[this.AC_iSel])
     tRes.childNodes[this.AC_iSel].className="";
    // bas
    if (touche==40) {
     this.AC_iSel++;
     if (this.AC_iSel>=tRes.childNodes.length)
      this.AC_iSel=0;
    }
    // haut
    if (touche==38) {
     this.AC_iSel--;
     if (this.AC_iSel<0)
      this.AC_iSel=tRes.childNodes.length-1;
    }    
    tRes.childNodes[this.AC_iSel].className="AC_liOn";
   }
  }
}           
this.ACkeyDown = function(evenement) {  
    var touche = window.event ? evenement.keyCode : evenement.which;
 if (!this.AC_http||document.getElementById("type_recherche"+this.addID).value!=0) {
  return touche;
 }
 var rechRapide = document.getElementById("autocomplete"+this.addID).value;  
 if (rechRapide == "Rechercher action, indice, devise, news, membre ...")
  rechRapide = document.getElementById("autocomplete"+this.addID).value=""; 
 if (touche == 13) {
 return false;
 } else {
 return touche;
 }
}        
this.handleHttpRespAC = function() {
  if (_this.AC_http.readyState == 4) {
    sAffiche = "";    
    sResp = _this.AC_http.responseText;  
    window.document.getElementById("AC_Result"+_this.addID).innerHTML = sResp; 
//    debugger; 
  }
}
this.ACgetHTTPObject = function() {
  var xmlhttp;

  if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
    try {
      xmlhttp = new XMLHttpRequest();
      } catch (e) {
      xmlhttp = false;
      }
  }
  else {
   xmlhttp = false;
  }
  return xmlhttp;
}

  if (myObjectName=="GlobalSearchMV")
  {
   if (typeof window.document.getElementById("trader_auth") != "undefined")
    authcode=window.document.getElementById("trader_auth").value;
   if (typeof window.document.getElementById("trader_key") != "undefined")
    keycode=window.document.getElementById("trader_key").value;
   sGetParam = typeof sGetParam !== 'undefined' ? sGetParam : null;  
   this.AC_url = "http://mvpro.4-traders.com/mods_a/search/findRapidSearch.php?objectName="+myObjectName+"&addID="+myAddID+"&auth="+authcode+"&key="+keycode;
  }
  else
  {

    if (document.getElementById("aComposeInputSearch")) {
        this.AC_url = "/mods_a/search/findRapidSearch.php?objectName="+myObjectName+"&addID="+myAddID+"&aComposeInputSearch="+ document.getElementById("aComposeInputSearch").value;
    } else {
        this.AC_url = "/mods_a/search/findRapidSearch.php?objectName="+myObjectName+"&addID="+myAddID;
    }  
  }
 
  if(sGetParam != "")
     this.AC_url = this.AC_url+"&"+sGetParam;
  this.AC_url = this.AC_url+"&company_name=";       
  this.AC_http = this.ACgetHTTPObject();
  this.AC_iSel = -1;
  this.bPlay = true;
  this.addID = myAddID;
  this.objectName = myObjectName;  
  var _this=this;
}