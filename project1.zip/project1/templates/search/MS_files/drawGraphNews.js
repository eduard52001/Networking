if(!configured)
{
    throw new Error('/js/utf-8/configGraph.js is not imported'); 
}

var aDataQuote = [];
var aDataDisplayed = [];
var maxBound = 0;
var minBound = 0;

function sortByX(a,b){
    if (a.x < b.x)
        return -1;
    else if (a.x > b.x)
        return 1;
        else return 0;
} 

function loadMoreNews(codeZB,inDiv,sFilter)
{
	var type="news"; 
	if(sFilter=="dividendes")
		type="dividendes"; 
		
    $("#moreNewsButton").prop('disabled', true);
    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        cache: false,
        context : document.body,
        async : true,
        data : {codeZB : codeZB, type : type, sFilter : sFilter},
        type : 'GET',
        
        success : function(data){    
            handleDataNews(data,inDiv,sFilter);
        }});
}

function loadNewsFromDate(codeZB,fromDate,inDiv)
{
	
    $("#moreNewsButton").prop('disabled', true);
    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        cache: false,
        context : document.body,
        async : true,
        data : {codeZB : codeZB, type : "news", datemin: fromDate},
        type : 'GET',
        success : function(data){
            handleDataNews(data,inDiv);
        }});
}

function handleDataNews(data,inDiv,sFilter)
{         
	sFilter = (typeof sFilter === "undefined") ? "" : sFilter;
	
    var aNews;
    try{
        aNews = JSON.parse(data);
    } 
    catch(e){      
        console.log(e);
        console.log(data);
        return;
    }

    var chart =  $("#"+inDiv+"").highcharts();
 
    var aValidSource = [];

    if(sFilter=="")
    {
        if(aNews.length>200)
            aValidSource = ((window.location.host).indexOf("zonebourse")>=0) ? ["dow_jones","reuters","reuters_pro","zonebourse","cercle","awp","dpa_afx","zonebourse_dpa","mtnewswires","mtnewswires_zonebourse","capital_iq"] : ["dow_jones","reuters","reuters_pro","zonebourse","noodls","prnewswire","businesswire","globenewswire","companynews","fxcm","marketwired","newsfilecorp","awp","dpa_afx","zonebourse_dpa","mtnewswires","mtnewswires_zonebourse","capital_iq"]; 
        else if(aNews.length>100)
            aValidSource = ((window.location.host).indexOf("zonebourse")>=0) ? ["dow_jones","reuters","reuters_pro","zonebourse","optionfinance","prnewswire","businesswire","globenewswire","companynews","fxcm","marketwired","newsfilecorp","nyfp","tensid","awp","dpa_afx","zonebourse_dpa","mtnewswires","mtnewswires_zonebourse","capital_iq"] : ["dow_jones","reuters","reuters_pro","zonebourse","noodls","prnewswire","businesswire","globenewswire","companynews","fxcm","marketwired","newsfilecorp","nyfp","tensid","awp","dpa_afx","zonebourse_dpa","mtnewswires","mtnewswires_zonebourse","capital_iq"];
	    
	    if(sFilter=='agenda' || sFilter=='agenda_hot' || sFilter=='dividendes')
		    aValidSource = [];
    }
	
	var id = 'newsSeries';
	var iZIndex = 1;
	
	 
	if(sFilter=='agenda_hot')
		id = 'newsSeriesAgendaHot';
	
	if(sFilter=='dividendes')
		id = 'newsSeriesDividendes';
	
	if(sFilter=='consensus')
		id = 'newsSeriesConsensus';
	
 
	var sFillColor = '#FFEE00';
	var sShape = 'circlepin';
	var ilegendIndex = 1;
	var sColor = 'black';
	var sWidth = 14;
	var sHeight = 14;
	
	if(sFilter=='agenda')
	{
		sFillColor = 'white';
		sShape = 'circlepin';
		ilegendIndex = 3;
		sColor = '#004EFF';
		sWidth = 6;
		sHeight = 6;
	}
	if(sFilter=='agenda_hot')
	{
		sFillColor = '#FFEE00';
		sShape = 'circlepin';
		iZIndex = 2;
		ilegendIndex = 2;
		sColor = '#004EFF';
		sWidth = 6;
		sHeight = 6;
	}
	if(sFilter=='dividendes')
	{
		sFillColor = '#3fcc00';
		sShape = 'circlepin';
		iZIndex = 3;
		ilegendIndex = 1;
		sColor = '#004EFF';
		sWidth = 6;
		sHeight = 6;
	}
	if(sFilter=='consensus')
	{
		sFillColor = '#C155FF';
		sShape = 'circlepin';
		sColor = '#004EFF';
		sWidth = 6;
		sHeight = 6;
	}
	
    seriesToComplete = {
		 allowOverlapX: true,
        type : 'flags', 
        data : [], 
		tooltip: {
			pointFormat : '<span style="color:black">{point.text}</span>',
		},
        onSeries : 'myValueSeries',
        shape: sShape,
		width:sWidth,
		height:sHeight, 
		zIndex:iZIndex,
		legendIndex:ilegendIndex,
		id : id,
		distance: 0, 
        fillColor: sFillColor,
        color: sColor,
        title : " ", 
        states:{
            hover:{               
                fillColor: "#01DFD7",
                color: "#01DFD7",
            }
        }, 
        lineWidth: 1,
        style: {
            //fontStyle: "italic",
            fontFamily: "Hoefler Text",
            fontWeight: "bold", 
			
        }
    };
	 
    
    var lastFlag = {x:0},
        nbNewsInFlag = 0;
    
    while(newsData = aNews.shift())
    {
        var aValAssoc = newsData['valeurs'].split(',');
        if((aValidSource.length==0 || aValidSource.indexOf(newsData['source'])>=0)&&(newsData['sous_rubrique']!="commentaire_seance")&&(aValAssoc.length<=3))
        { 
            var titleNews;                               
            if((typeof newsData['titre_origine'] === "string") && (newsData['titre_origine']!=""))
                titleNews = ((newsData['titre_origine'].length > 50) && (chart.userOptions.chart.renderTo=="graphNewsMini")) ? newsData['titre_origine'].substr(0,50)+'...' : newsData['titre_origine'];
            else
                titleNews = ((newsData['titre'].length > 50) && (chart.userOptions.chart.renderTo=="graphNewsMini")) ? newsData['titre'].substr(0,50)+'...' : newsData['titre'];
			
		 
			if((sFilter=='agenda' || sFilter=='agenda_hot'|| sFilter=='dividendes') && newsData['titre']!='')
				titleNews = ((newsData['titre'].length > 50) && (chart.userOptions.chart.renderTo=="graphNewsMini")) ? newsData['titre'].substr(0,50)+'...' : newsData['titre'];
			
            var dateNews =  new Date(newsData['date']).getTime();
            if(dateNews!=lastFlag.x)
            {
                if(lastFlag.x>0)
                {
                    if((nbNewsInFlag > 5) && (chart.userOptions.chart.renderTo=="graphNewsMini"))
                        lastFlag.text+="<tr><td class='newsColCT'>...</td></tr>";
                        
                    lastFlag.text+="</table>"; 
                    seriesToComplete.data.push(lastFlag);
                } 
				var sTitle = 'i'
				if(sFilter=='agenda' || sFilter=='agenda_hot' || sFilter=='dividendes' || sFilter=='consensus')
				{ 
					sTitle = '';
				}	
 
				var sText = '<table border="0" class="tabBody" cellspacing="0" cellpadding="0"><tr><td class="newsColCT">&bull; <a href="'+newsData['link']+'" target="_blank">'+titleNews+'</a></td></tr>';
				if(newsData['link']=='' || typeof newsData['link'] === "undefined" || newsData['link']==window.location.pathname)
					sText = '<table border="0" class="tabBody" cellspacing="0" cellpadding="0"><tr><td class="newsColCT">&bull; '+titleNews+'</td></tr>';
				
				lastFlag = {
					x : dateNews,
					title : sTitle, 
					text : sText,
					id : newsData['id'], 
				};
				 	
                nbNewsInFlag = 1;
            }                                                                                                
            else if((nbNewsInFlag < 5) || (chart.userOptions.chart.renderTo!="graphNewsMini"))
            {
                lastFlag.text+="<tr><td class='newsColCT'>&bull; <a href='"+newsData['link']+"' target='_blank'>"+titleNews+"</a></td></tr>";
                nbNewsInFlag++;
            }
            else
            {
                nbNewsInFlag++
            }                      
        }  
    }
    
    if(lastFlag.x>0)
    {
        lastFlag.text+="</table>"; 
        seriesToComplete.data.push(lastFlag);
    }
    
    chart.addSeries(seriesToComplete,true,false);
    chart.hideLoading();
}

function loadAgenda(codeZB,inDiv)
{
    $("#moreNewsButton").prop('disabled', true);
    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        cache: false,
        context : document.body,
        async : true,
        data : {codeZB : codeZB, type : "agenda"/*, limitFrom : nbNewsDisplayed, nbNews : 20*/},
        type : 'GET',
        success : function(data){
            handleDataAgenda(data,inDiv);               
        }
    });
}

function loadAgendaSecteur(codeZB,inDiv)
{
    $("#moreNewsButton").prop('disabled', true);
    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        cache: false,
        context : document.body,
        async : true,
        data : {codeZB : codeZB, type : "agenda", reqSector : 1, eventType : "publications,activité", sFilter : "agenda_secteur"},
        type : 'GET',
        success : function(data){
            handleDataAgendaSecteur(data,inDiv);               
        }
    });
}

function loadAgendaFromDate(codeZB,fromDate,inDiv,sEventType,bConcurence,bOnSeries)
{
    $("#moreNewsButton").prop('disabled', true);
    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        cache: false,
        context : document.body,
        async : true,
        data : {codeZB : codeZB, type : "agenda", datemin: fromDate, reqSector: bConcurence, eventType: sEventType},
        type : 'GET',
        success : function(data){
            handleDataAgenda(data,inDiv,bOnSeries);               
        }
    });
}

function handleDataAgendaSecteur(data,inDiv,bOnSeries)
{           
    var aEvents;                              
    try{
        aEvents = JSON.parse(data);   
    } catch(e){
        console.log(e);
        console.log(data);
        return;
    }                      

    seriesEvents = {
		id: 'newsSeriesSecteur',
        allowOverlapX: true,
        type : 'flags',
        name : 'events',
        showInLegend : true,
        xAxis: 1,
        data : [],
        shape: 'circle', 
		width:6,
		height:6, 
		legendIndex:4,
		y: -15,
	 
		fillColor: '#e1fefe',
		color: '#004EFF',
        tooltip: {
            pointFormat : '<span style="color:{black}">{point.text}</span><br/>'
        }
    }
    
    if(bOnSeries===true)
        seriesEvents.onSeries = 'myValueSeries';
 
    $.each(aEvents,function(index,data){
        seriesEvents.data.push({
            x : (new Date(data['date_publication']).getTime())||(new Date(data['date']).getTime()),
            title : ' ', 
            text : '<table border="0" class="tabBody" cellspacing="0" cellpadding="0"><tr><td class="newsColCT">&bull; <a href="'+data['link']+'" target="_blank">'+data['titre']+'</a></td></tr>', 
            id : data['id'],
        }); 
    });

    var chart = $("#"+inDiv+"").highcharts();
    chart.addSeries(seriesEvents,true,false);
    chart.hideLoading();
}

function handleDataAgenda(data,inDiv,bOnSeries)
{           
    var aEvents;                              
    try{
        aEvents = JSON.parse(data);   
    } catch(e){
        console.log(e);
        console.log(data);
        return;
    }                      

    seriesEvents = {
        allowOverlapX: true,
        type : 'flags',
        name : 'events',
        showInLegend : false,
        xAxis: 1,
		width:12,
		height:12,
        data : [],
        shape: 'squarepin',
        tooltip: {
            pointFormat : '<span style="color:{black}">{point.text}</span><br/>'
        }
    }
    
    if(bOnSeries===true)
        seriesEvents.onSeries = 'myValueSeries';

    $.each(aEvents,function(index,data){
        seriesEvents.data.push({
            x : (new Date(data['date_publication']).getTime())||(new Date(data['date']).getTime()),
            title : data['flag_title'], 
            text : data['titre'].split(" : ")[1], 
            id : data['id'],
            color : data['flag_color']
        }); 
    });

    var chart = $("#"+inDiv+"").highcharts();
    chart.addSeries(seriesEvents,true,false);
    chart.hideLoading();
}

function drawGraphNews(repNo,codeZB,nomSoc,inDiv,nbDecimals,aWords,bIsMobile,sFilter)
{
	sFilter = (typeof sFilter === "undefined") ? "" : sFilter; 
    //axis labels for crosshairs
    /* 
    // configuration and defaults :
    // enabled -> bool / false,
    // fontSize -> String / '11px',
    // fontFamily -> String / 'Arial',
    // fontColor -> String / 'black' <=> "#000000",
    // backgroundColor -> String / "#FFFFFF",
    // borderColor -> String / 'black' <=> "#000000",
    // borderWidth -> int / 1,
    // yAxisLinked -> array / [0],
    // xAxisLinked -> array / [0],
    // yValueDecimals -> array / [0],  if yAxisLinked > yValueDecimals complete yValueDecimals with 0
    // xValueDecimals -> array / [0]   if xAxisLinked > xValueDecimals complete xValueDecimals with 0
    //
    */
    (function (H) {
        'use strict';
        var addEvent = H.addEvent,
            doc = document,
            body = doc.body,
            formatIfNeeded = function(value,axis,nbDec)
            {
                var categories = axis.categories,
                    numericSymbols = chart.options.lang.numericSymbols,
                    i = numericSymbols && numericSymbols.length,
                    multi,
                    ret,
                    nbDec = (typeof nbDec === "undefined") ? 0 : nbDec,
                    // make sure the same symbol is added for all labels on a linear axis
                    numericSymbolDetector = axis.isLog ? value : axis.tickInterval;

                if(i && numericSymbolDetector >= 1000 && !categories) {
                    // Decide whether we should add a numeric symbol like k (thousands) or M (millions).
                    // If we are to enable this in tooltip or other places as well, we can move this
                    // logic to the numberFormatter and enable it by a parameter.
                    while (i-- && (typeof ret === "undefined")) {
                        multi = Math.pow(1000, i + 1);
                        if (numericSymbolDetector >= multi && numericSymbols[i] !== null) {
                            ret = (value / multi).toFixedDown(nbDec) + numericSymbols[i];
                        }
                    }
                }

                if (typeof ret === "undefined")
                    ret = false;
                    
                return ret;
            };

        H.wrap(H.Chart.prototype, 'init', function (proceed) {

            // Run the original proceed method
            proceed.apply(this, Array.prototype.slice.call(arguments, 1));

            var chart = this,
                options = chart.options,
                panning = options.chart.panning || true,
                zoomType = options.chart.zoomType || '',
                container = chart.container,
                yAxis = chart.get('mainAxeValeurs'),
                yPixels,
                xPixels,
                configuration = options.crosshairsLabels||{},
                enabled = configuration.enabled||false,
                fontSize = configuration.fontSize||'11px',
                fontFamily = configuration.fontFamily || 'Arial',
                fontColor = configuration.fontColor || 'black',
                backgroundColor = configuration.backgroundColor||"#FFFFFF",
                borderColor = configuration.borderColor||"black",
                borderWidth = (typeof configuration.borderWidth ==="undefined") ? 1 : configuration.borderWidth,
                yAxisLinked = configuration.yAxisLinked || [0],
                xAxisLinked = configuration.xAxisLinked || [0],
                yValueDecimals = configuration.yValueDecimals || [0],
                xValueDecimals = configuration.xValueDecimals || [0];
                
				
			 
				
				
            if(yAxisLinked.length>yValueDecimals.length)
            {
                do
                {
                    yValueDecimals.push(0);       
                }
                while(yAxisLinked.length>yValueDecimals.length)
            }
            
            if(xAxisLinked.length>xValueDecimals.length)
            {
                do
                {
                    xValueDecimals.push(0);       
                }
                while(xAxisLinked.length>xValueDecimals.length)
            }
            
            if(enabled)
            {
                var yLabel = chart.renderer.text(
                    "Temp",
                    chart.plotBox.width+chart.plotBox.x+20+6,
                    0
                )
                .css({
                    fontFamily : fontFamily,
                    fontSize: fontSize,
                    color: fontColor
                }).
                attr({
                    id : 'yLabel',
                    opacity: 0,
                    zIndex: 7
                })
                .add();
                
                //sampleDate.getDate()+' '+aMonths[sampleDate.getMonth()]+' '+sampleDate.getFullYear()
                var xLabel = chart.renderer.text(
                    "Temp",
                    0,
                    chart.plotBox.height+chart.plotBox.y+3
                )
                .css({
                    fontFamily : fontFamily,
                    fontSize: fontSize,
                    color: fontColor
                }).
                attr({
                    id : 'xLabel',
                    opacity: 0,
                    zIndex: 7
                })
                .add();
                
                var yBox = chart.renderer.rect(
                    yLabel.getBBox().x-3,
                    yLabel.getBBox().y-2,
                    yLabel.getBBox().width+6,
                    yLabel.getBBox().height+4,
                    0)
                .attr({
                    fill: backgroundColor,
                    stroke: borderColor,
                    'stroke-width': borderWidth,
                    opacity: 0,
                    id : 'yBox',
                    zIndex: 6
                })
                .add();
                
                var xBox = chart.renderer.rect(
                    xLabel.getBBox().x-3,
                    xLabel.getBBox().y-2,
                    xLabel.getBBox().width+6,
                    xLabel.getBBox().height+4,
                    0)
                .attr({
                    fill: backgroundColor,
                    stroke: borderColor,
                    'stroke-width': borderWidth,
                    opacity: 0,
                    id : 'xBox',
                    zIndex: 6
                })
                .add();                                                                                             
                      
                addEvent(chart.container, 'mousemove', function (e)
                {
                    yPixels = chart.pointer.normalize(e).chartY;
                    xPixels = chart.pointer.normalize(e).chartX;
                    
                    if((yPixels>chart.plotBox.y)&&(yPixels<chart.plotBox.y+chart.plotBox.height)&&(xPixels>chart.plotBox.x)&&(xPixels<chart.plotBox.x+chart.plotBox.width))
                    {
                        $.each(yAxisLinked,function(index,axis){
                            if((yPixels>chart.yAxis[axis].top)&&(yPixels<chart.yAxis[axis].top+chart.yAxis[axis].height))
                            {
                                var yLabelText = formatIfNeeded(chart.yAxis[axis].toValue(yPixels),chart.yAxis[axis],yValueDecimals[axis]);
                                yLabelText = (yLabelText) ? yLabelText : Math.floor(chart.yAxis[axis].toValue(yPixels) * Math.pow(10,yValueDecimals[axis])) / Math.pow(10,yValueDecimals[axis]);
                                
                                yLabel.attr({
                                    text: yLabelText,
                                    opacity: 1 
                                });
                                yBox.attr({
                                    width: yLabel.getBBox().width+6,
                                    x: chart.plotBox.x + chart.plotBox.width, 
                                    y: yPixels-(yBox.attr('height')/2),
                                    opacity: 1
                                });
                                yLabel.attr({
                                    y: yBox.attr('y')+parseInt(fontSize)+1,
                                    x: yBox.attr('x')+3 
                                });
                                return false;    
                            }
                            else
                            {
                                yBox.attr({
                                    opacity: 0
                                });
                                yLabel.attr({
                                    opacity: 0
                                });    
                            }   
                        });
                        
                        //Adjust xPixels' value to fit the hoverPoint
                        //xPixels = chart.xAxis[0].toPixels(chart.hoverPoints[0].x);
                        
                        $.each(xAxisLinked,function(index,axis){
                            if((xPixels>chart.xAxis[axis].left)&&(xPixels<chart.xAxis[axis].left+chart.xAxis[axis].width))
                            {
                                var xLabelText;
                                if(chart.xAxis[axis].options.type=="datetime")
                                {
                                    var newDate = new Date(chart.xAxis[axis].toValue(xPixels));
                                    xLabelText = newDate.getDate()+' '+aMonths[newDate.getMonth()]+' '+newDate.getFullYear();    
                                }
                                else
                                {
                                    xLabelText = Math.floor(chart.xAxis[axis].toValue(xPixels) * Math.pow(10,xValueDecimals[axis])) / Math.pow(10,xValueDecimals[axis]);   
                                }
                                
                                
                                xLabel.attr({
                                    text: xLabelText,
                                    y: chart.plotBox.height+chart.plotBox.y+parseInt(fontSize)+3+2, //bollow plotBox + fontSize + margin + padding
                                    opacity: 1 
                                });  
                                xBox.attr({
                                    width: xLabel.getBBox().width+6,
                                    opacity: 1
                                });
                                xBox.attr({
                                    x: xPixels-(xBox.attr('width')/2),
                                    y: chart.plotBox.height+chart.plotBox.y+3
                                });
                                xLabel.attr({
                                    x: xBox.attr('x')+3
                                });
                                
                                return false;
                            }
                            else
                            {
                                xBox.attr({
                                    opacity: 0
                                });
                                xLabel.attr({
                                    opacity: 0
                                });    
                            }
                            
                        });
                    }
                    else
                    {
                        yBox.attr({
                            opacity: 0
                        });
                        xBox.attr({
                            opacity: 0
                        });
                        yLabel.attr({
                            opacity: 0
                        });
                        xLabel.attr({
                            opacity: 0
                        });    
                    } 
                });
            }
        });
    }(Highcharts));
    
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    
	
	
    var creditsLink = (bIsMobile) ? null : 'http://www.'+aWords[0];
 
		
	var creditsText = '\u00A9'+aWords[0];
	var creditsEnable = true;
	
	if(sFilter=='agenda' || sFilter=='consensus')
	{
		creditsText = '';
		creditsEnable = false;
	}
   
	
	
	if(sFilter=='agenda' || sFilter=='consensus')
	{
	 
	  
		Highcharts.setOptions({
				lang: {
					rangeSelectorZoom:'',
				},
			}); 
	
			var options = {
			
			chart : {
				animation : false,
				renderTo : inDiv , 
				spacingRight : 10, 
				style :
				{
					fontFamily : 'Arial, Helvetica, Sans-Serif',
					color: "black"
				},
				events: {
					load: function(){                         
						var imageHeight = 25;
						var imageWidth = 240;
						if(sFilter=='')
						this.renderer.image("https://www.zonebourse.com/images/pdf_Report/"+aWords[0].capitalize()+".png",20,55,imageWidth,imageHeight).css({opacity: 0.5}).attr({zIndex: 2}).add();
						//  document.getElementsByClassName("highcharts-range-selector-buttons")[0].firstChild.textContent = ""; 
					}
				}, 
				pinchType: "", 
				
			}, 
			
			credits : {
				enabled : creditsEnable,
				href : creditsLink,
				text : creditsText,
				style : {
					fontSize : '12px'               
				} 
			},
			
			crosshairsLabels: {
				enabled: true,
				fontSize: '11px',
				fontFamily : 'Tahoma',
				backgroundColor: "#FFEE00",
				borderColor: "black",
				borderWidth: 1,
				yValueDecimals : [nbDecimals,1],  
				yAxisLinked : [0,1],
				xAxisLinked : [0]
			},
			
			exporting : {
				enabled : false
			},
			 
			rangeSelector : configSelectorAgenda, 

			title : { 
				text : null      
			},
			
			scrollbar: {
				enabled: false
			},
			
			navigator: {
				enabled : false,
			}, 

			legend: {
			  enabled : true,
			  useHTML: true,
			 
			  squareSymbol: false,
			  symbolHeight: 0,
			  symbolWidth: 0,
			  symbolRadius: 0, 
			  itemStyle: {
				fontWeight: 'normal',
				textOverflow: ""
			  },
	  
			  labelFormatter: function() { 
				
				var color = '';
				var name = '';
				if(this.userOptions.id=="newsSeriesAgendaHot")
				{
					color = '#FFEE00';
					name = aWords[2];
				}
				if(this.userOptions.id=="newsSeries")
				{ 
					color = 'white';
					name = aWords[3];
				}
				if(this.userOptions.id=="newsSeriesDividendes")
				{ 
					color = '#3fcc00';
					name = aWords[4];
				} 
				if(this.userOptions.id=="newsSeriesSecteur")
				{
					color = '#e1fefe';
					name = aWords[5];
				}
				if(this.userOptions.id=="newsSeriesConsensus")
				{
					color = '#C155FF';
					name = aWords[3];
				}
				return '<div style="border-radius:50%;border:1px solid #004EFF;background:'+color+';width:10px;height:10px;float:left;margin-top:1px;margin-right:2px;">&nbsp;</div>  ' + name; 
			  }
			},

			tooltip : {
				
				backgroundColor: {
					linearGradient: {
						x1: 0,
						y1: 0,
						x2: 0,
						y2: 1
					},
					stops: [
						[0, 'white'],
						[1, '#EEE']
					]
				},
				hideDelay: 1500,
				borderColor: 'gray',
				borderWidth: 1,
				borderRadius: 5,
				shared : true,
				split: false,
				headerFormat: '<span style="font-size:12px">'+aWords[1]+' : <b>{point.key}</b></span><br>', 
				xDateFormat: dateFormatDay,				
				useHTML: true, 
				style: {
					pointerEvents: 'auto'
				}                
			},

			plotOptions: {
				candlestick: {
					color: '#FF0000',        //close<open
					upColor: '#00FF00',      //close>open
					pointPadding: 0.1,
					enableMouseTracking : false
				},
				column: {
					color: '#1a324a',        //volume color
					pointPadding: 0.01,
					enableMouseTracking : false 
				},  
				line: {
					lineWidth : 2,     
					enableMouseTracking : false,
					color : '#1A324A'                
				},
				ohlc: {
					enableMouseTracking : false
				},
				flags : {
					states : {
						hover : {
							fillColor : "#81DAF5"
						}
					},
					lineWidth : 1               
				},
				series: {
					pointPlacement: "between",
					dataGrouping: {
						units:[
							['day',[1]]
						],
						dateTimeLabelFormats: {
							day : [dateFormatDay],
						}
					}
				}
			},
			
			xAxis: [
			{
				allowDecimals: false,
				endOnTick: false,
				labels: {   
					align: 'center',
					style: {
						color: "black"
					},
					zIndex: 5
				},
				lineWidth: 1,
				lineColor: 'black',
				gridLineColor: "#ededed",      
				gridLineWidth: 1,      
				title: null,
				minRange: 3600*24*30*1000,
				tickWidth: 1,
				tickLength: 5,
				tickColor: 'black',
				showFirstLabel: true,
				crosshair: {
					snap: false
				}
			},
			{ 
				lineWidth: 1,
				margin: [0, 0, 0, 0],
				spacing:[0, 0, 0, 0],
				distance:0,
				lineColor: "black",                                                                         
				tickWidth: 0,
				linkedTo: 0, 
				tickLength: 0,
				labels: {
					enabled: false
				}, 
				offset : 0,
				crosshair: {
					snap: false 
				}  
			}], 

			yAxis: [{
				id: "mainAxeValeurs",
				lineWidth: 1,   
				gridLineColor: "#ededed",
				title: "variation",  
				lineColor: 'black',
				maxPadding: 0.12,
				tickWidth: 1,
				tickLength: 5,
				tickColor: 'black',
				tickPixelInterval: 50,
				endOnTick: false,
				startOnTick: false,
				labels: {
					align: 'left',
					x: 10,
					style : {
						color: "black"
					}
				},       
				showLastLabel: true,
				type: 'logarithmic',
				offset: 20,
				crosshair: {
					snap: false
				}                                    
			},
			{
				id : 'axeVolumes',
				title: null,
				top: '80%',
				height: '0%',
				gridLineWidth: 1,
				gridLineColor: "#ededed",
				lineWidth: 1,
				lineColor: "black",
				tickWidth: 1,
				tickLength: 5,
				tickColor: 'black',
				offset : 20,
				scalable: false,
				labels : {
					align : 'left',
					x : 5,
					style: {
						color: "black"
					}
				},
				showEmpty : false,
				showLastLabel: true,
				endOnTick: false,
				crosshair: {
					snap: false
				}   
			}]
			
			               
		};
		
		
		 
	}
	else
	{
		 var options = {
        chart : {
            renderTo : inDiv ,
            spacingRight : 10,  
            marginBottom : 20,
            spacingBottom : 20, 
			
            style :
            {
                fontFamily : 'Arial, Helvetica, Sans-Serif',
                color: "black"
            },
            events: {
                load: function(){                         
                    var imageHeight = 25;
                    var imageWidth = 240;
                    this.renderer.image("https://www.zonebourse.com/images/pdf_Report/"+aWords[0].capitalize()+".png",20,55,imageWidth,imageHeight).css({opacity: 0.5}).attr({zIndex: 2}).add();
				}
            }, 
            pinchType: "",
            zoomType: ""         
        },

        exporting : {
            enabled : false
        },

        credits : {
            enabled : true,
            href : creditsLink,
            text : '\u00A9'+aWords[0],
            style : {
                fontSize : '12px'               
            } 
        },

        title : { 
            text : null      
        },
		
        navigator: {
            height: 40,
            yAxis: {
                type : 'logarithmic'
            },
            xAxis : {
                allowDecimals : false,
                endOnTick : true,
                maxPadding : 5,
                labels: {
                    style : {
                        color: "black"
                    }
                }
            }
        },
        
        rangeSelector : configSelectorLong,

        legend : {
            enabled : false  
        },

        tooltip : {
            
            backgroundColor: {
                linearGradient: {
                    x1: 0,
                    y1: 0,
                    x2: 0,
                    y2: 1
                },
                stops: [
                    [0, 'white'],
                    [1, '#EEE']
                ]
            },
            hideDelay: 1500,
            borderColor: 'gray',
            borderWidth: 1,
            borderRadius: 5,
            shared : true,
            split: false,
            headerFormat: '<span style="font-size:12px">'+aWords[1]+' : <b>{point.key}</b></span><br>',   
			xDateFormat: dateFormatDay,						
            useHTML: true,
            dateTimeLabelFormats : {
                day : dateFormatDay
            },
            style: {
                pointerEvents: 'auto'
            }                
        },

        xAxis: [
        {
            allowDecimals: false,
            endOnTick: false,
            labels: {   
                align: 'center',
                style: {
                    color: "black"
                },
                zIndex: 5
            },
            lineWidth: 1,
            lineColor: 'black',
            gridLineColor: "#ededed",      
            gridLineWidth: 1,      
            title: null,
            minRange: 3600*24*30*1000,
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            showFirstLabel: true,
            crosshair: {
                snap: false
            }
        },
        {
            lineWidth: 1,
            lineColor: "black",                                                                         
            tickWidth: 0,
            linkedTo: 0,
            tickLength: 0,
            labels: {
                enabled: false
            },
            offset : 0,
            crosshair: {
                snap: false 
            }  
        }], 

        yAxis: [{
            id: "mainAxeValeurs",
            lineWidth: 1,   
            gridLineColor: "#ededed",
            title: "variation",  
            lineColor: 'black',
            maxPadding: 0.1,
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            tickPixelInterval: 50,
            endOnTick: false,
            startOnTick: false,
            labels: {
                align: 'left',
                x: 10,
                style : {
                    color: "black"
                }
            },       
            showLastLabel: true,
            type: 'logarithmic',
            offset: 20,
            crosshair: {
                snap: false
            }                                    
        },
        {
            id : 'axeVolumes',
            title: null,
            top: '85%',
            height: '0%',
            gridLineWidth: 1,
            gridLineColor: "#ededed",
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            offset : 20,
            scalable: false,
            labels : {
                align : 'left',
                x : 5,
                style: {
                    color: "black"
                }
            },
            showEmpty : false,
            showLastLabel: true,
            endOnTick: false,
            crosshair: {
                snap: false
            }   
        }],

        plotOptions: {
            candlestick: {
                color: '#FF0000',        //close<open
                upColor: '#00FF00',      //close>open
                pointPadding: 0.1,
                enableMouseTracking : false
            },
            column: {
                color: '#1a324a',        //volume color
                pointPadding: 0.01,
                enableMouseTracking : false 
            },  
            line: {
                lineWidth : 2,     
                enableMouseTracking : false,
                color : '#1A324A'                
            },
            ohlc: {
                enableMouseTracking : false
            },
            flags : {
                stackDistance: 0,
                states : {
                    hover : {
                        fillColor : "#81DAF5"
                    }
                },
                lineWidth : 1               
            },
            series: {
                pointPlacement: "between",
                dataGrouping: {
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                    }
                }
            }
        },
        
        crosshairsLabels: {
            enabled: true,
            fontSize: '11px',
            fontFamily : 'Tahoma',
            backgroundColor: "#FFEE00",
            borderColor: "black",
            borderWidth: 1,
            yValueDecimals : [nbDecimals,1],  
            yAxisLinked : [0,1],
            xAxisLinked : [0]
        }               
    };
	}
	
    var chart = new Highcharts.StockChart(options);
	
    chart.showLoading();    
	
	

    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        cache: false,
        context : document.body,
        async : true,
        data : {codeZB : codeZB, type : "chart", fields : "Date,Open,High,Low,Close"},
        type : 'GET',
        success : function(data)
        { 
		
            try
            {
                aDataQuote = JSON.parse(data)    
            }
            catch(e)
            {
                $('#'+inDiv).css('display','none');
                console.log("erreur JSON parse : "+e);
                console.log("data received : "+data);
                return;
            }
			
			
            var chartSeries = {  
                type : 'line',
				color: "#333333",
                name : nomSoc,   
                data : [],                      
                id : 'myValueSeries',
                yAxis: 0,
                showInLegend: false,
                //zIndex: 0   		
            }; 
			
			if(sFilter=='agenda' || sFilter=='consensus')
			{
				chartSeries.turboThreshold = 20000;
			}
			
			
			
			if(sFilter=='agenda' || sFilter=='consensus')
			{ 
				var i = aDataQuote.length-1; 
				while((i>=0)){
				   chartSeries.data.unshift(aDataQuote[i]);
				   i--;
				}
			}
			else
			{ 
				var now = new Date().getTime();
				var i = aDataQuote.length-1; 
				while((i>=0)&&(aDataQuote[i]['x']>(now-(3600*24*365*2*1000))))
				{        
					chartSeries.data.unshift(aDataQuote[i]);
					i--;                
				}
			}
			 
            
            // Update the chart                              
            chart.addSeries(chartSeries,true,false);

			if(sFilter=='agenda' || sFilter=='consensus')
				chart.rangeSelector.clickButton(4,true);
			else
				chart.rangeSelector.clickButton(2,true);
            
			
			
            $.ajax({url : URL_SERVEUR+'atDataFeed.php',
                cache: false,
                context : document.body,
                async : true,
                data : {codeZB : codeZB, type : "volumes"},
                type : 'GET',
                success : function(data)
                {
                    try
                    {
                        aDataQuote = JSON.parse(data)    
                    }
                    catch(e)
                    {
                        $('#'+inDiv).css('display','none');
                        console.log("erreur JSON parse : "+e);
                        console.log("data received : "+data);
                        return;
                    }

                    var volumeSeries = {
						showInLegend: false,
						animation : false,
                        type : 'column',
                        name : 'Volumes',
                        data : [],//aDataQuote,
                        yAxis: 'axeVolumes',
                        id : 'volumes',
						color: "#333333",
                        tooltip: {
                            pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y}</b></td></tr>'
                        },
                        dataGrouping: {
                            units:[
                                ['day',[1]]
                            ],
                            dateTimeLabelFormats: {
                                day : [dateFormatDay],
                                week: [dateFormatWeek]
                            }
                        }
                    };

                    
					
					
					if(sFilter=='agenda' || sFilter=='consensus')
					{
						var i = aDataQuote.length-1; 
						while((i>=0)){
						   volumeSeries.data.unshift(aDataQuote[i]);
						   i--;
						}
					}
					else
					{ 
						var now = new Date().getTime();
						var i = aDataQuote.length-1; 
						while((i>=0)&&(aDataQuote[i][0]>(now-(3600*24*365*2*1000))))
						{        
							volumeSeries.data.unshift(aDataQuote[i]);
							i--;                
						}
					}
			
	
                    if(aDataQuote.length>0)
                    {
                        var chart = $("#"+inDiv).highcharts();
                        bGotVolumes = true;
						
						if(sFilter=='')
						{
							chart.get('axeVolumes').update({
								height: '15%',
								tickPixelInterval: chart.plotHeight*(0.1)
							});
							chart.get('mainAxeValeurs').update({
								height : '85%'
							});
						}
						else
						{
							chart.get('axeVolumes').update({
								height: '20%',
								tickPixelInterval: chart.plotHeight*(0.1)
							});
							chart.get('mainAxeValeurs').update({
								height : '80%'
							});
						}
                        
						if(sFilter=='')
						{
							chart.xAxis[1].update({
								offset: -chart.plotHeight*0.15
							}); 
						}
						else
						{
							chart.xAxis[1].update({
								offset: -chart.plotHeight*0.20
							}); 
						}
                        
                        chart.addSeries(volumeSeries,true,false);
                        aChartSeriesID.push(volumeSeries.id);
                    }
                    
                    if(typeof callback == "function") callback();
                }
            });

			
 
	
            loadMoreNews(codeZB,inDiv,sFilter);
			
			if(sFilter=='agenda')
			{
				loadMoreNews(codeZB,inDiv,'agenda_hot');
				loadMoreNews(codeZB,inDiv,'dividendes');
				loadAgendaSecteur(codeZB,inDiv);
            } 
			else if(sFilter=='consensus')
			{
            } 
			else
				loadAgenda(codeZB,inDiv);
			
    }});
}

function drawGraphNewsMini(repNo,codeZB,nomSoc,inDiv,nbDecimals,sPage,aWords,bIsMobile)
{
    //axis labels for crosshairs
    /* 
    // configuration and defaults :
    // enabled -> bool / false,
    // fontSize -> String / '11px',
    // fontFamily -> String / 'Arial',
    // fontColor -> String / 'black' <=> "#000000",
    // backgroundColor -> String / "#FFFFFF",
    // borderColor -> String / 'black' <=> "#000000",
    // borderWidth -> int / 1,
    // yAxisLinked -> array / [0],
    // xAxisLinked -> array / [0],
    // yValueDecimals -> array / [0],  if yAxisLinked > yValueDecimals complete yValueDecimals with 0
    // xValueDecimals -> array / [0]   if xAxisLinked > xValueDecimals complete xValueDecimals with 0
    //
    */
    (function (H) {
        'use strict';
        var addEvent = H.addEvent,
            doc = document,
            body = doc.body,
            formatIfNeeded = function(value,axis,nbDec)
            {
                var categories = axis.categories,
                    numericSymbols = chart.options.lang.numericSymbols,
                    i = numericSymbols && numericSymbols.length,
                    multi,
                    ret,
                    nbDec = (typeof nbDec === "undefined") ? 0 : nbDec,
                    // make sure the same symbol is added for all labels on a linear axis
                    numericSymbolDetector = axis.isLog ? value : axis.tickInterval;

                if(i && numericSymbolDetector >= 1000 && !categories) {
                    // Decide whether we should add a numeric symbol like k (thousands) or M (millions).
                    // If we are to enable this in tooltip or other places as well, we can move this
                    // logic to the numberFormatter and enable it by a parameter.
                    while (i-- && (typeof ret === "undefined")) {
                        multi = Math.pow(1000, i + 1);
                        if (numericSymbolDetector >= multi && numericSymbols[i] !== null) {
                            ret = (value / multi).toFixedDown(nbDec) + numericSymbols[i];
                        }
                    }
                }

                if (typeof ret === "undefined")
                    ret = false;
                    
                return ret;
            };

        H.wrap(H.Chart.prototype, 'init', function (proceed) {

            // Run the original proceed method
            proceed.apply(this, Array.prototype.slice.call(arguments, 1));

            var chart = this,
                options = chart.options,
                panning = options.chart.panning || true,
                zoomType = options.chart.zoomType || '',
                container = chart.container,
                yAxis = chart.get('mainAxeValeurs'),
                yPixels,
                xPixels,
                configuration = options.crosshairsLabels||{},
                enabled = configuration.enabled||false,
                fontSize = configuration.fontSize||'11px',
                fontFamily = configuration.fontFamily || 'Arial',
                fontColor = configuration.fontColor || 'black',
                backgroundColor = configuration.backgroundColor||"#FFFFFF",
                borderColor = configuration.borderColor||"black",
                borderWidth = (typeof configuration.borderWidth ==="undefined") ? 1 : configuration.borderWidth,
                yAxisLinked = configuration.yAxisLinked || [0],
                xAxisLinked = configuration.xAxisLinked || [0],
                yValueDecimals = configuration.yValueDecimals || [0],
                xValueDecimals = configuration.xValueDecimals || [0];
                
            if(yAxisLinked.length>yValueDecimals.length)
            {
                do
                {
                    yValueDecimals.push(0);       
                }
                while(yAxisLinked.length>yValueDecimals.length)
            }
            
            if(xAxisLinked.length>xValueDecimals.length)
            {
                do
                {
                    xValueDecimals.push(0);       
                }
                while(xAxisLinked.length>xValueDecimals.length)
            }
            
            if(enabled)
            {
                var yLabel = chart.renderer.text(
                    "Temp",
                    chart.plotBox.width+chart.plotBox.x+20+6,
                    0
                )
                .css({
                    fontFamily : fontFamily,
                    fontSize: fontSize,
                    color: fontColor
                }).
                attr({
                    id : 'yLabel',
                    opacity: 0,
                    zIndex: 7
                })
                .add();
                
                //sampleDate.getDate()+' '+aMonths[sampleDate.getMonth()]+' '+sampleDate.getFullYear()
                var xLabel = chart.renderer.text(
                    "Temp",
                    0,
                    chart.plotBox.height+chart.plotBox.y+3
                )
                .css({
                    fontFamily : fontFamily,
                    fontSize: fontSize,
                    color: fontColor
                }).
                attr({
                    id : 'xLabel',
                    opacity: 0,
                    zIndex: 7
                })
                .add();
                
                var yBox = chart.renderer.rect(
                    yLabel.getBBox().x-3,
                    yLabel.getBBox().y-2,
                    yLabel.getBBox().width+6,
                    yLabel.getBBox().height+4,
                    0)
                .attr({
                    fill: backgroundColor,
                    stroke: borderColor,
                    'stroke-width': borderWidth,
                    opacity: 0,
                    id : 'yBox',
                    zIndex: 6
                })
                .add();
                
                var xBox = chart.renderer.rect(
                    xLabel.getBBox().x-3,
                    xLabel.getBBox().y-2,
                    xLabel.getBBox().width+6,
                    xLabel.getBBox().height+4,
                    0)
                .attr({
                    fill: backgroundColor,
                    stroke: borderColor,
                    'stroke-width': borderWidth,
                    opacity: 0,
                    id : 'xBox',
                    zIndex: 6
                })
                .add();                                                                                             
                      
                addEvent(chart.container, 'mousemove', function (e)
                {
                    yPixels = chart.pointer.normalize(e).chartY;
                    xPixels = chart.pointer.normalize(e).chartX;           
                    
                    if((yPixels>chart.plotBox.y)&&(yPixels<chart.plotBox.y+chart.plotBox.height)&&(xPixels>chart.plotBox.x)&&(xPixels<chart.plotBox.x+chart.plotBox.width))
                    {
                        $.each(yAxisLinked,function(index,axis){
                            if((yPixels>chart.yAxis[axis].top)&&(yPixels<chart.yAxis[axis].top+chart.yAxis[axis].height))
                            {
                                var yLabelText = formatIfNeeded(chart.yAxis[axis].toValue(yPixels),chart.yAxis[axis],yValueDecimals[axis]);
                                yLabelText = (yLabelText) ? yLabelText : Math.floor(chart.yAxis[axis].toValue(yPixels) * Math.pow(10,yValueDecimals[axis])) / Math.pow(10,yValueDecimals[axis]);
                                
                                yLabel.attr({
                                    text: yLabelText,
                                    opacity: 1 
                                });
                                yBox.attr({
                                    width: yLabel.getBBox().width+6,
                                    x: chart.plotBox.x + chart.plotBox.width, 
                                    y: yPixels-(yBox.attr('height')/2),
                                    opacity: 1
                                });
                                yLabel.attr({
                                    y: yBox.attr('y')+parseInt(fontSize)+1,
                                    x: yBox.attr('x')+3 
                                });
                                return false;    
                            }
                            else
                            {
                                yBox.attr({
                                    opacity: 0
                                });
                                yLabel.attr({
                                    opacity: 0
                                });    
                            }   
                        });
                        
                        //Adjust xPixels' value to fit the hoverPoint
                        //xPixels = chart.xAxis[0].toPixels(chart.hoverPoints[0].x);
                        
                        $.each(xAxisLinked,function(index,axis){
                            if((xPixels>chart.xAxis[axis].left)&&(xPixels<chart.xAxis[axis].left+chart.xAxis[axis].width))
                            {
                                var xLabelText;
                                if(chart.xAxis[axis].options.type=="datetime")
                                {
                                    var newDate = new Date(chart.xAxis[axis].toValue(xPixels));
                                    xLabelText = newDate.getDate()+' '+aMonths[newDate.getMonth()]+' '+newDate.getFullYear();    
                                }
                                else
                                {
                                    xLabelText = Math.floor(chart.xAxis[axis].toValue(xPixels) * Math.pow(10,xValueDecimals[axis])) / Math.pow(10,xValueDecimals[axis]);   
                                }
                                
                                
                                xLabel.attr({
                                    text: xLabelText,
                                    y: chart.plotBox.height+chart.plotBox.y+parseInt(fontSize)+3+2, //bollow plotBox + fontSize + margin + padding
                                    opacity: 1 
                                });  
                                xBox.attr({
                                    width: xLabel.getBBox().width+6,
                                    opacity: 1
                                });
                                xBox.attr({
                                    x: xPixels-(xBox.attr('width')/2),
                                    y: chart.plotBox.height+chart.plotBox.y+3
                                });
                                xLabel.attr({
                                    x: xBox.attr('x')+3
                                });
                                
                                return false;
                            }
                            else
                            {
                                xBox.attr({
                                    opacity: 0
                                });
                                xLabel.attr({
                                    opacity: 0
                                });    
                            }
                            
                        });
                    }
                    else
                    {
                        yBox.attr({
                            opacity: 0
                        });
                        xBox.attr({
                            opacity: 0
                        });
                        yLabel.attr({
                            opacity: 0
                        });
                        xLabel.attr({
                            opacity: 0
                        });    
                    } 
                });
            }
        });
    }(Highcharts));
    
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    
    var creditsLink = (bIsMobile) ? null : 'http://www.'+aWords[0];

    var options = {
        chart : {
            renderTo : inDiv ,  
            style :
            {
                fontFamily : 'Arial, Helvetica, Sans-Serif',
                color: "black"
            }, 
            pinchType: "",
            zoomType: "",
            panning: false         
        }, 

        credits : {
            enabled : false
        }, 
        
        crosshairsLabels: {
            enabled: true,
            fontSize: '11px',
            fontFamily : 'Tahoma',
            backgroundColor: "#FFEE00",
            borderColor: "black",
            borderWidth: 1,
            yValueDecimals : [nbDecimals,1],  
            yAxisLinked : [0,1],
            xAxisLinked : [0]
        },  
            
        
        legend : {
            enabled : false  
        },
        
        navigator: {
            enabled: false
        },
        
        plotOptions: {
            candlestick: {
                color: '#FF0000',        //close<open
                upColor: '#00FF00',      //close>open
                pointPadding: 0.1,
                enableMouseTracking : false
            },
            column: {
                color: '#1a324a',        //volume color
                pointPadding: 0.01,
                enableMouseTracking : false 
            },  
            line: {
                lineWidth : 2,     
                enableMouseTracking : false,
                color : '#1A324A'                
            },
            ohlc: {
                enableMouseTracking : false
            },
            flags : {
                stackDistance: 0,
                states : {
                    hover : {
                        fillColor : "#81DAF5"
                    }
                },
                lineWidth : 1               
            },
            series: {
                pointPlacement: "between",
                dataGrouping: {
                    enabled: true,
                    forced: true,
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                    }
                }
            }
        },
        
        rangeSelector : {
            enabled: false
        },  
        
        scrollbar: {
            enabled: false
        },

        title : { 
            text : null      
        },
            
        tooltip : {
            
            backgroundColor: {
                linearGradient: {
                    x1: 0,
                    y1: 0,
                    x2: 0,
                    y2: 1
                },
                stops: [
                    [0, 'white'],
                    [1, '#EEE']
                ]
            },
            hideDelay: 1500,
            borderColor: 'gray',
            borderWidth: 1,
            borderRadius: 5,
            shared : true,
            split: false,
            headerFormat: '<span style="font-size:12px">'+aWords[1]+' : <b>{point.key}</b></span><br>',            
            useHTML: true,
            dateTimeLabelFormats : {
                day : dateFormatDay
            },
            style: {
                pointerEvents: 'auto'
            }                
        },      

        xAxis: [
        {
            allowDecimals: false,
            endOnTick: false,
            labels: {   
                align: 'center',
                style: {
                    color: "black"
                },
                zIndex: 5
            },
            lineWidth: 1,
            lineColor: 'black',
            gridLineColor: "#ededed",      
            gridLineWidth: 1,      
            title: null,
            minRange: 3600*24*30*1000,
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            showFirstLabel: true,
            crosshair: {
                snap: false
            }
        },
        {    
            lineWidth: 1,
            lineColor: "black",                                                                         
            tickWidth: 0,
            linkedTo: 0,
            tickLength: 0,
            labels: {
                enabled: false
            },
            offset : 0,
            crosshair: {
                snap: false 
            }  
        }], 

        yAxis: [{
            id: "mainAxeValeurs",
            lineWidth: 1,   
            gridLineColor: "#ededed",
            title: "variation",  
            lineColor: 'black',
            maxPadding: 0.1,
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            tickPixelInterval: 50,
            endOnTick: false,
            startOnTick: false,
            labels: {
                align: 'left',
                x: 10,
                style : {
                    color: "black"
                }
            },       
            showLastLabel: true,
            type: 'logarithmic',
            offset: 20,
            crosshair: {
                snap: false
            }                                    
        },
        {
            id : 'axeVolumes',
            title: null,
            top: '85%',
            height: '0%',
            gridLineWidth: 1,
            gridLineColor: "#ededed",
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',     
            offset : 20,
            scalable: false,
            labels : {
                align : 'left',
                x : 5,
                style: {
                    color: "black"
                }
            },
            showEmpty : false,
            showLastLabel: true,
            endOnTick: false,
            crosshair: {
                snap: false
            }   
        }]             
    };
                                                                               
    var chart = new Highcharts.StockChart(options);

    chart.showLoading();
    
    var begin = new Date();
    begin.setMonth(begin.getMonth() - 10);
    //begin.setFullYear(begin.getFullYear() - 1);
    sBegin = begin.getFullYear()+'-'+(begin.getMonth()+1)+'-'+begin.getDate();

    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        cache: false,
        context : document.body,
        async : true,
        data : {codeZB : codeZB, type : "chart", fields : "Date,Open,High,Low,Close", date_start: sBegin},
        type : 'GET',
        success : function(data)
        {    
            try
            {
                aDataQuote = JSON.parse(data)    
            }
            catch(e)
            {
                $('#'+inDiv).css('display','none');
                console.log("erreur JSON parse : "+e);
                console.log("data received : "+data);
                return;
            }
        
            var chartSeries = {                          
                type : 'line',
                name : nomSoc,   
                data : [],
                id : 'myValueSeries',
                yAxis: 0,
                showInLegend: false,
                //zIndex: 0              
            };     

            var now = new Date().getTime();
            var i = aDataQuote.length-1; 
            while((i>=0)&&(aDataQuote[i]['x']>(now-(3600*24*365*2*1000))))
            {
                chartSeries.data.unshift(aDataQuote[i]);
                i--;                
            }  
            
            // Update the chart                              
            chart.addSeries(chartSeries,true,false);
            
            $.ajax({url : URL_SERVEUR+'atDataFeed.php',
                cache: false,
                context : document.body,
                async : true,
                data : {codeZB : codeZB, type : "volumes", date_start: sBegin},
                type : 'GET',
                success : function(data)
                {
                    try
                    {
                        aDataQuote = JSON.parse(data)    
                    }
                    catch(e)
                    {
                        $('#'+inDiv).css('display','none');
                        console.log("erreur JSON parse : "+e);
                        console.log("data received : "+data);
                        return;
                    }

                    var volumeSeries = {
                        type : 'column',
                        name : 'Volumes',
                        data : [],//aDataQuote,
                        yAxis: 'axeVolumes',
                        id : 'volumes',
                        tooltip: {
                            pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y}</b></td></tr>'
                        },
                        dataGrouping: {
                            units:[
                                ['day',[1]]
                            ],
                            dateTimeLabelFormats: {
                                day : [dateFormatDay],
                                week: [dateFormatWeek]
                            }
                        }
                    };

                    var now = new Date().getTime();
                    var i = aDataQuote.length-1; 
                    while((i>=0)&&(aDataQuote[i][0]>(now-(3600*24*365*2*1000))))
                    {        
                        volumeSeries.data.unshift(aDataQuote[i]);
                        i--;                
                    }

                    if(aDataQuote.length>0)
                    {
                        var chart = $("#"+inDiv).highcharts();
                        bGotVolumes = true;
                        chart.get('axeVolumes').update({
                            height: '15%',
                            tickPixelInterval: chart.plotHeight*(0.1)
                        });
                        chart.get('mainAxeValeurs').update({
                            height : '85%'
                        });
                        chart.xAxis[1].update({
                            offset: -chart.plotHeight*0.15
                        });
                        chart.addSeries(volumeSeries,true,true);
                        aChartSeriesID.push(volumeSeries.id);
                    }
                    
                    if(typeof callback == "function") callback();
                }
            });
            
            if(sPage=="actualites")
            {                                                                
                loadNewsFromDate(codeZB,sBegin,inDiv);
                loadAgendaFromDate(codeZB,sBegin,inDiv,"",0,false);
            }
            else
            {      
                loadAgendaFromDate(codeZB,sBegin,inDiv,"",0,false);       
            }
    }});
}