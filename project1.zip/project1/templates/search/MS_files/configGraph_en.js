if(typeof URL_SERVEUR == "undefined")
    var URL_SERVEUR = "/charting/";

String.prototype.capitalize = function() {
    return this.charAt(0).toUpperCase() + this.slice(1).toLowerCase();
}

var rangeSelectorButtonsSmall,
    rangeSelectorButtonsLong,
    dateFormatDay,
    dateFormatWeek,
    tooltipValueFormat,
    rangeSelectorButtonsAgenda;

    
var mouseDown = 0;

const aMainStyle = {        
    backgroundColor : "white",
    spacingBottom: 20,
    spacingLeft: 0,
    spacingRight: 0,  
    
    legendAlign: "right", 
    legendMargin: 8,
    symbolHeight: 8,
       
    fontSize1 : "12px",
    fontSize2 : "10px",
    
    xAxisBottomLineColor: "black",
    xAxisBottomLineWidth: 2,
    xAxisBottomTickWidth: 0,
    xAxisgridLineDashStyle: 'Dot',
    xAxisgridLineWidth : 1,
    xAxisgridLineColor : '#A5A5A5',
    xAxisLabelColor : "black",
    xAxisLabelWeight : "bold",
    xAxisTopTickWidth: 0,
    xAxisTopLineColor: "black",
    xAxisTopLineWidth: 0,
    
    yAxisLabelColor : "#818181",  
    yAxisgridLineDashStyle: 'Dot',
    yAxisgridLineWidth : 1,
    yAxisgridLineColor : '#A5A5A5',
    yAxisLeftLineColor: "black",
    yAxisLeftLineWidth: 2,
    yAxisLeftTickWidth: 0,
    yAxisRightLineColor: "black", 
    yAxisRightLineWidth: 0,
    yAxisRightTickWidth: 0         
};

$(function() {
    document.body.onmousedown = function() {
        mouseDown=1;
    }
    document.body.onmouseup = function() {
        mouseDown=0;
    }
});

Highcharts.setOptions({
    chart: {
        style: {
            fontFamily: "Arial, Helvetica"    
        }
    },
    exporting:
    {
        enabled: false
    },
    lang: {
        thousandsSep : ',',                 //séparateur des milliers
        decimalPoint : '.',                 //Séparateur des décimales
    },
    rangeSelector: {
        inputDateFormat: "%m/%d/%Y"
    }
});

rangeSelectorButtonsSmall = [{
    type: 'month',
    count: 1,
    text: '1m'
}, {
    type: 'month',
    count: 3,
    text: '3m'
}, {
    type: 'month',
    count: 6,
    text: '6m'
}, {
    type: 'ytd',
    text: "YTD"
}, {
    type: 'year',
    count: 1,
    text: '1y'
}, {
    type: 'year',
    count: 3,
    text: '3y'
}, {
    type: 'year',
    count: 5,
    text: '5y'
}, {
    type: 'all',
    text: 'All'
}];

rangeSelectorButtonsAgenda = [{
        type: 'month',
        count: 1,
        text: '1m'     
    }, {
        type: 'month',
        count: 3,
        text: '3m'
    }, {
        type: 'ytd',
        text: "01/01"
    }, {
        type: 'year',
        count: 1,
        text: '1y'
    }, {
        type: 'year',
        count: 2,
        text: '2y'
    }, {
        type: 'year',
        count: 3,
        text: '3y'
    }, {
        type: 'year',
        count: 5,
        text: '5y'
}];

rangeSelectorButtonsLong = [{
    type: 'month',
    count: 2,
    text: '2m'     
}, {
    type: 'month',
    count: 3,
    text: '3m'
}, {
    type: 'month',
    count: 6,
    text: '6m'
}, {
    type: 'month',
    count: 9,
    text: '9m'
}, {
    type: 'ytd',
    text: "YTD"
}, {
    type: 'year',
    count: 1,
    text: '1y'
}, {
    type: 'year',
    count: 2,
    text: '2y'
}, {
    type: 'year',
    count: 5,
    text: '5y'
}, {
    type: 'all',
    text: 'All'
}];

dateFormatDay =  "%A, %b %e, %Y";

dateFormatWeek = "Week from %A, %b %e, %Y";

tooltipValueFormatOHLC = '<tr><td style="padding:0px ;font-size:12px" colspan="2"><b>{series.name}</b>: <ul style="margin: 3px 0px; padding-left: 15px;list-style-type: none;"><li>Open : <b>{point.open:,.%toReplace%f}</b></li><li>High : <b>{point.high:,.%toReplace%f}</b></li><li>Low : <b>{point.low:,.%toReplace%f}</b></li><li>Close : <b>{point.close:,.%toReplace%f}</b></li></ul></td></tr>';     

tradsTM = {
    "Variation" : "Performance",
    "Valorisation" : "Valuation",
    "perf_portif" : "Portfolio performance",
    "perf_spread" : "Spread",
    "Date" : "Date",
    'pl_values' : "gain / loss"
}; 

Highcharts.setOptions({
    global: {
        useUTC: true
    }
});


var tooltipValueFormatEOD = '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.%toReplace%f}</b></td></tr>';

var configSelectorSmall = {
    buttons : rangeSelectorButtonsSmall,
    buttonTheme: {
        fill : "#FFFFFF",
        style : {
            "text-decoration" : "underline",
            color: "#061574"
        },
        //width : 40,
        states: {
            select:{
                fill : "#FFFFFF",
                style : {
                    "text-decoration" : "none",
                    color: "black"
                },   
            }
        }
    },
    labelStyle: {
        color: "black"
    }
};

var configSelectorLong = {
    buttons : rangeSelectorButtonsLong,
    buttonTheme: {
        fill : "#FFFFFF",
        style : {
            "text-decoration" : "underline",
            color: "#061574"
        },
        //width : 40,
        states: {
            select:{
                fill : "#FFFFFF",
                style : {
                    "text-decoration" : "none",
                    color: "black"        
                },   
            }
        }
    },
    labelStyle: {
        color: "black"
    }
};

var configSelectorAgenda = {
    buttonPosition: {
        x: 0
      },
      inputPosition: {
        x: 40,
      },

    x: 0,
    y: 0,
    buttons : rangeSelectorButtonsAgenda,
   buttonTheme: {
        fill : "#FFFFFF",
        style : {
            "text-decoration" : "underline",
            color: "#061574"
        },
        states: {
            select:{
                fill : "#FFFFFF",
                style : {
                    "text-decoration" : "none",
                    color: "black",
                    fontWeight: "normal"
                },   
            }
        }
    },
    labelStyle: {
        color: "black"
    }
};
var configSelectorGraphComp = {
    floating: true,
    fill:'red',
    buttonPosition: {
        x: 0
      },
      inputPosition: {
        x: 40,
      },
    x: 0,
    y: -80,
    buttons : rangeSelectorButtonsAgenda,
   buttonTheme: {
        fill : "#FFFFFF",
        style : {
            "text-decoration" : "underline",
            color: "#061574"
        },
        states: {
            select:{
                fill : "#FFFFFF",
                style : {
                    "text-decoration" : "none",
                    color: "black",
                    fontWeight: "normal"
                },
            }
        }
    },
    labelStyle: {
        color: "black"
    }
};
var configSelectorMini = {
    inputEnabled : false,
    enabled: true,
    buttons : rangeSelectorButtonsSmall,
    buttonTheme: {
        fill : "#FFFFFF",
        style : {
            "text-decoration" : "underline",
            color: "#061574"
        },            
        states: {
            select:{
                fill : "#FFFFFF",
                style : {
                    "text-decoration" : "none",
                    color: "black"
                },   
            }
        }
    },
    labelStyle: {
        color: "black"
    }
};            

var configured = true;