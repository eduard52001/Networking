if(!configured)
{
    throw new Error('/js/utf-8/configGraph.js is not imported'); 
}
Number.prototype.toFixedDown = function(digits) {
    var re = new RegExp("(\\d+\\.\\d{" + digits + "})(\\d)"),
        m = this.toString().match(re);
    return m ? parseFloat(m[1]) : this.valueOf();
};

var nbAnneeHisto = 100;
var lastTimestamp;
var aIdsLignes = [];
var aMoyennes = {};
var aAT = {day : [],
          week : []};
var bChartDrawn = false;
var aAtFlags = {day : [],
                week : []};
var aChartSeriesID = [];
var bGotVolumes = false;

var aMonths = Highcharts.getOptions().lang.shortMonths;

function array_diff(a,b)
{
    var result = [];
    if(!Array.isArray(a)||!Array.isArray(b))
    {
        console.error('Function \'array_diff\' : At least one of the imputs is not an array -> ',a,b);
        return [];
    }
    $.each(a,function(index, valeur){
        if(b.indexOf(valeur)==-1)
        {
            result.push(valeur);
        }    
    });
    return result;
}

function drawGraphAT(codeZB,inDiv,sTitle,sGraphStyle)
{  
    //make yAxis scalable by default
    (function (H) {
        'use strict';
        var addEvent = H.addEvent,
        each = H.each,
        doc = document,
        body = doc.body;

        H.wrap(H.Chart.prototype, 'init', function (proceed) {

            // Run the original proceed method
            proceed.apply(this, Array.prototype.slice.call(arguments, 1));

            var chart = this,
            renderer = chart.renderer,
            yAxis = chart.yAxis;

            each(yAxis, function (yAxis) {
                var options = yAxis.options,
                scalable = options.scalable === undefined ? true : options.scalable,
                labels = options.labels,
                pointer = chart.pointer,
                labelGroupBBox,
                bBoxX,
                bBoxY,
                bBoxWidth,
                bBoxHeight,
                isDragging = false,
                downYValue;

                if (scalable) {
                    bBoxWidth = 40;
                    bBoxHeight = chart.containerHeight - yAxis.top - yAxis.bottom;
                    bBoxX = yAxis.opposite ? (labels.align === 'left' ? chart.containerWidth - yAxis.right : chart.containerWidth - (yAxis.right + bBoxWidth)) : (labels.align === 'left' ? yAxis.left : yAxis.left - bBoxWidth);
                    bBoxY = yAxis.top;

                    // Render an invisible bounding box around the y-axis label group
                    // This is where we add mousedown event to start dragging
                    labelGroupBBox = renderer.rect(bBoxX, bBoxY, bBoxWidth, bBoxHeight)
                    .attr({
                        fill: '#fff',
                        opacity: 0,
                        zIndex: 8
                    })
                    .css({
                        cursor: 'ns-resize'
                    })
                    .add();

                    labels.style.cursor = 'ns-resize';

                    addEvent(labelGroupBBox.element, 'mousedown', function (e) {
                        var downYPixels = pointer.normalize(e).chartY;

                        downYValue = yAxis.toValue(downYPixels);    
                        isDragging = true;
                    });

                    addEvent(chart.container, 'mousemove', function (e) {
                        if (isDragging) {
                            body.style.cursor = 'ns-resize';

                            var dragYPixels = chart.pointer.normalize(e).chartY,
                            dragYValue = yAxis.toValue(dragYPixels),

                            extremes = yAxis.getExtremes(),
                            userMin = extremes.userMin,
                            userMax = extremes.userMax,
                            dataMin = extremes.dataMin,
                            dataMax = extremes.dataMax,

                            min = userMin !== undefined ? userMin : dataMin,
                            max = userMax !== undefined ? userMax : dataMax,

                            newMin,
                            newMax;

                            // update max extreme only if dragged from upper portion
                            // update min extreme only if dragged from lower portion
                            if (downYValue > (dataMin + dataMax) / 2) {
                                newMin = min;
                                newMax = max - (dragYValue - downYValue);
                                newMax = newMax > dataMax ? newMax : dataMax; //limit
                            } else {
                                newMin = min - (dragYValue - downYValue);
                                newMin = newMin < dataMin ? newMin : dataMin; //limit
                                newMax = max;
                            }

                            yAxis.setExtremes(newMin, newMax, true, false);
                        }
                    });

                    addEvent(document, 'mouseup', function () {
                        body.style.cursor = 'default';
                        isDragging = false;
                    });

                    // double-click to go back to default range
                    addEvent(labelGroupBBox.element, 'dblclick', function () {
                        yAxis.setExtremes(null, null, true, false);
                    });
                }
            });
        });
        }(Highcharts));
        
    //enable y-Axis panning
    (function (H) {
        'use strict';
        var addEvent = H.addEvent,
        doc = document,
        body = doc.body;

        H.wrap(H.Chart.prototype, 'init', function (proceed) {

            // Run the original proceed method
            proceed.apply(this, Array.prototype.slice.call(arguments, 1));

            var chart = this,
            options = chart.options,
            panning = options.chart.panning || true,
            zoomType = options.chart.zoomType || '',
            container = chart.container,
            yAxis = chart.get('mainAxeValeurs'),
            downYPixels,
            downXPixels,
            downYValue,
            isDragging = false,
            hasDragged = 0;

            if (panning && zoomType === '') {

                addEvent(container, 'mousedown', function (e) {
                    body.style.cursor = 'move';

                    downYPixels = chart.pointer.normalize(e).chartY;
                    downXPixels = chart.pointer.normalize(e).chartX;
                    downYValue = yAxis.toValue(downYPixels);

                    isDragging = ((downXPixels>=chart.plotBox.x)&&(downXPixels<chart.plotBox.x+chart.plotBox.width)&&(downYPixels>=chart.plotBox.y)&&(downYPixels<chart.plotBox.y+chart.plotBox.height)&&chart.annotations.allowZoom);
                });

                addEvent(doc, 'mousemove', function (e) {
                    if (isDragging) {
                        var dragYPixels = chart.pointer.normalize(e).chartY,
                        dragYValue = yAxis.toValue(dragYPixels),

                        yExtremes = yAxis.getExtremes(),

                        yUserMin = yExtremes.userMin,
                        yUserMax = yExtremes.userMax,
                        yDataMin = yExtremes.dataMin,
                        yDataMax = yExtremes.dataMax,

                        yMin = ((yUserMin !== undefined)&&(yUserMin != null)) ? yUserMin : yDataMin,
                        yMax = ((yUserMax !== undefined)&&(yUserMax != null)) ? yUserMax : yDataMax,

                        newMinY,
                        newMaxY;

                        // determine if the mouse has moved more than 10px
                        hasDragged = Math.abs(downYPixels - dragYPixels);

                        if (hasDragged > 10) {

                            newMinY = yMin - (dragYValue - downYValue);
                            newMaxY = yMax - (dragYValue - downYValue);

                            yAxis.setExtremes(newMinY, newMaxY, true, false);
                        }
                    }
                });

                addEvent(doc, 'mouseup', function () {
                    if (isDragging) {
                        isDragging = false;
                    }
                });
            }
        });
    }(Highcharts));
    
    //Define the initial, basic options.
    var options = {
            
        chart: {
            renderTo : inDiv,       
            events : {
                redraw : function(){
                    $.each(aAtFlags,function(periode,aFlag){
                        if($('#periode').val()==periode)
                        {
                            $.each(aFlag,function(periode,flag){
                                if((chart.get('mainAxeValeurs').toPixels(flag[2])-7<chart.plotBox.y)||(chart.get('mainAxeValeurs').toPixels(flag[2])+7>chart.plotBox.y+chart.get('mainAxeValeurs').height)||(chart.xAxis[0].toPixels(flag[1])>chart.xAxis[0].toPixels(chart.xAxis[0].max)))
                                {
                                    $("#label"+flag[0]).attr({opacity: 0});   
                                    $("#text"+flag[0]).attr({opacity: 0});   
                                }
                                else
                                {
                                    $("#text"+flag[0]).attr({
                                        x: Math.max(chart.plotBox.x,chart.xAxis[0].toPixels(flag[1]))+3,  
                                        y: chart.get('mainAxeValeurs').toPixels(flag[2])-3,
                                        opacity: 1
                                    });
                                    
                                    $("#label"+flag[0]).attr({
                                        x: parseFloat($("#text"+flag[0]).attr('x'))-3,
                                        y: parseFloat($("#text"+flag[0]).attr('y'))+2-parseFloat($("#label"+flag[0]).attr('height')),
                                        opacity: 1
                                    }); 
                                }
                            }); 
                        }
                        else
                        {
                            $.each(aFlag,function(periode,flag){
                                $("#label"+flag[0]).attr({opacity: 0});   
                                $("#text"+flag[0]).attr({opacity: 0});
                            });     
                        }
                    });        
                }  
            },
            style :
            {
                fontFamily : 'Arial, Helvetica, Sans-Serif'
            }/*,
            marginRight: 50*/
        },
        
        credits : {
            enabled : false
        },
        
        exporting : {
            enabled : true
        }, 
        
        loading: {
            hideDuration : 250,
            style : {
                backgroundColor : 'gray'
            },
            labelStyle : {
                color : 'white',
                top: '45%'                             
            }
        },
        
        navigator : {
            enabled: true,
            baseSeries : 'valeurs', 
            xAxis : {  
                labels: {
                    style : {
                        color: "black"
                    }
                },
                ordinal: true                
            },
            yAxis : {
                scalable: false
            }
        },  
        
        rangeSelector : configSelectorLong,
        
        annotationsOptions:
        {
            enabledButtons: false       //set first to false or will throw error when options.series contains no series
        },      
                    
        plotOptions: {
            candlestick: {
                color: '#FF0000',        //close<open
                upColor: '#00FF00',      //close>open
                pointPadding: 0.1
            },
            column: {
                color: '#1a324a',        //volume color
            },
            line : {
                color : '#1A324A'               
            },
            series : {
                showInLegend : false,
                connectNulls: true,
                turboThreshold: 0,
                states: {
                    hover: {
                        enabled: false
                    }
                } 
            } 
        },
        
        tooltip: {
            followPointer: false,
            backgroundColor: {
                linearGradient: {
                    x1: 0,
                    y1: 0,
                    x2: 0,
                    y2: 1
                },
                stops: [
                    [0, 'white'],
                    [1, '#EEE']
                ]
            },
            borderColor: 'gray',
            borderWidth: 1,
            borderRadius: 5,
            shared : true,
            headerFormat: '<span style="font-size:12px">{point.key}</span><br><table style="min-width:150px;">',
            footerFormat: '</table>',
            useHTML: true,
            positioner: function(labelWidth,labelHeight,point){
                var xPos = (point.plotX-labelWidth < 0) ? point.plotX + 40 : point.plotX-labelWidth;
                var yPos = Math.min(Math.max(point.plotY,chart.plotTop),chart.plotTop+chart.plotHeight-labelHeight);
                return {x:xPos, y:yPos};
            }                            
        }, 
        
        title : { 
            text : sTitle,
            align : 'left',
            style :{
                fontSize : '12px',                           
                fontWeight: 'bold',
                color : '#6e6e6e'
            },
            x : 10
        },
        
        xAxis:[{
            gridLineWidth: 1,
            gridLineColor: "#ededed",
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            startOnTick : true,
            endOnTick : true,
            labels: {
                style: {
                    color: "black"
                }
            },
            events: {
                afterSetExtremes: function(){
                    if(mouseDown==0&&bChartDrawn){
                        console.log("set");
                    }    
                }
            }            
        },
        {
            lineWidth: 1,
            lineColor: "black",
            offset : 0,
            labels: {
                enabled: false
            }    
        }],
        
        yAxis: [  
        {
            id : 'mainAxeValeurs',
            title: {
                text: '',
            },
            height: '100%',
            gridLineWidth: 1,
            gridLineColor: "#ededed",                    
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            endOnTick: false,
            startOnTick: false,
            labels : {
                align : 'left',
                x : 5,
                style: {
                    color: "black"
                }
            },
            showLastLabel: true,
            opposite: true, 
            offset : 10                         
        },
        {
            id : 'mainAxeValeurs',
            title : null,
            height: '100%',
            lineWidth : 0,
            gridLineWidth: 0,
            linkedTo : 0,
            opposite: false, 
            labels : {
                enabled : false
            },
            offset : 10,
            scalable: false
        },
        {
            id : 'axeVolumes',
            title: null,
            top: '85%',
            height: '0%',
            gridLineWidth: 1,
            gridLineColor: "#ededed",      
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            offset : 10,
            scalable: false,
            labels : {
                align : 'left',
                x : 5,
                style: {
                    color: "black"
                }
            },
            showEmpty : false,
            showLastLabel: true,
            endOnTick: false   
        }]
    };
    
    var chart = new Highcharts.StockChart(options);
                  
    chart.showLoading();
                               
    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        context : document.body,
        async : true,
        data : {codeZB : codeZB, type : "chart", fields: "Date,Open,High,Low,Close"},
        type : 'GET',
        success : function(data)
        {
        var aDataQuote;    
            try
            {
                aDataQuote = JSON.parse(data)    
            }
            catch(e)
            {
                $('#'+inDiv).css('display','none');
                console.log("erreur JSON parse : "+e);
                console.log("data received : "+data);
                return;
            }
            var chartSeries = {                          
                type : sGraphStyle,
                name : sTitle,   
                data : [],//aDataQuote,
                id : 'valeurs',
                yAxis: 'mainAxeValeurs',
                //zIndex : 3,
                tooltip: {
                    pointFormat : tooltipValueFormatOHLC
                },
                dataGrouping: {
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                }
            };
            
            var now = new Date().getTime();
            var i = aDataQuote.length-1; 
            while((i>=0)&&(aDataQuote[i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
            {        
                chartSeries.data.unshift(aDataQuote[i]);
                i--;                
            } 

            var options = chart.options;
            
            //options.annotationsOptions.enabledButtons = true;   //re-enable the annotations buttons
            options.series = [chartSeries];                     //first series is added in options or will throw error with annotations buttons
            aChartSeriesID.push(chartSeries.id);
            
            chart = new Highcharts.StockChart(options);
            
            chart.rangeSelector.clickButton(2,true);
            bChartDrawn = true; 

            $.ajax({url : URL_SERVEUR+'atDataFeed.php',
                context : document.body,
                async : true,
                data : {codeZB : codeZB, type : "volumes"},
                type : 'GET',
                success : function(data)
                {
                    try
                    {
                        aDataQuote = JSON.parse(data)    
                    }
                    catch(e)
                    {
                        $('#'+inDiv).css('display','none');
                        console.log("erreur JSON parse : "+e);
                        console.log("data received : "+data);
                        return;
                    }

                    var volumeSeries = {
                        type : 'column',
                        name : 'Volumes',
                        data : [],//aDataQuote,
                        yAxis: 'axeVolumes',
                        id : 'volumes',
                        tooltip: {
                            pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y}</b></td></tr>'
                        },
                        dataGrouping: {
                            units:[
                                ['day',[1]]
                            ],
                            dateTimeLabelFormats: {
                                day : [dateFormatDay],
                                week: [dateFormatWeek]
                            }
                        }
                    };
                    
                    var now = new Date().getTime();
                    var i = aDataQuote.length-1; 
                    while((i>=0)&&(aDataQuote[i][0]>(now-(3600*24*365*4*1000))))
                    {        
                        volumeSeries.data.unshift(aDataQuote[i]);
                        i--;                
                    }

                    if(aDataQuote.length>0)
                    {
                        chart.addSeries(volumeSeries,true,true);
                        bGotVolumes = true;
                        aChartSeriesID.push(volumeSeries.id);
                        chart.get('axeVolumes').update({
                            height: '15%',
                            tickPixelInterval: chart.plotHeight*(0.1)
                        });
                        chart.get('mainAxeValeurs').update({
                            height : '85%'
                        });
                        chart.xAxis[1].update({
                            offset: -chart.plotHeight*0.15
                        })
                    }
                }
            });
            
            $.ajax({url : URL_SERVEUR+'atDataFeed.php',
                context : document.body,
                async : true,
                data : {codeZB : codeZB, type : "moyennes"},
                type : 'GET',
                success : function(data)
                {
                    try
                    {
                        aDataQuote = JSON.parse(data)    
                    }
                    catch(e)
                    {
                        $('#'+inDiv).css('display','none');
                        console.log("erreur JSON parse : "+e);
                        console.log("data received : "+data);
                        return;
                    }
                    
                    var mma20 = {
                        type : 'line',
                        color : "#0000FF",
                        data : [],//aDataQuote[0], 
                        yAxis: 'mainAxeValeurs',
                        lineWidth: 1,
                        name : 'MMA(20)',
                        id : 'MMA20',
                        tooltip: {
                            pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.4f}</b></td></tr>'
                        },
                        //zIndex : 2,
                        dataGrouping: {
                            units:[
                                ['day',[1]]
                            ],
                            dateTimeLabelFormats: {
                                day : [dateFormatDay],
                                week: [dateFormatWeek]
                            }
                        }
                    };

                    var mma50 = {
                        type : 'line',
                        color : "#FF00FF",
                        data : [],//aDataQuote[1],
                        yAxis: 'mainAxeValeurs',
                        lineWidth: 1,
                        name : 'MMA(50)',
                        id : 'MMA50',
                        tooltip: {
                            pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.4f}</b></td></tr>'
                        },
                        //zIndex : 1,
                        dataGrouping: {
                            units:[
                                ['day',[1]]
                            ],
                            dateTimeLabelFormats: {
                                day : [dateFormatDay],
                                week: [dateFormatWeek]
                            }
                        }
                    };

                    var mma100 = {
                        type : 'line',
                        color : "#FFA500",
                        data : [],//aDataQuote[2],
                        yAxis: 'mainAxeValeurs',
                        lineWidth: 1,
                        name : 'MMA(100)',
                        id : 'MMA100',
                        tooltip: {
                            pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.4f}</b></td></tr>'
                        },
                        //zIndex : 0,
                        dataGrouping: {
                            units:[
                                ['day',[1]]
                            ],
                            dateTimeLabelFormats: {
                                day : [dateFormatDay],
                                week: [dateFormatWeek]
                            }
                        }
                    };  

                    var mma20V = {
                        type : 'line',
                        color : "#0000FF",
                        data : [],//aDataQuote[3], 
                        yAxis: 'axeVolumes',
                        lineWidth: 1,
                        name : 'MMA(20) volumes',
                        id : 'MMA20V',
                        tooltip: {
                            pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.0f}</b></td></tr>'
                        },
                        //zIndex : 2,
                        dataGrouping: {
                            units:[
                                ['day',[1]]
                            ],
                            dateTimeLabelFormats: {
                                day : [dateFormatDay],
                                week: [dateFormatWeek]
                            }
                        }
                    };
                                                            
                    var now = new Date().getTime();
                    var i = aDataQuote[0].length-1; 
                    while((i>=0)&&(aDataQuote[0][i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
                    {
                        mma20.data.unshift(aDataQuote[0][i]);
                        i--;                
                    }
                    
                    var i = aDataQuote[1].length-1; 
                    while((i>=0)&&(aDataQuote[1][i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
                    {
                        mma50.data.unshift(aDataQuote[1][i]);
                        i--;                
                    }
                    
                    var i = aDataQuote[2].length-1; 
                    while((i>=0)&&(aDataQuote[2][i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
                    {
                        mma100.data.unshift(aDataQuote[2][i]); 
                        i--;                
                    }
                    
                    var i = aDataQuote[3].length-1;
                     
                    while((i>=0)&&(aDataQuote[3][i][0]>(now-(3600*24*365*nbAnneeHisto*1000)))&&bGotVolumes)
                    {
                        mma20V.data.unshift(aDataQuote[3][i]);
                        i--;                
                    }
                    
                    aMoyennes['day'] = [mma20.data,mma50.data,mma100.data,mma20V.data];          
                    
                    chart.addSeries(mma20);
                    aChartSeriesID.push(mma20.id);
                    chart.addSeries(mma50);
                    aChartSeriesID.push(mma50.id);
                    chart.addSeries(mma100);
                    aChartSeriesID.push(mma100.id);
                    
                    if(bGotVolumes)
                    {
                        chart.addSeries(mma20V);
                        aChartSeriesID.push(mma20V.id);
                    }
                        
                }
            });
            
            $.ajax({url : URL_SERVEUR+'atDataFeed.php',
                context : document.body,
                async : true,
                data : {type : 'analyses' , codeZB : codeZB, periode : 'DAY'},
                type : 'GET',
                success : function(data)
                {
                    var aDataAT,
                        idLigneInt = 1;
                    try
                    {
                        aDataAT = JSON.parse(data)    
                    }
                    catch(e)
                    {
                        $('#'+inDiv).css('display','none');
                        console.log("erreur JSON parse : "+e);
                        console.log("data received : "+data);
                        return;
                    } 
                    
                    var now = new Date().getTime();   
                    $.each(aDataAT,function(index,aData){
                        if(aData.length == 7)
                        {
                            var trendSeries = {
                                type : 'scatter',
                                color : aData[1],
                                id : aData[0],
                                data : [[Math.max(aData[3],(now-(3600*24*365*nbAnneeHisto*1000))),aData[4]],[Math.max(aData[5],(now-(3600*24*365*nbAnneeHisto*1000))),aData[6]]],
                                yAxis: 'mainAxeValeurs',
                                lineWidth: aData[2],
                                enableMouseTracking : false,
                                //zIndex : 3,
                                marker: {
                                    enabled: false
                                }              
                            };
                            
                            var lastDate = chart.get("valeurs").xData.slice(-1)[0];
                            var a = (aData[6]-aData[4])/(aData[5]-aData[3]);
                            var b = aData[4]-(a*aData[3]);
                            
                            trendSeries.data.push([lastDate,lastDate*a+b]);

                            chart.addSeries(trendSeries);
                            aChartSeriesID.push(trendSeries.id);
                            aAT['day'].push(aData[0]);
                        }
                        else if(aData.length == 6)
                        {
                            var lastDate = chart.get("valeurs").xData.slice(-1)[0];
                            
                            var atSeries = {
                                type : 'scatter',
                                color : aData[1],
                                id : aData[0],
                                data : [[Math.max(aData[3],(now-(3600*24*365*nbAnneeHisto*1000))),aData[4]],[lastDate,aData[4]]],
                                yAxis: 'mainAxeValeurs',
                                lineWidth: aData[2],
                                enableMouseTracking : false,
                                //zIndex : 3,
                                marker: {
                                    enabled: false
                                }   
                            };
                            
                            chart.addSeries(atSeries);
                            aChartSeriesID.push(atSeries.id);
                                                       
                            var opacityVal = ((chart.get('mainAxeValeurs').toPixels(aData[4])-7<chart.plotBox.y)||(chart.get('mainAxeValeurs').toPixels(aData[4])+7>chart.plotBox.y+chart.plotBox.height)) ? 0 : 1;
                            var nbChar = parseInt(Math.log10(aData[4]))+parseInt(aData[5][1]);
                            
                            var textLabel = chart.renderer.text(aData[4].toFixed(parseInt(aData[5][1])),
                                                                Math.max(chart.plotBox.x,chart.xAxis[0].toPixels(aData[3]))+3,
                                                                chart.get('mainAxeValeurs').toPixels(aData[4])-2)
                            .css({
                                fontFamily : 'Tahoma',
                                fontSize: '11px',
                                color: 'white'
                            }).
                            attr({
                                id : 'text'+aData[0],
                                zIndex :4,
                            })
                            .add();
                            
                            chart.renderer.rect(textLabel.getBBox().x-3,
                                                textLabel.getBBox().y-2,
                                                textLabel.getBBox().width+6,
                                                textLabel.getBBox().height,
                                                0)
                            .attr({
                                fill: aData[1],
                                stroke: aData[1],
                                'stroke-width': 1,
                                opacity: opacityVal,
                                zIndex :3,
                                id : 'label'+aData[0]
                            })
                            .add();  
                            
                            aAtFlags['day'].push([aData[0],aData[3],aData[4]]);
                            aAT['day'].push(aData[0]);
                        }
                        else
                        {
                            var lastDate = chart.get("valeurs").xData.slice(-1)[0];
                            
                            var ligneIntSeries = {
                                type : 'scatter',
                                color : 'black',
                                id : "ligneInt"+idLigneInt+"DAY",
                                data : [[Math.max(aData[1],(now-(3600*24*365*nbAnneeHisto*1000))),aData[2]],[lastDate,aData[2]]],
                                yAxis: 'mainAxeValeurs',
                                lineWidth: 1,
                                dashStyle: 'ShortDash',
                                enableMouseTracking : false,
                                //zIndex : 3,
                                marker: {
                                    enabled: false
                                }   
                            };
                               
                            chart.addSeries(ligneIntSeries);
                            aChartSeriesID.push(ligneIntSeries.id);
                            
                            var opacityVal = ((chart.get('mainAxeValeurs').toPixels(aData[2])-7<chart.plotBox.y)||(chart.get('mainAxeValeurs').toPixels(aData[2])+7>chart.plotBox.y+chart.plotBox.height)) ? 0 : 1;
                            var nbChar = parseInt(Math.log10(aData[2]))+parseInt(aData[3][1]);
                            
                            var textLabel = chart.renderer.text(aData[2].toFixed(parseInt(aData[3][1])),
                                                                Math.max(chart.plotBox.x,chart.xAxis[0].toPixels(aData[1]))+3,
                                                                chart.get('mainAxeValeurs').toPixels(aData[2])-2)
                            .css({
                                fontFamily : 'Tahoma',
                                fontSize: '11px',
                                color: 'black'
                            }).
                            attr({
                                id : 'textLigneInt'+idLigneInt+"DAY",
                                zIndex :4,
                            })
                            .add();
                            
                            chart.renderer.rect(textLabel.getBBox().x-3,
                                                textLabel.getBBox().y-2,
                                                textLabel.getBBox().width+6,
                                                textLabel.getBBox().height,
                                                0)
                            .attr({
                                fill: 'white',
                                stroke: 'black',
                                'stroke-width': 1,
                                opacity: opacityVal,
                                zIndex :3,
                                id : 'labelLigneInt'+idLigneInt+"DAY"
                            })
                            .add();  
                            
                            aAtFlags['day'].push(['LigneInt'+idLigneInt+"DAY",aData[1],aData[2]]);
                            aAT['day'].push("ligneInt"+idLigneInt+"DAY");
                            
                            idLigneInt++;    
                        }   
                    });  
                }
            });   
        }
    });
        
    $('#candle').click(function()
    {
        if($(this).attr('selected')!="selected")
        {
            var chart = $("#graphCours").highcharts();
            chart.get('valeurs').update({
                type : 'candlestick',
                color: '#FF0000',
                tooltip: {
                    pointFormat : tooltipValueFormatOHLC
                }
            });
            $('#candle').attr('src',"https://www.zonebourse.com/images/3C_CandleStick_on.gif");
            $('#line').attr('src',"https://www.zonebourse.com/images/3C_Line_of.gif");
            $('#ohlc').attr('src',"https://www.zonebourse.com/images/3C_OHLC_of.gif");

            $('#candle').attr({selected : true});
            $('#line').attr({selected : false});
            $('#ohlc').attr({selected : false});
        }            
    });

    $('#line').click(function()
    {
        if($(this).attr('selected')!="selected")
        {
            var chart = $("#graphCours").highcharts();
            chart.get('valeurs').update({
                type : 'line',
                color : '#1A324A',
                tooltip: {
                    pointFormat : tooltipValueFormatEOD
                }
            });

            $('#candle').attr('src',"https://www.zonebourse.com/images/3C_CandleStick_of.gif");
            $('#line').attr('src',"https://www.zonebourse.com/images/3C_Line_on.gif");
            $('#ohlc').attr('src',"https://www.zonebourse.com/images/3C_OHLC_of.gif");

            $('#candle').attr({selected : false});
            $('#line').attr({selected : true});
            $('#ohlc').attr({selected : false});
        }                
    });

    $('#ohlc').click(function()
    {
        if($(this).attr('selected')!="selected")
        {
            var chart = $("#graphCours").highcharts();
            chart.get('valeurs').update({
                type : 'ohlc',
                color : '#000000',
                tooltip: {
                    pointFormat : tooltipValueFormatOHLC
                }
            });
            $('#candle').attr('src',"https://www.zonebourse.com/images/3C_CandleStick_of.gif");
            $('#line').attr('src',"https://www.zonebourse.com/images/3C_Line_of.gif");
            $('#ohlc').attr('src',"https://www.zonebourse.com/images/3C_OHLC_on.gif");

            $('#candle').attr({selected : false});
            $('#line').attr({selected : false});
            $('#ohlc').attr({selected : true});
        }                 
    });
    
    $('#periode').change(function(p)
    {
        var periode = this.value,
            aSeriesToUpdate = ["valeurs","volumes","MMA20","MMA50","MMA100","MMA20V"];
        $.each(aSeriesToUpdate,function(index,idSeries){
            if(chart.get(idSeries))
            {
                chart.get(idSeries).update({
                    dataGrouping: {
                        units:[
                            [periode,[1]]
                        ]
                    }
                },
                false);
            }    
        });
        if(typeof aMoyennes[periode] === "undefined")
        {
            $.ajax({url : URL_SERVEUR+'atDataFeed.php',
                    context : document.body,
                    async : true,
                    data : {codeZB : codeZB, type : "moyennes", cycle : periode.toUpperCase()+"1"},
                    type : 'GET',
                    success : function(data)
                    {
                        try
                        {
                            aDataQuote = JSON.parse(data)    
                        }
                        catch(e)
                        {
                            $('#'+inDiv).css('display','none');
                            console.log("erreur JSON parse : "+e);
                            console.log("data received : "+data);
                            return;
                        }
                        
                        var now = new Date().getTime();
                        
                        var mma20Data = [],
                            mma50Data = [],
                            mma100Data = [],
                            mma20VData = [];
                            
                        var i = aDataQuote[0].length-1;      
                        while((i>=0)&&(aDataQuote[0][i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
                        {
                            mma20Data.unshift(aDataQuote[0][i]);
                            i--;                
                        }
                        
                        var i = aDataQuote[1].length-1; 
                        while((i>=0)&&(aDataQuote[1][i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
                        {
                            mma50Data.unshift(aDataQuote[1][i]);
                            i--;                
                        }
                        
                        var i = aDataQuote[2].length-1; 
                        while((i>=0)&&(aDataQuote[2][i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
                        {
                            mma100Data.unshift(aDataQuote[2][i]||null); 
                            i--;                
                        }
                        
                        var i = aDataQuote[3].length-1;
                        while((i>=0)&&(aDataQuote[3][i][0]>(now-(3600*24*365*nbAnneeHisto*1000)))&&bGotVolumes)
                        {
                            mma20VData.unshift(aDataQuote[3][i]||null);
                            i--;                
                        }
                        
                        aMoyennes[periode] = [mma20Data,mma50Data,mma100Data,mma20VData];  
                        
                        chart.get("MMA20").update({
                            data : mma20Data
                        },
                        false);
                        chart.get("MMA50").update({
                            data : mma50Data
                        },
                        false);
                        chart.get("MMA100").update({
                            data : mma100Data
                        },
                        false);
                        
                        if(bGotVolumes)
                        {
                            chart.get("MMA20V").update({
                                data : mma20VData
                            },
                            false);
                        }
                        
                        chart.redraw();  
                    }
            });    
        }
        else
         {
            chart.get("MMA20").update({
                data : aMoyennes[periode][0]
            },
            false);
            chart.get("MMA50").update({
                data : aMoyennes[periode][1]
            },
            false);
            chart.get("MMA100").update({
                data : aMoyennes[periode][2]
            },
            false);
            
            if(bGotVolumes)
            {
                chart.get("MMA20V").update({
                    data : aMoyennes[periode][3]
                },
                false);   
            }
                
        }
        
        
        if(aAT[periode].length==0)
        {
            $.ajax({url : URL_SERVEUR+'atDataFeed.php',
                context : document.body,
                async : true,
                data : {type : 'analyses' , codeZB : codeZB, periode : periode.toUpperCase()},
                type : 'GET',
                success : function(data)
                {
                    var aDataAT,
                        idLigneInt = 1;
                    try
                    {
                        aDataAT = JSON.parse(data)    
                    }
                    catch(e)
                    {
                        $('#'+inDiv).css('display','none');
                        console.log("erreur JSON parse : "+e);
                        console.log("data received : "+data);
                        return;
                    }
                    var now = new Date().getTime();
                    $.each(aDataAT,function(index,aData){
                        if(aData.length == 7)
                        {
                            var trendSeries = {
                                type : 'scatter',
                                color : aData[1],
                                id : aData[0],
                                data : [[Math.max(aData[3],(now-(3600*24*365*nbAnneeHisto*1000))),aData[4]],[Math.max(aData[5],(now-(3600*24*365*nbAnneeHisto*1000))),aData[6]]],
                                yAxis: 'mainAxeValeurs',
                                lineWidth: aData[2],
                                enableMouseTracking : false,
                                //zIndex : 3,
                                marker: {
                                    enabled: false
                                }              
                            };
                            
                            var lastDate = chart.get("valeurs").xData.slice(-1)[0];
                            var a = (aData[6]-aData[4])/(aData[5]-aData[3]);
                            var b = aData[4]-(a*aData[3]);
                            
                            trendSeries.data.push([lastDate,lastDate*a+b]);

                            chart.addSeries(trendSeries);
                            aChartSeriesID.push(trendSeries.id);
                            aAT[periode].push(aData[0]);   
                               
                        }
                        else if(aData.length == 6)
                        {
                            var lastDate = chart.get("valeurs").xData.slice(-1)[0];
                            
                            var atSeries = {
                                type : 'scatter',
                                color : aData[1],
                                id : aData[0],
                                data : [[Math.max(aData[3],(now-(3600*24*365*nbAnneeHisto*1000))),aData[4]],[lastDate,aData[4]]],
                                yAxis: 'mainAxeValeurs',
                                lineWidth: aData[2],
                                enableMouseTracking : false,
                                //zIndex : 3,
                                marker: {
                                    enabled: false
                                }   
                            };
                            
                            chart.addSeries(atSeries);
                            aChartSeriesID.push(atSeries.id);
                                                       
                            var opacityVal = ((chart.get('mainAxeValeurs').toPixels(aData[4])-7<chart.plotBox.y)||(chart.get('mainAxeValeurs').toPixels(aData[4])+7>chart.plotBox.y+chart.plotBox.height)) ? 0 : 1;
                            var nbChar = parseInt(Math.log10(aData[4]))+parseInt(aData[5][1]);
                            
                            var textLabel = chart.renderer.text(aData[4].toFixed(parseInt(aData[5][1])),
                                                                Math.max(chart.plotBox.x,chart.xAxis[0].toPixels(aData[3]))+3,
                                                                chart.get('mainAxeValeurs').toPixels(aData[4])-2)
                            .css({
                                fontFamily : 'Tahoma',
                                fontSize: '11px',
                                color: 'white'
                            }).
                            attr({
                                id : 'text'+aData[0],
                                zIndex :4,
                            })
                            .add();
                            
                            chart.renderer.rect(textLabel.getBBox().x-3,
                                                textLabel.getBBox().y-2,
                                                textLabel.getBBox().width+6,
                                                textLabel.getBBox().height,
                                                0)
                            .attr({
                                fill: aData[1],
                                stroke: aData[1],
                                'stroke-width': 1,
                                opacity: opacityVal,
                                zIndex :3,
                                id : 'label'+aData[0]
                            })
                            .add();  
                            
                            aAtFlags[periode].push([aData[0],aData[3],aData[4]]);
                            aAT[periode].push(aData[0]);
                        }
                        else
                        {
                            var lastDate = chart.get("valeurs").xData.slice(-1)[0];
                            
                            var ligneIntSeries = {
                                type : 'scatter',
                                color : 'black',
                                id : "ligneInt"+idLigneInt+periode.toUpperCase(),
                                data : [[Math.max(aData[1],(now-(3600*24*365*nbAnneeHisto*1000))),aData[2]],[lastDate,aData[2]]],
                                yAxis: 'mainAxeValeurs',
                                lineWidth: 1,
                                dashStyle: 'ShortDash',
                                enableMouseTracking : false,
                                //zIndex : 3,
                                marker: {
                                    enabled: false
                                }   
                            };
                               
                            chart.addSeries(ligneIntSeries);
                            aChartSeriesID.push(ligneIntSeries.id);
                            
                            var opacityVal = ((chart.get('mainAxeValeurs').toPixels(aData[2])-7<chart.plotBox.y)||(chart.get('mainAxeValeurs').toPixels(aData[2])+7>chart.plotBox.y+chart.plotBox.height)) ? 0 : 1;
                            var nbChar = parseInt(Math.log10(aData[2]))+parseInt(aData[3][1]);
                            
                            var textLabel = chart.renderer.text(aData[2].toFixed(parseInt(aData[3][1])),
                                                                Math.max(chart.plotBox.x,chart.xAxis[0].toPixels(aData[1]))+3,
                                                                chart.get('mainAxeValeurs').toPixels(aData[2])-2)
                            .css({
                                fontFamily : 'Tahoma',
                                fontSize: '11px',
                                color: 'black'
                            }).
                            attr({
                                id : 'textLigneInt'+idLigneInt+periode.toUpperCase(),
                                zIndex :4,
                            })
                            .add();
                            
                            chart.renderer.rect(textLabel.getBBox().x-3,
                                                textLabel.getBBox().y-2,
                                                textLabel.getBBox().width+6,
                                                textLabel.getBBox().height,
                                                0)
                            .attr({
                                fill: 'white',
                                stroke: 'black',
                                'stroke-width': 1,
                                opacity: opacityVal,
                                zIndex :3,
                                id : 'labelLigneInt'+idLigneInt+periode.toUpperCase()
                            })
                            .add();  
                            
                            aAtFlags[periode].push(['LigneInt'+idLigneInt+periode.toUpperCase(),aData[1],aData[2]]);
                            aAT[periode].push("ligneInt"+idLigneInt+periode.toUpperCase());
                            
                            idLigneInt++;    
                        }   
                    });  
                }
            });   
        }  
         
        $.each(aAT['day'],function(index,id){
            chart.get(id).update({
                visible: periode=="day"   
            },
            false);    
        });
        $.each(aAT['week'],function(index,id){
            chart.get(id).update({
                visible: periode=="week"   
            },
            false);    
        });   
            
        chart.redraw();                                     
    });
        
    $('#logScale').change(function()
    {
        
        var newType = (this.checked) ? 'logarithmic' : 'linear';  
        chart.get('mainAxeValeurs').update({
            type: newType
        },true);
     });
        
}             

function drawGraphATMini(codeZB,inDiv,sTitle,sGraphStyle,nbDecimals)
{ 
    animated = true; 
    //make yAxis scalable by default
    (function (H) {
        'use strict';
        var addEvent = H.addEvent,
        each = H.each,
        doc = document,
        body = doc.body;

        H.wrap(H.Chart.prototype, 'init', function (proceed) {

            // Run the original proceed method
            proceed.apply(this, Array.prototype.slice.call(arguments, 1));

            var chart = this,
            renderer = chart.renderer,
            yAxis = chart.yAxis;

            each(yAxis, function (yAxis) {
                var options = yAxis.options,
                scalable = options.scalable === undefined ? true : options.scalable,
                labels = options.labels,
                pointer = chart.pointer,
                labelGroupBBox,
                bBoxX,
                bBoxY,
                bBoxWidth,
                bBoxHeight,
                isDragging = false,
                downYValue;

                if (scalable) {
                    bBoxWidth = 40;
                    bBoxHeight = chart.containerHeight - yAxis.top - yAxis.bottom;
                    bBoxX = yAxis.opposite ? (labels.align === 'left' ? chart.containerWidth - yAxis.right : chart.containerWidth - (yAxis.right + bBoxWidth)) : (labels.align === 'left' ? yAxis.left : yAxis.left - bBoxWidth);
                    bBoxY = yAxis.top;

                    // Render an invisible bounding box around the y-axis label group
                    // This is where we add mousedown event to start dragging
                    labelGroupBBox = renderer.rect(bBoxX, bBoxY, bBoxWidth, bBoxHeight)
                    .attr({
                        fill: '#fff',
                        opacity: 0,
                        zIndex: 8
                    })
                    .css({
                        cursor: 'ns-resize'
                    })
                    .add();

                    labels.style.cursor = 'ns-resize';

                    addEvent(labelGroupBBox.element, 'mousedown', function (e) {
                        var downYPixels = pointer.normalize(e).chartY;

                        downYValue = yAxis.toValue(downYPixels);    
                        isDragging = true;
                    });

                    addEvent(chart.container, 'mousemove', function (e) {
                        if (isDragging) {
                            body.style.cursor = 'ns-resize';

                            var dragYPixels = chart.pointer.normalize(e).chartY,
                            dragYValue = yAxis.toValue(dragYPixels),

                            extremes = yAxis.getExtremes(),
                            userMin = extremes.userMin,
                            userMax = extremes.userMax,
                            dataMin = extremes.dataMin,
                            dataMax = extremes.dataMax,

                            min = userMin !== undefined ? userMin : dataMin,
                            max = userMax !== undefined ? userMax : dataMax,

                            newMin,
                            newMax;

                            // update max extreme only if dragged from upper portion
                            // update min extreme only if dragged from lower portion
                            if (downYValue > (dataMin + dataMax) / 2) {
                                newMin = min;
                                newMax = max - (dragYValue - downYValue);
                                newMax = newMax > dataMax ? newMax : dataMax; //limit
                            } else {
                                newMin = min - (dragYValue - downYValue);
                                newMin = newMin < dataMin ? newMin : dataMin; //limit
                                newMax = max;
                            }

                            yAxis.setExtremes(newMin, newMax, true, false);
                        }
                    });

                    addEvent(document, 'mouseup', function () {
                        body.style.cursor = 'default';
                        isDragging = false;
                    });

                    // double-click to go back to default range
                    addEvent(labelGroupBBox.element, 'dblclick', function () {
                        yAxis.setExtremes(null, null, true, false);
                    });
                }
            });
        });
        }(Highcharts));
        
    //enable y-Axis panning
    (function (H) {
        'use strict';
        var addEvent = H.addEvent,
        doc = document,
        body = doc.body;

        H.wrap(H.Chart.prototype, 'init', function (proceed) {

            // Run the original proceed method
            proceed.apply(this, Array.prototype.slice.call(arguments, 1));

            var chart = this,
            options = chart.options,
            panning = options.chart.panning || true,
            zoomType = options.chart.zoomType || '',
            container = chart.container,
            yAxis = chart.get('mainAxeValeurs'),
            downYPixels,
            downXPixels,
            downYValue,
            isDragging = false,
            hasDragged = 0;

            if (panning && zoomType === '') {

                addEvent(container, 'mousedown', function (e) {
                    body.style.cursor = 'move';

                    downYPixels = chart.pointer.normalize(e).chartY;
                    downXPixels = chart.pointer.normalize(e).chartX;
                    downYValue = yAxis.toValue(downYPixels);

                    isDragging = ((downXPixels>=chart.plotBox.x)&&(downXPixels<chart.plotBox.x+chart.plotBox.width)&&(downYPixels>=chart.plotBox.y)&&(downYPixels<chart.plotBox.y+chart.plotBox.height)&&chart.annotations.allowZoom);
                });

                addEvent(doc, 'mousemove', function (e) {
                    if (isDragging) {
                        var dragYPixels = chart.pointer.normalize(e).chartY,
                        dragYValue = yAxis.toValue(dragYPixels),

                        yExtremes = yAxis.getExtremes(),

                        yUserMin = yExtremes.userMin,
                        yUserMax = yExtremes.userMax,
                        yDataMin = yExtremes.dataMin,
                        yDataMax = yExtremes.dataMax,

                        yMin = ((yUserMin !== undefined)&&(yUserMin != null)) ? yUserMin : yDataMin,
                        yMax = ((yUserMax !== undefined)&&(yUserMax != null)) ? yUserMax : yDataMax,

                        newMinY,
                        newMaxY;

                        // determine if the mouse has moved more than 10px
                        hasDragged = Math.abs(downYPixels - dragYPixels);

                        if (hasDragged > 10) {

                            newMinY = yMin - (dragYValue - downYValue);
                            newMaxY = yMax - (dragYValue - downYValue);

                            yAxis.setExtremes(newMinY, newMaxY, true, false);
                        }
                    }
                });

                addEvent(doc, 'mouseup', function () {
                    if (isDragging) {
                        isDragging = false;
                    }
                });
            }
        });
    }(Highcharts));   
    
    //axis labels for crosshairs
    /* 
    // configuration and defaults :
    // enabled -> bool / false,
    // fontSize -> String / '11px',
    // fontFamily -> String / 'Arial',
    // fontColor -> String / 'black' <=> "#000000",
    // backgroundColor -> String / "#FFFFFF",
    // borderColor -> String / 'black' <=> "#000000",
    // borderWidth -> int / 1,
    // yAxisLinked -> array / [0],
    // xAxisLinked -> array / [0],
    // yValueDecimals -> array / [0],  if yAxisLinked > yValueDecimals complete yValueDecimals with 0
    // xValueDecimals -> array / [0]   if xAxisLinked > xValueDecimals complete xValueDecimals with 0
    //
    */
    (function (H) {
        'use strict';
        var addEvent = H.addEvent,
            doc = document,
            body = doc.body,
            formatIfNeeded = function(value,axis,nbDec)
            {
                var categories = axis.categories,
                    numericSymbols = chart.options.lang.numericSymbols,
                    i = numericSymbols && numericSymbols.length,
                    multi,
                    ret,
                    nbDec = (typeof nbDec === "undefined") ? 0 : nbDec,
                    // make sure the same symbol is added for all labels on a linear axis
                    numericSymbolDetector = axis.isLog ? value : axis.tickInterval;

                if(i && numericSymbolDetector >= 1000 && !categories) {
                    // Decide whether we should add a numeric symbol like k (thousands) or M (millions).
                    // If we are to enable this in tooltip or other places as well, we can move this
                    // logic to the numberFormatter and enable it by a parameter.
                    while (i-- && (typeof ret === "undefined")) {
                        multi = Math.pow(1000, i + 1);
                        if (numericSymbolDetector >= multi && numericSymbols[i] !== null) {
                            ret = (value / multi).toFixedDown(nbDec) + numericSymbols[i];
                        }
                    }
                }

                if (typeof ret === "undefined")
                    ret = false;
                    
                return ret;
            };

        H.wrap(H.Chart.prototype, 'init', function (proceed) {

            // Run the original proceed method
            proceed.apply(this, Array.prototype.slice.call(arguments, 1));

            var chart = this,
                options = chart.options,
                panning = options.chart.panning || true,
                zoomType = options.chart.zoomType || '',
                container = chart.container,
                yAxis = chart.get('mainAxeValeurs'),
                yPixels,
                xPixels,
                configuration = options.crosshairsLabels||{},
                enabled = configuration.enabled||false,
                fontSize = configuration.fontSize||'11px',
                fontFamily = configuration.fontFamily || 'Arial',
                fontColor = configuration.fontColor || 'black',
                backgroundColor = configuration.backgroundColor||"#FFFFFF",
                borderColor = configuration.borderColor||"black",
                borderWidth = (typeof configuration.borderWidth ==="undefined") ? 1 : configuration.borderWidth,
                yAxisLinked = configuration.yAxisLinked || [0],
                xAxisLinked = configuration.xAxisLinked || [0],
                yValueDecimals = configuration.yValueDecimals || [0],
                xValueDecimals = configuration.xValueDecimals || [0];
                
            if(yAxisLinked.length>yValueDecimals.length)
            {
                do
                {
                    yValueDecimals.push(0);       
                }
                while(yAxisLinked.length>yValueDecimals.length)
            }
            
            if(xAxisLinked.length>xValueDecimals.length)
            {
                do
                {
                    xValueDecimals.push(0);       
                }
                while(xAxisLinked.length>xValueDecimals.length)
            }
            
            if(enabled)
            {
                var yLabel = chart.renderer.text(
                    "Temp",
                    chart.plotBox.width+chart.plotBox.x+20+6,
                    0
                )
                .css({
                    fontFamily : fontFamily,
                    fontSize: fontSize,
                    color: fontColor
                }).
                attr({
                    id : 'yLabel',
                    opacity: 0,
                })
                .add();
                
                //sampleDate.getDate()+' '+aMonths[sampleDate.getMonth()]+' '+sampleDate.getFullYear()
                var xLabel = chart.renderer.text(
                    "Temp",
                    0,
                    chart.plotBox.height+chart.plotBox.y+3
                )
                .css({
                    fontFamily : fontFamily,
                    fontSize: fontSize,
                    color: fontColor
                }).
                attr({
                    id : 'xLabel',
                    opacity: 0,
                })
                .add();
                
                var yBox = chart.renderer.rect(
                    yLabel.getBBox().x-3,
                    yLabel.getBBox().y-2,
                    yLabel.getBBox().width+6,
                    yLabel.getBBox().height+4,
                    0)
                .attr({
                    fill: backgroundColor,
                    stroke: borderColor,
                    'stroke-width': borderWidth,
                    opacity: 0,
                    id : 'yBox'
                })
                .add();
                
                var xBox = chart.renderer.rect(
                    xLabel.getBBox().x-3,
                    xLabel.getBBox().y-2,
                    xLabel.getBBox().width+6,
                    xLabel.getBBox().height+4,
                    0)
                .attr({
                    fill: backgroundColor,
                    stroke: borderColor,
                    'stroke-width': borderWidth,
                    opacity: 0,
                    id : 'xBox'
                })
                .add();                                                                                             
                      
                addEvent(chart.container, 'mousemove', function (e)
                {
                    yPixels = chart.pointer.normalize(e).chartY;
                    xPixels = chart.pointer.normalize(e).chartX;
                    
                    yBox.toFront();
                    xBox.toFront();
                    yLabel.toFront();
                    xLabel.toFront();
                    
                    if((yPixels>chart.plotBox.y)&&(yPixels<chart.plotBox.y+chart.plotBox.height)&&(xPixels>chart.plotBox.x)&&(xPixels<chart.plotBox.x+chart.plotBox.width))
                    {
                        $.each(yAxisLinked,function(index,axis){
                            if((yPixels>chart.yAxis[axis].top)&&(yPixels<chart.yAxis[axis].top+chart.yAxis[axis].height))
                            {
                                var yLabelText = formatIfNeeded(chart.yAxis[axis].toValue(yPixels),chart.yAxis[axis],yValueDecimals[axis]);
                                yLabelText = (yLabelText) ? yLabelText : Math.floor(chart.yAxis[axis].toValue(yPixels) * Math.pow(10,yValueDecimals[axis])) / Math.pow(10,yValueDecimals[axis]);
                                
                                yLabel.attr({
                                    text: yLabelText,
                                    opacity: 1 
                                });
                                yBox.attr({
                                    width: yLabel.getBBox().width+6,
                                    x: chart.plotBox.x + chart.plotBox.width, 
                                    y: yPixels-(yBox.attr('height')/2),
                                    opacity: 1
                                });
                                yLabel.attr({
                                    y: yBox.attr('y')+parseInt(fontSize)+1,
                                    x: yBox.attr('x')+3 
                                });
                                return false;    
                            }
                            else
                            {
                                yBox.attr({
                                    opacity: 0
                                });
                                yLabel.attr({
                                    opacity: 0
                                });    
                            }   
                        });
                        
                        //Adjust xPixels' value to fit the hoverPoint
                        //xPixels = chart.xAxis[0].toPixels(chart.hoverPoints[0].x);
                        
                        $.each(xAxisLinked,function(index,axis){
                            if((xPixels>chart.xAxis[axis].left)&&(xPixels<chart.xAxis[axis].left+chart.xAxis[axis].width))
                            {
                                var xLabelText;
                                if(chart.xAxis[axis].options.type=="datetime")
                                {
                                    var newDate = new Date(chart.xAxis[axis].toValue(xPixels));
                                    xLabelText = newDate.getDate()+' '+aMonths[newDate.getMonth()]+' '+newDate.getFullYear();    
                                }
                                else
                                {
                                    xLabelText = Math.floor(chart.xAxis[axis].toValue(xPixels) * Math.pow(10,xValueDecimals[axis])) / Math.pow(10,xValueDecimals[axis]);   
                                }
                                
                                
                                xLabel.attr({
                                    text: xLabelText,
                                    y: chart.plotBox.height+chart.plotBox.y+parseInt(fontSize)+3+2, //bollow plotBox + fontSize + margin + padding
                                    opacity: 1 
                                });  
                                xBox.attr({
                                    width: xLabel.getBBox().width+6,
                                    opacity: 1
                                });
                                xBox.attr({
                                    x: xPixels-(xBox.attr('width')/2),
                                    y: chart.plotBox.height+chart.plotBox.y+3
                                });
                                xLabel.attr({
                                    x: xBox.attr('x')+3
                                });
                                
                                return false;
                            }
                            else
                            {
                                xBox.attr({
                                    opacity: 0
                                });
                                xLabel.attr({
                                    opacity: 0
                                });    
                            }
                            
                        });
                    }
                    else
                    {
                        yBox.attr({
                            opacity: 0
                        });
                        xBox.attr({
                            opacity: 0
                        });
                        yLabel.attr({
                            opacity: 0
                        });
                        xLabel.attr({
                            opacity: 0
                        });    
                    } 
                });
            }
        });
    }(Highcharts));
    
    //Define the initial, basic options.
    var options = {
            
        chart: {
            renderTo : inDiv,       
            events : {
                redraw : function(){
                    $.each(aAtFlags,function(periode,aFlag){
                        if($('#periode').val()==periode)
                        {
                            $.each(aFlag,function(periode,flag){
                                if((chart.get('mainAxeValeurs').toPixels(flag[2])-7<chart.plotBox.y)||(chart.get('mainAxeValeurs').toPixels(flag[2])+7>chart.plotBox.y+chart.get('mainAxeValeurs').height)||(chart.xAxis[0].toPixels(flag[1])>chart.xAxis[0].toPixels(chart.xAxis[0].max)))
                                {
                                    $("#label"+flag[0]).attr({opacity: 0});   
                                    $("#text"+flag[0]).attr({opacity: 0});   
                                }
                                else
                                {
                                    $("#text"+flag[0]).attr({
                                        x: Math.max(chart.plotBox.x,chart.xAxis[0].toPixels(flag[1]))+3,  
                                        y: chart.get('mainAxeValeurs').toPixels(flag[2])-3,
                                        opacity: 1
                                    });
                                    
                                    $("#label"+flag[0]).attr({
                                        x: parseFloat($("#text"+flag[0]).attr('x'))-3,
                                        y: parseFloat($("#text"+flag[0]).attr('y'))+2-parseFloat($("#label"+flag[0]).attr('height')),
                                        opacity: 1
                                    }); 
                                }
                            }); 
                        }
                        else
                        {
                            $.each(aFlag,function(periode,flag){
                                $("#label"+flag[0]).attr({opacity: 0});   
                                $("#text"+flag[0]).attr({opacity: 0});
                            });     
                        }
                    });        
                }  
            },
            style :
            {
                fontFamily : 'Arial, Helvetica, Sans-Serif'
            }/*,
            marginRight: 50*/
        },
        
        credits : {
            enabled : false
        },
        
        exporting : {
            enabled : false
        }, 
        
        loading: {
            hideDuration : 250,
            style : {
                backgroundColor : 'gray'
            },
            labelStyle : {
                color : 'white',
                top: '45%'                             
            }
        },
        
        navigator : {
            enabled: true,
            baseSeries : 'valeurs', 
            xAxis : {  
                labels: {
                    style : {
                        color: "black"
                    }
                },
                ordinal: true                
            },
            yAxis : {
                scalable: false
            }
        },  
        
        rangeSelector : configSelectorLong,
        
        annotationsOptions:
        {
            enabledButtons: false       //set first to false or will throw error when options.series contains no series
        },      
                    
        plotOptions: {
            candlestick: {
                color: '#FF0000',        //close<open
                upColor: '#00FF00',      //close>open
                pointPadding: 0.1
            },
            column: {
                color: '#1a324a',        //volume color
            },
            line : {
                color : '#1A324A'               
            },
            series : {
                showInLegend : false,
                connectNulls: true,
                turboThreshold: 0,
                states: {
                    hover: {
                        enabled: false
                    }
                } 
            } 
        },
        
        tooltip: {
            enabled: false                            
        }, 
        
        title : { 
            text : sTitle,
            align : 'left',
            style :{
                fontSize : '12px',                           
                fontWeight: 'bold',
                color : '#6e6e6e'
            },
            x : 10
        },
        
        xAxis:[{
            gridLineWidth: 1,
            gridLineColor: "#ededed",
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            startOnTick : true,
            endOnTick : true,
            labels: {
                style: {
                    color: "black"
                }
            },
            events: {
                afterSetExtremes: function(){
                    if(mouseDown==0&&bChartDrawn){
                        console.log("set");
                    }    
                }
            }            
        },
        {
            lineWidth: 1,
            lineColor: "black",
            offset : 0,
            labels: {
                enabled: false
            }    
        }],
        
        yAxis: [  
        {
            id : 'mainAxeValeurs',
            title: {
                text: '',
            },
            height: '100%',
            gridLineWidth: 1,
            gridLineColor: "#ededed",                    
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            endOnTick: false,
            startOnTick: false,
            labels : {
                align : 'left',
                x : 5,
                style: {
                    color: "black"
                }
            },
            showLastLabel: true,
            opposite: true, 
            offset : 10,
            endOnTick: false,   
            crosshair: {
                snap: false
            }                           
        },
        {
            id : 'axeVolumes',
            title: null,
            top: '85%',
            height: '0%',
            gridLineWidth: 1,
            gridLineColor: "#ededed",      
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            offset : 10,
            scalable: false,
            labels : {
                align : 'left',
                x : 5,
                style: {
                    color: "black"
                }
            },
            showEmpty : false,
            showLastLabel: true,
            endOnTick: false,   
            crosshair: {
                snap: false
            }   
        }
        ], 
        
        crosshairsLabels: {
            enabled: true,
            fontSize: '11px',
            fontFamily : 'Tahoma',
            backgroundColor: "#FFEE00",
            borderColor: "black",
            borderWidth: 1,
            yValueDecimals : [nbDecimals,nbDecimals,1], //volume axis is the 3rd axis  
            yAxisLinked : [0,2],
            xAxisLinked : [0]
        }
    };
    
    var chart = new Highcharts.StockChart(options);
                  
    chart.showLoading();
    
    if(true)
    {
        $.ajax({url : URL_SERVEUR+'atDataFeed.php',
            context : document.body,
            async : true,
            data : {codeZB : codeZB, type : "chart", fields: "Date,Open,High,Low,Close"},
            type : 'GET',
            success : function(data)
            { 
                var aDataQuote;    
                try
                {
                    aDataQuote = JSON.parse(data)    
                }
                catch(e)
                {
                    $('#'+inDiv).css('display','none');
                    console.log("erreur JSON parse : "+e);
                    console.log("data received : "+data);
                    return;
                }
                
                var chartSeries = {                          
                    type : sGraphStyle,
                    name : sTitle,   
                    data : [],//aDataQuote,
                    id : 'valeurs',
                    yAxis: 'mainAxeValeurs',
                    //zIndex : 3,
                    tooltip: {
                        pointFormat : tooltipValueFormatOHLC
                    },
                    dataGrouping: {
                        units:[
                            ['day',[1]]
                        ],
                        dateTimeLabelFormats: {
                            day : [dateFormatDay],
                            week: [dateFormatWeek]
                        }
                    }
                };
                
                var now = new Date().getTime();
                var i = aDataQuote.length-1; 
                while((i>=0)&&(aDataQuote[i]["x"]>(now-(3600*24*365*nbAnneeHisto*1000))))
                {        
                    chartSeries.data.unshift(aDataQuote[i]);
                    i--;                
                }
                
                bChartDrawn = true;
                chart.hideLoading();
                
                chart.addSeries(chartSeries,true,true);
                
                chart.rangeSelector.clickButton(2,true);
                        
               
            }
        });
    }
    //old vertion
    //addVolumes(codeZB,inDiv,animated);
     /*getMMAdata(codeZB,inDiv,'day',function()
                {                    
                    var mma20 = {
                        type : 'line',
                        color : "#0000FF",
                        data : aMoyennes['day'][0], 
                        yAxis: 'mainAxeValeurs',
                        xAxis: 0,
                        lineWidth: 1,
                        name : 'MMA(20)',
                        id : 'MMA20',
                        tooltip: {
                            pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.4f}</b></td></tr>'
                        },
                        //zIndex : 2,
                        dataGrouping: {
                            units:[
                                ['day',[1]]
                            ],
                            dateTimeLabelFormats: {
                                day : [dateFormatDay],
                                week: [dateFormatWeek]
                            }
                        },
                        visible: $('#mmaButton').prop('checked')
                    };
                    var mma50 = {
                        type : 'line',
                        color : "#FF00FF",
                        data : aMoyennes['day'][1],
                        yAxis: 'mainAxeValeurs',
                        xAxis: 0,
                        lineWidth: 1,
                        name : 'MMA(50)',
                        id : 'MMA50',
                        tooltip: {
                            pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.4f}</b></td></tr>'
                        },
                        //zIndex : 1,
                        dataGrouping: {
                            units:[
                                ['day',[1]]
                            ],
                            dateTimeLabelFormats: {
                                day : [dateFormatDay],
                                week: [dateFormatWeek]
                            }
                        },
                        visible: $('#mmaButton').prop('checked')
                    };

                    var mma100 = {
                        type : 'line',
                        color : "#FFA500",
                        data : aMoyennes['day'][2],
                        yAxis: 'mainAxeValeurs',
                        xAxis: 0,
                        lineWidth: 1,
                        name : 'MMA(100)',
                        id : 'MMA100',
                        tooltip: {
                            pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.4f}</b></td></tr>'
                        },
                        //zIndex : 0,
                        dataGrouping: {
                            units:[
                                ['day',[1]]
                            ],
                            dateTimeLabelFormats: {
                                day : [dateFormatDay],
                                week: [dateFormatWeek]
                            }
                        },
                        visible: $('#mmaButton').prop('checked')
                    };  

                    var mma20V = {
                        type : 'line',
                        color : "#0000FF",
                        data : aMoyennes['day'][3],
                        yAxis: 'axeVolumes',
                        xAxis: 0,
                        lineWidth: 1,
                        name : 'MMA(20) volumes',
                        id : 'MMA20V',
                        tooltip: {
                            pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.0f}</b></td></tr>'
                        },
                        //zIndex : 2,
                        dataGrouping: {
                            units:[
                                ['day',[1]]
                            ],
                            dateTimeLabelFormats: {
                                day : [dateFormatDay],
                                week: [dateFormatWeek]
                            }
                        },
                        visible: $('#mmaButton').prop('checked')
                    };
                    
                    chart.addSeries(mma20,false);
                    aChartSeriesID.push(mma20.id);
                    chart.addSeries(mma50,false);
                    aChartSeriesID.push(mma50.id);
                    chart.addSeries(mma100,!bGotVolumes);
                    aChartSeriesID.push(mma100.id);
                    
                    if(bGotVolumes)
                    {
                        chart.addSeries(mma20V,true);
                        aChartSeriesID.push(mma20V.id);
                    }
                });*/
        
}

function drawGraphCours(codeZB,externcode,name,inDiv,sGraphStyle,nbDecimals,aWords,animated)
{      
    //make yAxis scalable by default
    (function (H) {
        'use strict';
        var addEvent = H.addEvent,
        each = H.each,
        doc = document,
        body = doc.body;

        H.wrap(H.Chart.prototype, 'init', function (proceed) {

            // Run the original proceed method
            proceed.apply(this, Array.prototype.slice.call(arguments, 1));

            var chart = this,
            renderer = chart.renderer,
            yAxis = chart.yAxis;

            each(yAxis, function (yAxis) {
                var options = yAxis.options,
                scalable = options.scalable === undefined ? true : options.scalable,
                labels = options.labels,
                pointer = chart.pointer,
                labelGroupBBox,
                bBoxX,
                bBoxY,
                bBoxWidth,
                bBoxHeight,
                isDragging = false,
                downYValue;

                if (scalable) {
                    bBoxWidth = 40;
                    bBoxHeight = chart.containerHeight - yAxis.top - yAxis.bottom;
                    bBoxX = yAxis.opposite ? (labels.align === 'left' ? chart.containerWidth - yAxis.right : chart.containerWidth - (yAxis.right + bBoxWidth)) : (labels.align === 'left' ? yAxis.left : yAxis.left - bBoxWidth);
                    bBoxY = yAxis.top;

                    // Render an invisible bounding box around the y-axis label group
                    // This is where we add mousedown event to start dragging
                    labelGroupBBox = renderer.rect(bBoxX, bBoxY, bBoxWidth, bBoxHeight)
                    .attr({
                        fill: '#fff',
                        opacity: 0,
                        zIndex: 8
                    })
                    .css({
                        cursor: 'ns-resize'
                    })
                    .add();

                    labels.style.cursor = 'ns-resize';

                    addEvent(labelGroupBBox.element, 'mousedown', function (e) {
                        var downYPixels = pointer.normalize(e).chartY;

                        downYValue = yAxis.toValue(downYPixels);    
                        isDragging = true;
                    });

                    addEvent(chart.container, 'mousemove', function (e) {
                        if (isDragging) {
                            body.style.cursor = 'ns-resize';

                            var dragYPixels = chart.pointer.normalize(e).chartY,
                            dragYValue = yAxis.toValue(dragYPixels),

                            extremes = yAxis.getExtremes(),
                            userMin = extremes.userMin,
                            userMax = extremes.userMax,
                            dataMin = extremes.dataMin,
                            dataMax = extremes.dataMax,

                            min = userMin !== undefined ? userMin : dataMin,
                            max = userMax !== undefined ? userMax : dataMax,

                            newMin,
                            newMax;

                            // update max extreme only if dragged from upper portion
                            // update min extreme only if dragged from lower portion
                            if (downYValue > (dataMin + dataMax) / 2) {
                                newMin = min;
                                newMax = max - (dragYValue - downYValue);
                                newMax = newMax > dataMax ? newMax : dataMax; //limit
                            } else {
                                newMin = min - (dragYValue - downYValue);
                                newMin = newMin < dataMin ? newMin : dataMin; //limit
                                newMax = max;
                            }

                            yAxis.setExtremes(newMin, newMax, true, false);
                        }
                    });

                    addEvent(document, 'mouseup', function () {
                        body.style.cursor = 'default';
                        isDragging = false;
                    });

                    // double-click to go back to default range
                    addEvent(labelGroupBBox.element, 'dblclick', function () {
                        yAxis.setExtremes(null, null, true, false);
                    });
                }
            });
        });
        }(Highcharts));
        
    //enable y-Axis panning
    (function (H) {
        'use strict';
        var addEvent = H.addEvent,
        doc = document,
        body = doc.body;

        H.wrap(H.Chart.prototype, 'init', function (proceed) {

            // Run the original proceed method
            proceed.apply(this, Array.prototype.slice.call(arguments, 1));

            var chart = this,
            options = chart.options,
            panning = options.chart.panning || true,
            zoomType = options.chart.zoomType || '',
            container = chart.container,
            yAxis = chart.get('mainAxeValeurs'),
            downYPixels,
            downXPixels,
            downYValue,
            isDragging = false,
            hasDragged = 0,
            zoomAllowed = (typeof chart.annotationsOptions === "undefined") ? true : chart.annotations.allowZoom;

            if (panning && zoomType === '') {

                addEvent(container, 'mousedown', function (e) {
                    body.style.cursor = 'move';

                    downYPixels = chart.pointer.normalize(e).chartY;
                    downXPixels = chart.pointer.normalize(e).chartX;
                    downYValue = yAxis.toValue(downYPixels);

                    isDragging = ((downXPixels>=chart.plotBox.x)&&(downXPixels<chart.plotBox.x+chart.plotBox.width)&&(downYPixels>=chart.plotBox.y)&&(downYPixels<chart.plotBox.y+chart.plotBox.height)&&zoomAllowed);
                });

                addEvent(doc, 'mousemove', function (e) {
                    if (isDragging) {
                        var dragYPixels = chart.pointer.normalize(e).chartY,
                        dragYValue = yAxis.toValue(dragYPixels),

                        yExtremes = yAxis.getExtremes(),

                        yUserMin = yExtremes.userMin,
                        yUserMax = yExtremes.userMax,
                        yDataMin = yExtremes.dataMin,
                        yDataMax = yExtremes.dataMax,

                        yMin = ((yUserMin !== undefined)&&(yUserMin != null)) ? yUserMin : yDataMin,
                        yMax = ((yUserMax !== undefined)&&(yUserMax != null)) ? yUserMax : yDataMax,

                        newMinY,
                        newMaxY;

                        // determine if the mouse has moved more than 10px
                        hasDragged = Math.abs(downYPixels - dragYPixels);

                        if (hasDragged > 10) {

                            newMinY = yMin - (dragYValue - downYValue);
                            newMaxY = yMax - (dragYValue - downYValue);

                            yAxis.setExtremes(newMinY, newMaxY, true, false);
                        }
                    }
                });

                addEvent(doc, 'mouseup', function () {
                    if (isDragging) {
                        isDragging = false;
                    }
                });
            }
        });
    }(Highcharts));
    
    //axis labels for crosshairs
    /* 
    // configuration and defaults :
    // enabled -> bool / false,
    // fontSize -> String / '11px',
    // fontFamily -> String / 'Arial',
    // fontColor -> String / 'black' <=> "#000000",
    // backgroundColor -> String / "#FFFFFF",
    // borderColor -> String / 'black' <=> "#000000",
    // borderWidth -> int / 1,
    // yAxisLinked -> array / [0],
    // xAxisLinked -> array / [0],
    // yValueDecimals -> array / [0],  if yAxisLinked > yValueDecimals complete yValueDecimals with 0
    // xValueDecimals -> array / [0]   if xAxisLinked > xValueDecimals complete xValueDecimals with 0
    //
    */
    (function (H) {
        'use strict';
        var addEvent = H.addEvent,
            doc = document,
            body = doc.body,
            formatIfNeeded = function(value,axis,nbDec)
            {
                var categories = axis.categories,
                    numericSymbols = chart.options.lang.numericSymbols,
                    i = numericSymbols && numericSymbols.length,
                    multi,
                    ret,
                    nbDec = (typeof nbDec === "undefined") ? 0 : nbDec,
                    // make sure the same symbol is added for all labels on a linear axis
                    numericSymbolDetector = axis.isLog ? value : axis.tickInterval;

                if(i && numericSymbolDetector >= 1000 && !categories) {
                    // Decide whether we should add a numeric symbol like k (thousands) or M (millions).
                    // If we are to enable this in tooltip or other places as well, we can move this
                    // logic to the numberFormatter and enable it by a parameter.
                    while (i-- && (typeof ret === "undefined")) {
                        multi = Math.pow(1000, i + 1);
                        if (numericSymbolDetector >= multi && numericSymbols[i] !== null) {
                            ret = (value / multi).toFixedDown(nbDec) + numericSymbols[i];
                        }
                    }
                }

                if (typeof ret === "undefined")
                    ret = false;
                    
                return ret;
            };

        H.wrap(H.Chart.prototype, 'init', function (proceed) {

            // Run the original proceed method
            proceed.apply(this, Array.prototype.slice.call(arguments, 1));

            var chart = this,
                options = chart.options,
                panning = options.chart.panning || true,
                zoomType = options.chart.zoomType || '',
                container = chart.container,
                yAxis = chart.get('mainAxeValeurs'),
                yPixels,
                xPixels,
                configuration = options.crosshairsLabels||{},
                enabled = configuration.enabled||false,
                fontSize = configuration.fontSize||'11px',
                fontFamily = configuration.fontFamily || 'Arial',
                fontColor = configuration.fontColor || 'black',
                backgroundColor = configuration.backgroundColor||"#FFFFFF",
                borderColor = configuration.borderColor||"black",
                borderWidth = (typeof configuration.borderWidth ==="undefined") ? 1 : configuration.borderWidth,
                yAxisLinked = configuration.yAxisLinked || [0],
                xAxisLinked = configuration.xAxisLinked || [0],
                yValueDecimals = configuration.yValueDecimals || [0],
                xValueDecimals = configuration.xValueDecimals || [0];
                
            if(yAxisLinked.length>yValueDecimals.length)
            {
                do
                {
                    yValueDecimals.push(0);       
                }
                while(yAxisLinked.length>yValueDecimals.length)
            }
            
            if(xAxisLinked.length>xValueDecimals.length)
            {
                do
                {
                    xValueDecimals.push(0);       
                }
                while(xAxisLinked.length>xValueDecimals.length)
            }
            
            if(enabled)
            {
                var yLabel = chart.renderer.text(
                    "Temp",
                    chart.plotBox.width+chart.plotBox.x+20+6,
                    0
                )
                .css({
                    fontFamily : fontFamily,
                    fontSize: fontSize,
                    color: fontColor
                }).
                attr({
                    id : 'yLabel',
                    opacity: 0,
                })
                .add();
                
                //sampleDate.getDate()+' '+aMonths[sampleDate.getMonth()]+' '+sampleDate.getFullYear()
                var xLabel = chart.renderer.text(
                    "Temp",
                    0,
                    chart.plotBox.height+chart.plotBox.y+3
                )
                .css({
                    fontFamily : fontFamily,
                    fontSize: fontSize,
                    color: fontColor
                }).
                attr({
                    id : 'xLabel',
                    opacity: 0,
                })
                .add();
                
                var yBox = chart.renderer.rect(
                    yLabel.getBBox().x-3,
                    yLabel.getBBox().y-2,
                    yLabel.getBBox().width+6,
                    yLabel.getBBox().height+4,
                    0)
                .attr({
                    fill: backgroundColor,
                    stroke: borderColor,
                    'stroke-width': borderWidth,
                    opacity: 0,
                    id : 'yBox'
                })
                .add();
                
                var xBox = chart.renderer.rect(
                    xLabel.getBBox().x-3,
                    xLabel.getBBox().y-2,
                    xLabel.getBBox().width+6,
                    xLabel.getBBox().height+4,
                    0)
                .attr({
                    fill: backgroundColor,
                    stroke: borderColor,
                    'stroke-width': borderWidth,
                    opacity: 0,
                    id : 'xBox'
                })
                .add();                                                                                             
                      
                addEvent(chart.container, 'mousemove', function (e)
                {
                    yPixels = chart.pointer.normalize(e).chartY;
                    xPixels = chart.pointer.normalize(e).chartX;
                    
                    yBox.toFront();
                    xBox.toFront();
                    yLabel.toFront();
                    xLabel.toFront();
                    
                    if((yPixels>chart.plotBox.y)&&(yPixels<chart.plotBox.y+chart.plotBox.height)&&(xPixels>chart.plotBox.x)&&(xPixels<chart.plotBox.x+chart.plotBox.width))
                    {
                        $.each(yAxisLinked,function(index,axis){
                            if((yPixels>chart.yAxis[axis].top)&&(yPixels<chart.yAxis[axis].top+chart.yAxis[axis].height))
                            {
                                var yLabelText = formatIfNeeded(chart.yAxis[axis].toValue(yPixels),chart.yAxis[axis],yValueDecimals[axis]);
                                yLabelText = (yLabelText) ? yLabelText : Math.floor(chart.yAxis[axis].toValue(yPixels) * Math.pow(10,yValueDecimals[axis])) / Math.pow(10,yValueDecimals[axis]);
                                
                                yLabel.attr({
                                    text: yLabelText,
                                    opacity: 1 
                                });
                                yBox.attr({
                                    width: yLabel.getBBox().width+6,
                                    x: chart.plotBox.x + chart.plotBox.width, 
                                    y: yPixels-(yBox.attr('height')/2),
                                    opacity: 1
                                });
                                yLabel.attr({
                                    y: yBox.attr('y')+parseInt(fontSize)+1,
                                    x: yBox.attr('x')+3 
                                });
                                return false;    
                            }
                            else
                            {
                                yBox.attr({
                                    opacity: 0
                                });
                                yLabel.attr({
                                    opacity: 0
                                });    
                            }   
                        });
                        
                        //Adjust xPixels' value to fit the hoverPoint
                        //xPixels = chart.xAxis[0].toPixels(chart.hoverPoints[0].x);
                        
                        $.each(xAxisLinked,function(index,axis){
                            if((xPixels>chart.xAxis[axis].left)&&(xPixels<chart.xAxis[axis].left+chart.xAxis[axis].width))
                            {
                                var xLabelText;
                                if(chart.xAxis[axis].options.type=="datetime")
                                {
                                    var newDate = new Date(chart.xAxis[axis].toValue(xPixels));
                                    xLabelText = newDate.getDate()+' '+aMonths[newDate.getMonth()]+' '+newDate.getFullYear();    
                                }
                                else
                                {
                                    xLabelText = Math.floor(chart.xAxis[axis].toValue(xPixels) * Math.pow(10,xValueDecimals[axis])) / Math.pow(10,xValueDecimals[axis]);   
                                }
                                
                                
                                xLabel.attr({
                                    text: xLabelText,
                                    y: chart.plotBox.height+chart.plotBox.y+parseInt(fontSize)+3+2, //bollow plotBox + fontSize + margin + padding
                                    opacity: 1 
                                });  
                                xBox.attr({
                                    width: xLabel.getBBox().width+6,
                                    opacity: 1
                                });
                                xBox.attr({
                                    x: xPixels-(xBox.attr('width')/2),
                                    y: chart.plotBox.height+chart.plotBox.y+3
                                });
                                xLabel.attr({
                                    x: xBox.attr('x')+3
                                });
                                
                                return false;
                            }
                            else
                            {
                                xBox.attr({
                                    opacity: 0
                                });
                                xLabel.attr({
                                    opacity: 0
                                });    
                            }
                            
                        });
                    }
                    else
                    {
                        yBox.attr({
                            opacity: 0
                        });
                        xBox.attr({
                            opacity: 0
                        });
                        yLabel.attr({
                            opacity: 0
                        });
                        xLabel.attr({
                            opacity: 0
                        });    
                    } 
                });
            }
        });
    }(Highcharts));
    
    animated = (typeof animated === "undefined") ? false : animated;
    
    tooltipValueFormatOHLC = tooltipValueFormatOHLC.replace(/%toReplace%/ig,nbDecimals);
    tooltipValueFormatEOD = tooltipValueFormatEOD.replace(/%toReplace%/ig,nbDecimals);
    
    //Define the initial, basic options.
    var options = {
            
        chart: {
            renderTo : inDiv,
            events: {
                load: function(){                         
                    var imageHeight = 25;
                    var imageWidth = 240;
                    
                    this.renderer.image("https://www.zonebourse.com/images/pdf_Report/"+aWords[0].capitalize()+".png",35,55,imageWidth,imageHeight).css({opacity: 0.5}).attr({zIndex: 2}).add();
                },
                redraw : function(){
                    $.each(aAtFlags,function(periode,aFlag){
                        if($('#periode').val()==periode)
                        {
                            $.each(aFlag,function(periode,flag){
                                if((chart.get('mainAxeValeurs').toPixels(flag[2])-7<chart.plotBox.y)||(chart.get('mainAxeValeurs').toPixels(flag[2])+7>chart.plotBox.y+chart.get('mainAxeValeurs').height)||(chart.xAxis[0].toPixels(flag[1])>chart.xAxis[0].toPixels(chart.xAxis[0].max)))
                                {
                                    $("#label"+flag[0]).attr({opacity: 0});   
                                    $("#text"+flag[0]).attr({opacity: 0});   
                                }
                                else
                                {
                                    $("#label"+flag[0]).attr({
                                        x: Math.max(chart.plotBox.x,chart.xAxis[0].toPixels(flag[1])),
                                        y: chart.get('mainAxeValeurs').toPixels(flag[2])-7,
                                        opacity: 1
                                    });
                                    $("#text"+flag[0]).attr({
                                        x: parseFloat($("#label"+flag[0]).attr('x'))+3,  
                                        y: parseFloat($("#label"+flag[0]).attr('y'))+12,
                                        opacity: 1
                                    }); 
                                }
                            }); 
                        }
                        else
                        {
                            $.each(aFlag,function(periode,flag){
                                $("#label"+flag[0]).attr({opacity: 0});   
                                $("#text"+flag[0]).attr({opacity: 0});
                            });     
                        }
                    });        
                }  
            },
            style :
            {
                fontFamily : 'Arial, Helvetica, Sans-Serif'
            },
            marginRight: 70
        },
        
        credits : {
            enabled : true,         
            href : null,
            text : '\u00A9'+aWords[0],
            style : {
                fontSize : '12px'               
            } 
        },
        
        exporting : {
            enabled : true,
            buttons: {
                contextButton: {
                    theme: {
                        fill: "#004EFF",
                        states: {
                            hover: {
                                fill: '#004EFF'
                            },
                            select: {
                                fill: '#004EFF'
                            }
                        }                                                
                    },
                    symbolStroke: "white",
                    symbolStrokeWidth: 2,
                    menuItems: [{
                        textKey: "printChart",
                        onclick: function (){this.print()}
                    },
                    {
                        separator: true
                    },
                    {
                        textKey: "downloadPNG",
                        onclick: function (){this.exportChart()}   
                    },
                    {
                        textKey: "downloadJPEG",
                        onclick: function (){this.exportChart({type:"image/jpeg"})}   
                    },
                    {
                        textKey: "downloadSVG",
                        onclick: function (){this.exportChart({type:"image/svg+xml"})}   
                    }]
                }
            }
        }, 
        
        navigator : {
            baseSeries : 'valeurs', 
            xAxis : {  
                labels: {
                    style : {
                        color: "black"
                    }
                },
                ordinal: true                
            },
            yAxis : {
                scalable: false
            }
        },  
        
        rangeSelector : configSelectorLong,   
                    
        plotOptions: {
            candlestick: {
                color: '#FF0000',        //close<open
                upColor: '#00FF00',      //close>open
                pointPadding: 0.1
            },
            column: {
                color: '#1a324a',        //volume color
            },
            line : {
                color : '#1A324A'               
            },
            series : {
                showInLegend : false,
                connectNulls: true,
                turboThreshold: 0,
                marker: {
                    enabled: false
                },
                states: {
                    hover: {
                        lineWidth: 1
                    }
                } 
            } 
        },
        
        tooltip: {
            followPointer: false,
            backgroundColor: {
                linearGradient: {
                    x1: 0,
                    y1: 0,
                    x2: 0,
                    y2: 1
                },
                stops: [
                    [0, 'white'],
                    [1, '#EEE']
                ]
            },
            borderColor: 'gray',
            borderWidth: 1,
            borderRadius: 5,
            shared : true,
            split: false,
            headerFormat: '<span style="font-size:12px">{point.key}</span><br><table style="min-width:150px;">',
            footerFormat: '</table>',
            useHTML: true,
            positioner: function(labelWidth,labelHeight,point){
                var xPos = (point.plotX-labelWidth < 0) ? point.plotX + 40 : point.plotX-labelWidth;
                var yPos = Math.min(Math.max(point.plotY,chart.plotTop),chart.plotTop+chart.plotHeight-labelHeight);
                return {x:xPos, y:yPos};
            },
            crosshairs: [true,true]                           
        }, 
        
        title : { 
            text : null
        },
        
        xAxis:[{
            gridLineWidth: 1,
            gridLineColor: "#ededed",
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black', 
            labels: {
                style: {
                    color: "black"
                }
            }         
        },
        {
            lineWidth: 1,
            lineColor: "black",                                                                         
            linkedTo: 0,
            tickWidth: 0,
            tickLength: 0,
            labels: {
                enabled: false
            },
            offset : 0  
        }],
        
        yAxis: [  
        {
            id : 'mainAxeValeurs',
            title: {
                text: '',
            },
            height: '100%',
            type: ($("#logScale").prop("checked")) ? 'logarithmic' : 'linear',
            gridLineWidth: 1,
            gridLineColor: "#ededed",                    
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            endOnTick: false,
            startOnTick: false,
            labels : {
                align : 'left',
                x : 5,
                style: {
                    color: "black"
                }
            },
            showLastLabel: true,
            opposite: true, 
            offset : 20,
            crosshair: {
                snap: false
            }
        },
        {
            id : 'axeVolumes',
            title: null,
            top: '85%',
            height: '0%',
            gridLineWidth: 1,
            gridLineColor: "#ededed",
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            offset : 20,
            scalable: false,
            labels : {
                align : 'left',
                x : 5,
                style: {
                    color: "black"
                }
            },
            showEmpty : false,
            showLastLabel: true,
            endOnTick: false,
            crosshair: {
                snap: false
            }   
        }],
        
        crosshairsLabels: {
            enabled: true,
            fontSize: '11px',
            fontFamily : 'Tahoma',
            backgroundColor: "#FFEE00",
            borderColor: "black",
            borderWidth: 1,
            yValueDecimals : [nbDecimals,nbDecimals,1], //volume axis is the 3rd axis  
            yAxisLinked : [0,2],
            xAxisLinked : [0]
        }
    };
    
    var chart = new Highcharts.StockChart(options);
                  
    chart.showLoading();
    
    addQuotes(codeZB,name,inDiv,animated,function()
    {
        bChartDrawn = true;
        chart.hideLoading();
        
        addVolumes(codeZB,inDiv,animated);
    
        chart.rangeSelector.clickButton(2,true);
                
        getMMAdata(codeZB,inDiv,'day',function()
        {                    
            var mma20 = {
                type : 'line',
                color : "#0000FF",
                data : aMoyennes['day'][0], 
                yAxis: 'mainAxeValeurs',
                xAxis: 0,
                lineWidth: 1,
                name : 'MMA(20)',
                id : 'MMA20',
                tooltip: {
                    pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.4f}</b></td></tr>'
                },
                //zIndex : 2,
                dataGrouping: {
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                },
                visible: $('#mmaButton').prop('checked')
            };
            var mma50 = {
                type : 'line',
                color : "#FF00FF",
                data : aMoyennes['day'][1],
                yAxis: 'mainAxeValeurs',
                xAxis: 0,
                lineWidth: 1,
                name : 'MMA(50)',
                id : 'MMA50',
                tooltip: {
                    pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.4f}</b></td></tr>'
                },
                //zIndex : 1,
                dataGrouping: {
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                },
                visible: $('#mmaButton').prop('checked')
            };

            var mma100 = {
                type : 'line',
                color : "#FFA500",
                data : aMoyennes['day'][2],
                yAxis: 'mainAxeValeurs',
                xAxis: 0,
                lineWidth: 1,
                name : 'MMA(100)',
                id : 'MMA100',
                tooltip: {
                    pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.4f}</b></td></tr>'
                },
                //zIndex : 0,
                dataGrouping: {
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                },
                visible: $('#mmaButton').prop('checked')
            };  
            
            var mma20V = {
                type : 'line',
                color : "#0000FF",
                data : aMoyennes['day'][3],
                yAxis: 'axeVolumes',
                xAxis: 0,
                lineWidth: 1,
                name : 'MMA(20) volumes',
                id : 'MMA20V',
                tooltip: {
                    pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.0f}</b></td></tr>'
                },
                //zIndex : 2,
                dataGrouping: {
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                },
                visible: $('#mmaButton').prop('checked')
            };
            
            chart.addSeries(mma20,false);
            aChartSeriesID.push(mma20.id);
            chart.addSeries(mma50,false);
            aChartSeriesID.push(mma50.id);
            chart.addSeries(mma100,!bGotVolumes);
            aChartSeriesID.push(mma100.id);
            
            if(bGotVolumes)
            {
                chart.addSeries(mma20V,true);
                aChartSeriesID.push(mma20V.id);
            }
        });
        
        getMMAdata(codeZB,inDiv,'week');
        
        /*refreshLastData(codeZB,externcode,inDiv);
        setInterval(function () {refreshLastData(codeZB,externcode,inDiv)},5000);*/
    });    
}

function addQuotes(codeZB,name,inDiv,animated,callback)
{
    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        context : document.body,
        async : true,
        data : {codeZB : codeZB, type : "chart", fields: "Date,Open,High,Low,Close"},
        type : 'GET',
        success : function(data)
        {
        var aDataQuote;    
            try
            {
                aDataQuote = JSON.parse(data)    
            }
            catch(e)
            {
                $('#'+inDiv).css('display','none');
                console.log("erreur JSON parse : "+e);
                console.log("data received : "+data);
                return;
            }
            var chartSeries = {                          
                type : 'candlestick',
                name : name,   
                data : [],//aDataQuote,
                id : 'valeurs',
                yAxis: 'mainAxeValeurs',
                //zIndex : 3,
                tooltip: {
                    pointFormat : tooltipValueFormatOHLC
                },
                dataGrouping: {
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                }
            };
            
            var now = new Date().getTime();
            var i = aDataQuote.length-1; 
            while((i>=0)&&(aDataQuote[i]['x']>(now-(3600*24*365*nbAnneeHisto*1000))))
            {        
                chartSeries.data.unshift(aDataQuote[i]);
                i--;              
            }
            
            var chart = $("#"+inDiv).highcharts();
            chart.addSeries(chartSeries,true,true);
            aChartSeriesID.push(chartSeries.id);
             
            if(typeof callback == "function") callback();
        }
    });   
}

function addVolumes(codeZB,inDiv,animated,callback)
{
    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        context : document.body,
        async : true,
        data : {codeZB : codeZB, type : "volumes"},
        type : 'GET',
        success : function(data)
        {
            try
            {
                aDataQuote = JSON.parse(data)    
            }
            catch(e)
            {
                $('#'+inDiv).css('display','none');
                console.log("erreur JSON parse : "+e);
                console.log("data received : "+data);
                return;
            }

            var volumeSeries = {
                type : 'column',
                name : 'Volumes',
                data : [],//aDataQuote,
                yAxis: 'axeVolumes',
                id : 'volumes',
                tooltip: {
                    pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y}</b></td></tr>'
                },
                dataGrouping: {
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                }
            };

            var now = new Date().getTime();
            var i = aDataQuote.length-1; 
            while((i>=0)&&(aDataQuote[i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
            {        
                volumeSeries.data.unshift(aDataQuote[i]);
                i--;                
            }

            if(aDataQuote.length>0)
            {
                var chart = $("#"+inDiv).highcharts();
                bGotVolumes = true;
                chart.get('axeVolumes').update({
                    height: '15%',
                    tickPixelInterval: chart.plotHeight*(0.1)
                });
                chart.get('mainAxeValeurs').update({
                    height : '85%'
                });
                chart.xAxis[1].update({
                    offset: -chart.plotHeight*0.15
                });
                chart.addSeries(volumeSeries,true,true);
                aChartSeriesID.push(volumeSeries.id);
            }
            
            if(typeof callback == "function") callback();
        }
    });
}

function getMMAdata(codeZB,inDiv,periode,callback)
{
    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        context : document.body,
        async : true,
        data : {codeZB : codeZB, type : "moyennes", cycle : periode.toUpperCase()+"1"},
        type : 'GET',
        success : function(data)
        {
            try
            {
                aDataQuote = JSON.parse(data)    
            }
            catch(e)
            {
                $('#'+inDiv).css('display','none');
                console.log("erreur JSON parse : "+e);
                console.log("data received : "+data);
                return;
            }
            
            var mma20Data = [],
                mma50Data = [],
                mma100Data = [],
                mma20VData = [];
                                                    
            var now = new Date().getTime();
            var i = aDataQuote[0].length-1; 
            while((i>=0)&&(aDataQuote[0][i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
            {
                mma20Data.unshift(aDataQuote[0][i]);
                i--;                
            }
            
            var i = aDataQuote[1].length-1; 
            while((i>=0)&&(aDataQuote[1][i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
            {
                mma50Data.unshift(aDataQuote[1][i]);
                i--;                
            }
            
            var i = aDataQuote[2].length-1; 
            while((i>=0)&&(aDataQuote[2][i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
            {
                mma100Data.unshift(aDataQuote[2][i]); 
                i--;                
            }
            
            var i = aDataQuote[3].length-1;
             
            while((i>=0)&&(aDataQuote[3][i][0]>(now-(3600*24*365*nbAnneeHisto*1000)))&&bGotVolumes)
            {
                mma20VData.unshift(aDataQuote[3][i]);
                i--;                
            }
            
            aMoyennes[periode] = [mma20Data,mma50Data,mma100Data,mma20VData];
            
            if(typeof callback == "function") callback();               
        }
    }); 
}

function drawGraphInv(codeZB,name,inDiv,sGraphStyle,nbDecimals,aWords,animated)
{  
    //make yAxis scalable by default
    (function (H) {
        'use strict';
        var addEvent = H.addEvent,
        each = H.each,
        doc = document,
        body = doc.body;

        H.wrap(H.Chart.prototype, 'init', function (proceed) {

            // Run the original proceed method
            proceed.apply(this, Array.prototype.slice.call(arguments, 1));

            var chart = this,
            renderer = chart.renderer,
            yAxis = chart.yAxis;

            each(yAxis, function (yAxis) {
                var options = yAxis.options,
                scalable = options.scalable === undefined ? true : options.scalable,
                labels = options.labels,
                pointer = chart.pointer,
                labelGroupBBox,
                bBoxX,
                bBoxY,
                bBoxWidth,
                bBoxHeight,
                isDragging = false,
                downYValue;

                if (scalable) {
                    bBoxWidth = 40;
                    bBoxHeight = chart.containerHeight - yAxis.top - yAxis.bottom;
                    bBoxX = yAxis.opposite ? (labels.align === 'left' ? chart.containerWidth - yAxis.right : chart.containerWidth - (yAxis.right + bBoxWidth)) : (labels.align === 'left' ? yAxis.left : yAxis.left - bBoxWidth);
                    bBoxY = yAxis.top;

                    // Render an invisible bounding box around the y-axis label group
                    // This is where we add mousedown event to start dragging
                    labelGroupBBox = renderer.rect(bBoxX, bBoxY, bBoxWidth, bBoxHeight)
                    .attr({
                        fill: '#fff',
                        opacity: 0,
                        zIndex: 8
                    })
                    .css({
                        cursor: 'ns-resize'
                    })
                    .add();

                    labels.style.cursor = 'ns-resize';

                    addEvent(labelGroupBBox.element, 'mousedown', function (e) {
                        var downYPixels = pointer.normalize(e).chartY;

                        downYValue = yAxis.toValue(downYPixels);    
                        isDragging = true;
                    });

                    addEvent(chart.container, 'mousemove', function (e) {
                        if (isDragging) {
                            body.style.cursor = 'ns-resize';

                            var dragYPixels = chart.pointer.normalize(e).chartY,
                            dragYValue = yAxis.toValue(dragYPixels),

                            extremes = yAxis.getExtremes(),
                            userMin = extremes.userMin,
                            userMax = extremes.userMax,
                            dataMin = extremes.dataMin,
                            dataMax = extremes.dataMax,

                            min = userMin !== undefined ? userMin : dataMin,
                            max = userMax !== undefined ? userMax : dataMax,

                            newMin,
                            newMax;

                            // update max extreme only if dragged from upper portion
                            // update min extreme only if dragged from lower portion
                            if (downYValue > (dataMin + dataMax) / 2) {
                                newMin = min;
                                newMax = max - (dragYValue - downYValue);
                                newMax = newMax > dataMax ? newMax : dataMax; //limit
                            } else {
                                newMin = min - (dragYValue - downYValue);
                                newMin = newMin < dataMin ? newMin : dataMin; //limit
                                newMax = max;
                            }

                            yAxis.setExtremes(newMin, newMax, true, false);
                        }
                    });

                    addEvent(document, 'mouseup', function () {
                        body.style.cursor = 'default';
                        isDragging = false;
                    });

                    // double-click to go back to default range
                    addEvent(labelGroupBBox.element, 'dblclick', function () {
                        yAxis.setExtremes(null, null, true, false);
                    });
                }
            });
        });
        }(Highcharts));
        
    //enable y-Axis panning
    (function (H) {
        'use strict';
        var addEvent = H.addEvent,
        doc = document,
        body = doc.body;

        H.wrap(H.Chart.prototype, 'init', function (proceed) {

            // Run the original proceed method
            proceed.apply(this, Array.prototype.slice.call(arguments, 1));

            var chart = this,
            options = chart.options,
            panning = options.chart.panning || true,
            zoomType = options.chart.zoomType || '',
            container = chart.container,
            yAxis = chart.get('mainAxeValeurs'),
            downYPixels,
            downXPixels,
            downYValue,
            isDragging = false,
            hasDragged = 0,
            zoomAllowed = (typeof chart.annotationsOptions === "undefined") ? true : chart.annotations.allowZoom;

            if (panning && zoomType === '') {

                addEvent(container, 'mousedown', function (e) {
                    body.style.cursor = 'move';

                    downYPixels = chart.pointer.normalize(e).chartY;
                    downXPixels = chart.pointer.normalize(e).chartX;
                    downYValue = yAxis.toValue(downYPixels);

                    isDragging = ((downXPixels>=chart.plotBox.x)&&(downXPixels<chart.plotBox.x+chart.plotBox.width)&&(downYPixels>=chart.plotBox.y)&&(downYPixels<chart.plotBox.y+chart.plotBox.height)&&zoomAllowed);
                });

                addEvent(doc, 'mousemove', function (e) {
                    if (isDragging) {
                        var dragYPixels = chart.pointer.normalize(e).chartY,
                        dragYValue = yAxis.toValue(dragYPixels),

                        yExtremes = yAxis.getExtremes(),

                        yUserMin = yExtremes.userMin,
                        yUserMax = yExtremes.userMax,
                        yDataMin = yExtremes.dataMin,
                        yDataMax = yExtremes.dataMax,

                        yMin = ((yUserMin !== undefined)&&(yUserMin != null)) ? yUserMin : yDataMin,
                        yMax = ((yUserMax !== undefined)&&(yUserMax != null)) ? yUserMax : yDataMax,

                        newMinY,
                        newMaxY;

                        // determine if the mouse has moved more than 10px
                        hasDragged = Math.abs(downYPixels - dragYPixels);

                        if (hasDragged > 10) {

                            newMinY = yMin - (dragYValue - downYValue);
                            newMaxY = yMax - (dragYValue - downYValue);

                            yAxis.setExtremes(newMinY, newMaxY, true, false);
                        }
                    }
                });

                addEvent(doc, 'mouseup', function () {
                    if (isDragging) {
                        isDragging = false;
                    }
                });
            }
        });
    }(Highcharts));
    
    //axis labels for crosshairs
    /* 
    // configuration and defaults :
    // enabled -> bool / false,
    // fontSize -> String / '11px',
    // fontFamily -> String / 'Arial',
    // fontColor -> String / 'black' <=> "#000000",
    // backgroundColor -> String / "#FFFFFF",
    // borderColor -> String / 'black' <=> "#000000",
    // borderWidth -> int / 1,
    // yAxisLinked -> array / [0],
    // xAxisLinked -> array / [0],
    // yValueDecimals -> array / [0],  if yAxisLinked > yValueDecimals complete yValueDecimals with 0
    // xValueDecimals -> array / [0]   if xAxisLinked > xValueDecimals complete xValueDecimals with 0
    //
    */
    (function (H) {
        'use strict';
        var addEvent = H.addEvent,
            doc = document,
            body = doc.body,
            formatIfNeeded = function(value,axis,nbDec)
            {
                var categories = axis.categories,
                    numericSymbols = chart.options.lang.numericSymbols,
                    i = numericSymbols && numericSymbols.length,
                    multi,
                    ret,
                    nbDec = (typeof nbDec === "undefined") ? 0 : nbDec,
                    // make sure the same symbol is added for all labels on a linear axis
                    numericSymbolDetector = axis.isLog ? value : axis.tickInterval;

                if(i && numericSymbolDetector >= 1000 && !categories) {
                    // Decide whether we should add a numeric symbol like k (thousands) or M (millions).
                    // If we are to enable this in tooltip or other places as well, we can move this
                    // logic to the numberFormatter and enable it by a parameter.
                    while (i-- && (typeof ret === "undefined")) {
                        multi = Math.pow(1000, i + 1);
                        if (numericSymbolDetector >= multi && numericSymbols[i] !== null) {
                            ret = (value / multi).toFixedDown(nbDec) + numericSymbols[i];
                        }
                    }
                }

                if (typeof ret === "undefined")
                    ret = false;
                    
                return ret;
            };

        H.wrap(H.Chart.prototype, 'init', function (proceed) {

            // Run the original proceed method
            proceed.apply(this, Array.prototype.slice.call(arguments, 1));

            var chart = this,
                options = chart.options,
                panning = options.chart.panning || true,
                zoomType = options.chart.zoomType || '',
                container = chart.container,
                yAxis = chart.get('mainAxeValeurs'),
                yPixels,
                xPixels,
                configuration = options.crosshairsLabels||{},
                enabled = configuration.enabled||false,
                fontSize = configuration.fontSize||'11px',
                fontFamily = configuration.fontFamily || 'Arial',
                fontColor = configuration.fontColor || 'black',
                backgroundColor = configuration.backgroundColor||"#FFFFFF",
                borderColor = configuration.borderColor||"black",
                borderWidth = (typeof configuration.borderWidth ==="undefined") ? 1 : configuration.borderWidth,
                yAxisLinked = configuration.yAxisLinked || [0],
                xAxisLinked = configuration.xAxisLinked || [0],
                yValueDecimals = configuration.yValueDecimals || [0],
                xValueDecimals = configuration.xValueDecimals || [0];
                
            if(yAxisLinked.length>yValueDecimals.length)
            {
                do
                {
                    yValueDecimals.push(0);       
                }
                while(yAxisLinked.length>yValueDecimals.length)
            }
            
            if(xAxisLinked.length>xValueDecimals.length)
            {
                do
                {
                    xValueDecimals.push(0);       
                }
                while(xAxisLinked.length>xValueDecimals.length)
            }
            
            if(enabled)
            {
                var yLabel = chart.renderer.text(
                    "Temp",
                    chart.plotBox.width+chart.plotBox.x+20+6,
                    0
                )
                .css({
                    fontFamily : fontFamily,
                    fontSize: fontSize,
                    color: fontColor
                }).
                attr({
                    id : 'yLabel',
                    opacity: 0,
                })
                .add();
                
                //sampleDate.getDate()+' '+aMonths[sampleDate.getMonth()]+' '+sampleDate.getFullYear()
                var xLabel = chart.renderer.text(
                    "Temp",
                    0,
                    chart.plotBox.height+chart.plotBox.y+3
                )
                .css({
                    fontFamily : fontFamily,
                    fontSize: fontSize,
                    color: fontColor
                }).
                attr({
                    id : 'xLabel',
                    opacity: 0,
                })
                .add();
                
                var yBox = chart.renderer.rect(
                    yLabel.getBBox().x-3,
                    yLabel.getBBox().y-2,
                    yLabel.getBBox().width+6,
                    yLabel.getBBox().height+4,
                    0)
                .attr({
                    fill: backgroundColor,
                    stroke: borderColor,
                    'stroke-width': borderWidth,
                    opacity: 0,
                    id : 'yBox'
                })
                .add();
                
                var xBox = chart.renderer.rect(
                    xLabel.getBBox().x-3,
                    xLabel.getBBox().y-2,
                    xLabel.getBBox().width+6,
                    xLabel.getBBox().height+4,
                    0)
                .attr({
                    fill: backgroundColor,
                    stroke: borderColor,
                    'stroke-width': borderWidth,
                    opacity: 0,
                    id : 'xBox'
                })
                .add();                                                                                             
                      
                addEvent(chart.container, 'mousemove', function (e)
                {
                    yPixels = chart.pointer.normalize(e).chartY;
                    xPixels = chart.pointer.normalize(e).chartX;
                    
                    yBox.toFront();
                    xBox.toFront();
                    yLabel.toFront();
                    xLabel.toFront();
                    
                    if((yPixels>chart.plotBox.y)&&(yPixels<chart.plotBox.y+chart.plotBox.height)&&(xPixels>chart.plotBox.x)&&(xPixels<chart.plotBox.x+chart.plotBox.width))
                    {
                        $.each(yAxisLinked,function(index,axis){
                            if((yPixels>chart.yAxis[axis].top)&&(yPixels<chart.yAxis[axis].top+chart.yAxis[axis].height))
                            {
                                var yLabelText = formatIfNeeded(chart.yAxis[axis].toValue(yPixels),chart.yAxis[axis],yValueDecimals[axis]);
                                yLabelText = (yLabelText) ? yLabelText : Math.floor(chart.yAxis[axis].toValue(yPixels) * Math.pow(10,yValueDecimals[axis])) / Math.pow(10,yValueDecimals[axis]);
                                
                                yLabel.attr({
                                    text: yLabelText,
                                    opacity: 1 
                                });
                                yBox.attr({
                                    width: yLabel.getBBox().width+6,
                                    x: chart.plotBox.x + chart.plotBox.width, 
                                    y: yPixels-(yBox.attr('height')/2),
                                    opacity: 1
                                });
                                yLabel.attr({
                                    y: yBox.attr('y')+parseInt(fontSize)+1,
                                    x: yBox.attr('x')+3 
                                });
                                return false;    
                            }
                            else
                            {
                                yBox.attr({
                                    opacity: 0
                                });
                                yLabel.attr({
                                    opacity: 0
                                });    
                            }   
                        });
                        
                        //Adjust xPixels' value to fit the hoverPoint
                        //xPixels = chart.xAxis[0].toPixels(chart.hoverPoints[0].x);
                        
                        $.each(xAxisLinked,function(index,axis){
                            if((xPixels>chart.xAxis[axis].left)&&(xPixels<chart.xAxis[axis].left+chart.xAxis[axis].width))
                            {
                                var xLabelText;
                                if(chart.xAxis[axis].options.type=="datetime")
                                {
                                    var newDate = new Date(chart.xAxis[axis].toValue(xPixels));
                                    xLabelText = newDate.getDate()+' '+aMonths[newDate.getMonth()]+' '+newDate.getFullYear();    
                                }
                                else
                                {
                                    xLabelText = Math.floor(chart.xAxis[axis].toValue(xPixels) * Math.pow(10,xValueDecimals[axis])) / Math.pow(10,xValueDecimals[axis]);   
                                }
                                
                                
                                xLabel.attr({
                                    text: xLabelText,
                                    y: chart.plotBox.height+chart.plotBox.y+parseInt(fontSize)+3+2, //bollow plotBox + fontSize + margin + padding
                                    opacity: 1 
                                });  
                                xBox.attr({
                                    width: xLabel.getBBox().width+6,
                                    opacity: 1
                                });
                                xBox.attr({
                                    x: xPixels-(xBox.attr('width')/2),
                                    y: chart.plotBox.height+chart.plotBox.y+3
                                });
                                xLabel.attr({
                                    x: xBox.attr('x')+3
                                });
                                
                                return false;
                            }
                            else
                            {
                                xBox.attr({
                                    opacity: 0
                                });
                                xLabel.attr({
                                    opacity: 0
                                });    
                            }
                            
                        });
                    }
                    else
                    {
                        yBox.attr({
                            opacity: 0
                        });
                        xBox.attr({
                            opacity: 0
                        });
                        yLabel.attr({
                            opacity: 0
                        });
                        xLabel.attr({
                            opacity: 0
                        });    
                    } 
                });
            }
        });
    }(Highcharts));
    
    //Fix bug display reverse chart
    (function(H) {
        function swapPlot(point) {
            var temp = point.yBottom;
            point.yBottom = point.plotHigh;
            point.plotHigh = temp;
        }
        H.wrap(H.seriesTypes.candlestick.prototype, 'drawPoints', function(proceed) {
            if (this.yAxis.reversed) {
                H.each(this.points, swapPlot)
            }

            proceed.apply(this, Array.prototype.slice.call(arguments, 1));
        });
    })(Highcharts);
    
    animated = (typeof animated === "undefined") ? false : animated;
    
    tooltipValueFormatOHLC = tooltipValueFormatOHLC.replace(/%toReplace%/ig,nbDecimals);
    tooltipValueFormatEOD = tooltipValueFormatEOD.replace(/%toReplace%/ig,nbDecimals);
    
    //Define the initial, basic options.
    var options = {
            
        chart: {
            renderTo : inDiv,       
            events : {
                load: function(){                         
                    var imageHeight = 25;
                    var imageWidth = 240;
                    
                    this.renderer.image("https://www.zonebourse.com/images/pdf_Report/"+aWords[0].capitalize()+".png",35,55,imageWidth,imageHeight).css({opacity: 0.5}).attr({zIndex: 2}).add();
                }, 
                redraw : function(){
                    $.each(aAtFlags,function(periode,aFlag){
                        if($('#periode').val()==periode)
                        {
                            $.each(aFlag,function(periode,flag){
                                if((chart.get('mainAxeValeurs').toPixels(flag[2])-7<chart.plotBox.y)||(chart.get('mainAxeValeurs').toPixels(flag[2])+7>chart.plotBox.y+chart.get('mainAxeValeurs').height)||(chart.xAxis[0].toPixels(flag[1])>chart.xAxis[0].toPixels(chart.xAxis[0].max)))
                                {
                                    $("#label"+flag[0]).attr({opacity: 0});   
                                    $("#text"+flag[0]).attr({opacity: 0});   
                                }
                                else
                                {
                                    $("#label"+flag[0]).attr({
                                        x: Math.max(chart.plotBox.x,chart.xAxis[0].toPixels(flag[1])),
                                        y: chart.get('mainAxeValeurs').toPixels(flag[2])-7,
                                        opacity: 1
                                    });
                                    $("#text"+flag[0]).attr({
                                        x: parseFloat($("#label"+flag[0]).attr('x'))+3,  
                                        y: parseFloat($("#label"+flag[0]).attr('y'))+12,
                                        opacity: 1
                                    }); 
                                }
                            }); 
                        }
                        else
                        {
                            $.each(aFlag,function(periode,flag){
                                $("#label"+flag[0]).attr({opacity: 0});   
                                $("#text"+flag[0]).attr({opacity: 0});
                            });     
                        }
                    });        
                }  
            },
            style :
            {
                fontFamily : 'Arial, Helvetica, Sans-Serif'
            },
            marginRight: 70
        },
        
        credits : {
            enabled : true,       
            href : null,
            text : '\u00A9'+aWords[0],
            style : {
                fontSize : '12px'               
            } 
        },
        
        exporting : {
            enabled : true,
            buttons: {
                contextButton: {
                    theme: {
                        fill: "#004EFF",
                        states: {
                            hover: {
                                fill: '#004EFF'
                            },
                            select: {
                                fill: '#004EFF'
                            }
                        }                                                
                    },
                    symbolStroke: "white",
                    symbolStrokeWidth: 2,
                    menuItems: [{
                        textKey: "printChart",
                        onclick: function (){this.print()}
                    },
                    {
                        separator: true
                    },
                    {
                        textKey: "downloadPNG",
                        onclick: function (){this.exportChart()}   
                    },
                    {
                        textKey: "downloadJPEG",
                        onclick: function (){this.exportChart({type:"image/jpeg"})}   
                    },
                    {
                        textKey: "downloadSVG",
                        onclick: function (){this.exportChart({type:"image/svg+xml"})}   
                    }]
                }
            }
        }, 
        
        navigator : {
            baseSeries : 'valeurs', 
            xAxis : {  
                labels: {
                    style : {
                        color: "black"
                    }
                },
                ordinal: true                
            },
            yAxis : {
                scalable: false
            }
        },  
        
        rangeSelector : configSelectorLong,   
                    
        plotOptions: {
            candlestick: {
                color: '#FF0000',        //close<open
                upColor: '#00FF00',      //close>open
                pointPadding: 0.1
            },
            column: {
                color: '#1a324a',        //volume color
            },
            line : {
                color : '#1A324A'               
            },
            series : {
                showInLegend : false,
                connectNulls: true,
                turboThreshold: 0,
                states: {
                    hover: {
                        enabled: false
                    }
                }  
            } 
        },
        
        tooltip: {
            followPointer: false,
            backgroundColor: {
                linearGradient: {
                    x1: 0,
                    y1: 0,
                    x2: 0,
                    y2: 1
                },
                stops: [
                    [0, 'white'],
                    [1, '#EEE']
                ]
            },
            borderColor: 'gray',
            borderWidth: 1,
            borderRadius: 5,
            shared : true,
            split: false,
            headerFormat: '<span style="font-size:12px">{point.key}</span><br><table style="min-width:150px;">',
            footerFormat: '</table>',
            useHTML: true,
            positioner: function(labelWidth,labelHeight,point){
                var xPos = (point.plotX-labelWidth < 0) ? point.plotX + 40 : point.plotX-labelWidth;
                var yPos = Math.min(Math.max(point.plotY,chart.plotTop),chart.plotTop+chart.plotHeight-labelHeight);
                return {x:xPos, y:yPos};
            },
            crosshairs: [true,true]                           
        }, 
        
        title : { 
            text : null
        },
        
        xAxis:[{
            gridLineWidth: 1,
            gridLineColor: "#ededed",
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black', 
            labels: {
                style: {
                    color: "black"
                }
            }         
        },
        {
            lineWidth: 1,
            lineColor: "black",                                                                         
            linkedTo: 0,
            tickWidth: 0,
            tickLength: 0,
            labels: {
                enabled: false
            },
            offset : 0  
        }],
        
        yAxis: [  
        {
            id : 'mainAxeValeurs',
            title: {
                text: '',
            },
            type: ($("#logScale").prop("checked")) ? 'logarithmic' : 'linear',
            height: '100%',
            gridLineWidth: 1,
            gridLineColor: "#ededed",                    
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            endOnTick: false,
            startOnTick: false,
            labels : {
                align : 'left',
                x : 5,
                style: {
                    color: "black"
                }
            },
            showLastLabel: true,
            opposite: true,
            reversed: true, 
            offset : 20,
            crosshair: {
                snap: false
            }                          
        },
        {
            id : 'axeVolumes',
            title: null,
            top: '85%',
            height: '0%',
            gridLineWidth: 1,
            gridLineColor: "#ededed",      
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            offset : 20,
            scalable: false,
            labels : {
                align : 'left',
                x : 5,
                style: {
                    color: "black"
                }
            },
            showEmpty : false,
            showLastLabel: true,
            endOnTick: false,
            crosshair: {
                snap: false
            }   
        }],
        
        crosshairsLabels: {
            enabled: true,
            fontSize: '11px',
            fontFamily : 'Tahoma',
            backgroundColor: "#FFEE00",
            borderColor: "black",
            borderWidth: 1,
            yValueDecimals : [nbDecimals,nbDecimals,1],  
            yAxisLinked : [0,2],
            xAxisLinked : [0]
        }
    };
    
    var chart = new Highcharts.StockChart(options);
                  
    chart.showLoading();
    
    addQuotes(codeZB,name,inDiv,animated,function()
    {
        bChartDrawn = true;
        chart.hideLoading();
        
        addVolumes(codeZB,inDiv,animated);
    
        chart.rangeSelector.clickButton(2,true);
        
        getMMAdata(codeZB,inDiv,'day',function()
        {                        
            var mma20 = {
                type : 'line',
                color : "#0000FF",
                data : aMoyennes['day'][0], 
                yAxis: 'mainAxeValeurs',
                xAxis: 0,
                lineWidth: 1,
                name : 'MMA(20)',
                id : 'MMA20',
                tooltip: {
                    pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.4f}</b></td></tr>'
                },
                //zIndex : 2,
                dataGrouping: {
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                },
                visible: $('#mmaButton').prop('checked')
            };
            var mma50 = {
                type : 'line',
                color : "#FF00FF",
                data : aMoyennes['day'][1],
                yAxis: 'mainAxeValeurs',
                xAxis: 0,
                lineWidth: 1,
                name : 'MMA(50)',
                id : 'MMA50',
                tooltip: {
                    pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.4f}</b></td></tr>'
                },
                //zIndex : 1,
                dataGrouping: {
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                },
                visible: $('#mmaButton').prop('checked')
            };

            var mma100 = {
                type : 'line',
                color : "#FFA500",
                data : aMoyennes['day'][2],
                yAxis: 'mainAxeValeurs',
                xAxis: 0,
                lineWidth: 1,
                name : 'MMA(100)',
                id : 'MMA100',
                tooltip: {
                    pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.4f}</b></td></tr>'
                },
                //zIndex : 0,
                dataGrouping: {
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                },
                visible: $('#mmaButton').prop('checked')
            };  

            var mma20V = {
                type : 'line',
                color : "#0000FF",
                data : aMoyennes['day'][3],
                yAxis: 'axeVolumes',
                xAxis: 0,
                lineWidth: 1,
                name : 'MMA(20) volumes',
                id : 'MMA20V',
                tooltip: {
                    pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.0f}</b></td></tr>'
                },
                //zIndex : 2,
                dataGrouping: {
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                },
                visible: $('#mmaButton').prop('checked')
            };
            
            chart.addSeries(mma20,false);
            aChartSeriesID.push(mma20.id);
            chart.addSeries(mma50,false);
            aChartSeriesID.push(mma50.id);
            chart.addSeries(mma100,!bGotVolumes);
            aChartSeriesID.push(mma100.id);
            
            if(bGotVolumes)
            {
                chart.addSeries(mma20V,true);
                aChartSeriesID.push(mma20V.id);
            }
        });
        
        getMMAdata(codeZB,inDiv,'week');
    });    
}

function drawGraphSynthese(codeZB,inDiv,sTitle,sGraphStyle,nbDecimals)
{
    //axis labels for crosshairs
    /* 
    // configuration and defaults :
    // enabled -> bool / false,
    // fontSize -> String / '11px',
    // fontFamily -> String / 'Arial',
    // fontColor -> String / 'black' <=> "#000000",
    // backgroundColor -> String / "#FFFFFF",
    // borderColor -> String / 'black' <=> "#000000",
    // borderWidth -> int / 1,
    // yAxisLinked -> array / [0],
    // xAxisLinked -> array / [0],
    // yValueDecimals -> array / [0],  if yAxisLinked > yValueDecimals complete yValueDecimals with 0
    // xValueDecimals -> array / [0]   if xAxisLinked > xValueDecimals complete xValueDecimals with 0
    //
    */
    (function (H) {
        'use strict';
        var addEvent = H.addEvent,
            doc = document,
            body = doc.body,
            formatIfNeeded = function(value,axis,nbDec)
            {
                var categories = axis.categories,
                    numericSymbols = chart.options.lang.numericSymbols,
                    i = numericSymbols && numericSymbols.length,
                    multi,
                    ret,
                    nbDec = (typeof nbDec === "undefined") ? 0 : nbDec,
                    // make sure the same symbol is added for all labels on a linear axis
                    numericSymbolDetector = axis.isLog ? value : axis.tickInterval;

                if(i && numericSymbolDetector >= 1000 && !categories) {
                    // Decide whether we should add a numeric symbol like k (thousands) or M (millions).
                    // If we are to enable this in tooltip or other places as well, we can move this
                    // logic to the numberFormatter and enable it by a parameter.
                    while (i-- && (typeof ret === "undefined")) {
                        multi = Math.pow(1000, i + 1);
                        if (numericSymbolDetector >= multi && numericSymbols[i] !== null) {
                            ret = (value / multi).toFixedDown(nbDec) + numericSymbols[i];
                        }
                    }
                }

                if (typeof ret === "undefined")
                    ret = false;
                    
                return ret;
            };

        H.wrap(H.Chart.prototype, 'init', function (proceed) {

            // Run the original proceed method
            proceed.apply(this, Array.prototype.slice.call(arguments, 1));

            var chart = this,
                options = chart.options,
                panning = options.chart.panning || true,
                zoomType = options.chart.zoomType || '',
                container = chart.container,
                yAxis = chart.get('mainAxeValeurs'),
                yPixels,
                xPixels,
                configuration = options.crosshairsLabels||{},
                enabled = configuration.enabled||false,
                fontSize = configuration.fontSize||'11px',
                fontFamily = configuration.fontFamily || 'Arial',
                fontColor = configuration.fontColor || 'black',
                backgroundColor = configuration.backgroundColor||"#FFFFFF",
                borderColor = configuration.borderColor||"black",
                borderWidth = (typeof configuration.borderWidth ==="undefined") ? 1 : configuration.borderWidth,
                yAxisLinked = configuration.yAxisLinked || [0],
                xAxisLinked = configuration.xAxisLinked || [0],
                yValueDecimals = configuration.yValueDecimals || [0],
                xValueDecimals = configuration.xValueDecimals || [0];
            
            if(yAxisLinked.length>yValueDecimals.length)
            {
                do
                {
                    yValueDecimals.push(0);       
                }
                while(yAxisLinked.length>yValueDecimals.length)
            }
            
            if(xAxisLinked.length>xValueDecimals.length)
            {
                do
                {
                    xValueDecimals.push(0);       
                }
                while(xAxisLinked.length>xValueDecimals.length)
            }
            
            if(enabled)
            {
                var yLabel = chart.renderer.text(
                    "Temp",
                    chart.plotBox.width+chart.plotBox.x+20+6,
                    0
                )
                .css({
                    fontFamily : fontFamily,
                    fontSize: fontSize,
                    color: fontColor
                }).
                attr({
                    id : 'yLabel',
                    opacity: 0,
                })
                .add();
                
                //sampleDate.getDate()+' '+aMonths[sampleDate.getMonth()]+' '+sampleDate.getFullYear()
                var xLabel = chart.renderer.text(
                    "Temp",
                    0,
                    chart.plotBox.height+chart.plotBox.y+3
                )
                .css({
                    fontFamily : fontFamily,
                    fontSize: fontSize,
                    color: fontColor
                }).
                attr({
                    id : 'xLabel',
                    opacity: 0,
                })
                .add();
                
                var yBox = chart.renderer.rect(
                    yLabel.getBBox().x-3,
                    yLabel.getBBox().y-2,
                    yLabel.getBBox().width+6,
                    yLabel.getBBox().height+4,
                    0)
                .attr({
                    fill: backgroundColor,
                    stroke: borderColor,
                    'stroke-width': borderWidth,
                    opacity: 0,
                    id : 'yBox'
                })
                .add();
                
                var xBox = chart.renderer.rect(
                    xLabel.getBBox().x-3,
                    xLabel.getBBox().y-2,
                    xLabel.getBBox().width+6,
                    xLabel.getBBox().height+4,
                    0)
                .attr({
                    fill: backgroundColor,
                    stroke: borderColor,
                    'stroke-width': borderWidth,
                    opacity: 0,
                    id : 'xBox'
                })
                .add();                                                                                             
                      
                addEvent(body, 'mousemove', function (e)
                {
                    yPixels = chart.pointer.normalize(e).chartY;
                    xPixels = chart.pointer.normalize(e).chartX;
                    
                    yBox.toFront();
                    xBox.toFront();
                    yLabel.toFront();
                    xLabel.toFront();
                    
                    if((yPixels>chart.plotBox.y)&&(yPixels<chart.plotBox.y+chart.plotBox.height)&&(xPixels>chart.plotBox.x)&&(xPixels<chart.plotBox.x+chart.plotBox.width))
                    {
                        $.each(yAxisLinked,function(index,axis){
                            if((yPixels>chart.yAxis[axis].top)&&(yPixels<chart.yAxis[axis].top+chart.yAxis[axis].height))
                            {
                                var yLabelText = formatIfNeeded(chart.yAxis[axis].toValue(yPixels),chart.yAxis[axis],yValueDecimals[axis]);
                                yLabelText = (yLabelText) ? yLabelText : Math.floor(chart.yAxis[axis].toValue(yPixels) * Math.pow(10,yValueDecimals[axis])) / Math.pow(10,yValueDecimals[axis]);
                                
                                yLabel.attr({
                                    text: yLabelText,
                                    opacity: 1 
                                });
                                yBox.attr({
                                    width: yLabel.getBBox().width+6,
                                    x: chart.plotBox.x + chart.plotBox.width, 
                                    y: yPixels-(yBox.attr('height')/2),
                                    opacity: 1
                                });
                                yLabel.attr({
                                    y: yBox.attr('y')+parseInt(fontSize)+1,
                                    x: yBox.attr('x')+3 
                                });
                                return false;    
                            }
                            else
                            {
                                yBox.attr({
                                    opacity: 0
                                });
                                yLabel.attr({
                                    opacity: 0
                                });    
                            }   
                        });
                        
                        //Adjust xPixels' value to fit the hoverPoint
                        //xPixels = chart.xAxis[0].toPixels(chart.hoverPoints[0].x);
                        
                        $.each(xAxisLinked,function(index,axis){
                            if((xPixels>chart.xAxis[axis].left)&&(xPixels<chart.xAxis[axis].left+chart.xAxis[axis].width))
                            {
                                var xLabelText;
                                if(chart.xAxis[axis].options.type=="datetime")
                                {
                                    var newDate = new Date(chart.xAxis[axis].toValue(xPixels));
                                    xLabelText = newDate.getDate()+' '+aMonths[newDate.getMonth()]+' '+newDate.getFullYear();    
                                }
                                else
                                {
                                    xLabelText = Math.floor(chart.xAxis[axis].toValue(xPixels) * Math.pow(10,xValueDecimals[axis])) / Math.pow(10,xValueDecimals[axis]);   
                                }
                                
                                
                                xLabel.attr({
                                    text: xLabelText,
                                    y: chart.plotBox.height+chart.plotBox.y+parseInt(fontSize)+3+2, //bollow plotBox + fontSize + margin + padding
                                    opacity: 1 
                                });  
                                xBox.attr({
                                    width: xLabel.getBBox().width+6,
                                    opacity: 1
                                });
                                xBox.attr({
                                    x: xPixels-(xBox.attr('width')/2),
                                    y: chart.plotBox.height+chart.plotBox.y+3
                                });
                                xLabel.attr({
                                    x: xBox.attr('x')+3
                                });
                                
                                return false;
                            }
                            else
                            {
                                xBox.attr({
                                    opacity: 0
                                });
                                xLabel.attr({
                                    opacity: 0
                                });    
                            }
                            
                        });
                    }
                    else
                    {
                        yBox.attr({
                            opacity: 0
                        });
                        xBox.attr({
                            opacity: 0
                        });
                        yLabel.attr({
                            opacity: 0
                        });
                        xLabel.attr({
                            opacity: 0
                        });    
                    } 
                });
            }
        });
    }(Highcharts));
    
    tooltipValueFormatOHLC = tooltipValueFormatOHLC.replace(/%toReplace%/ig,nbDecimals);
    tooltipValueFormatEOD = tooltipValueFormatEOD.replace(/%toReplace%/ig,nbDecimals);
      
    //Define the initial, basic options.
    var options = {
            
        chart: {
            renderTo : inDiv,
            panning: false,
            spacingLeft: 0,
            spacingBottom: 0,
            spacingTop: 0,
            //spacingRight: 0,      
            events : {
                redraw : function(){
                    $.each(aAtFlags,function(periode,aFlag){
                        if(($('#periode').val()==periode)&&($('#atButton').prop('checked')))
                        {
                            $.each(aFlag,function(periode,flag){
                                if((chart.get('mainAxeValeurs').toPixels(flag[2])-7<chart.plotBox.y)||(chart.get('mainAxeValeurs').toPixels(flag[2])+7>chart.plotBox.y+chart.get('mainAxeValeurs').height)||(chart.xAxis[0].toPixels(flag[1])>chart.xAxis[0].toPixels(chart.xAxis[0].max)))
                                {
                                    $("#label"+flag[0]).attr({opacity: 0});   
                                    $("#text"+flag[0]).attr({opacity: 0});   
                                }
                                else
                                {
                                    $("#text"+flag[0]).attr({
                                        x: Math.max(chart.plotBox.x,chart.xAxis[0].toPixels(flag[1]))+3,  
                                        y: chart.get('mainAxeValeurs').toPixels(flag[2])-3,
                                        opacity: 1
                                    });
                                    
                                    $("#label"+flag[0]).attr({
                                        x: parseFloat($("#text"+flag[0]).attr('x'))-3,
                                        y: parseFloat($("#text"+flag[0]).attr('y'))+2-parseFloat($("#label"+flag[0]).attr('height')),
                                        opacity: 1
                                    }); 
                                }
                            }); 
                        }
                        else
                        {
                            $.each(aFlag,function(periode,flag){
                                $("#label"+flag[0]).attr({opacity: 0});   
                                $("#text"+flag[0]).attr({opacity: 0});
                            });     
                        }
                    });        
                }  
            },
            style :
            {
                fontFamily : 'Arial, Helvetica, Sans-Serif'
            }
        },
        
        credits : {
            enabled : false
        },
        
        exporting : {
            enabled : false
        }, 
        
        navigator : {
            enabled: false
        },
        
        scrollbar :{
            enabled: false
        },
        
        rangeSelector : configSelectorMini,
        
        annotationsOptions:
        {
            enabledButtons: false       //set first to false or will throw error when options.series contains no series
        },      
                    
        plotOptions: {
            candlestick: {
                color: '#FF0000',        //close<open
                upColor: '#00FF00',      //close>open
                pointPadding: 0.1
            },
            column: {
                color: '#1a324a',        //volume color
                pointPadding: 0.01 
            },
            line : {
                color : '#1A324A'               
            },
            series : {
                showInLegend : false,
                connectNulls: true,
                turboThreshold: 0,
                states: {
                    hover: {
                        enabled: false
                    }
                } 
            } 
        },
        
        tooltip: {
            enabled: false,
            crosshairs: [true,true]                           
        }, 
        
        title : { 
            text : null
        },
        
        xAxis:[{
            gridLineWidth: 1,
            gridLineColor: "#ededed",
            //range: 3600*24*30*4*1000,
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            labels: {
                style: {
                    color: "black"
                }
            },
            events: {
                afterSetExtremes: function(){
                    if(mouseDown==0&&bChartDrawn){
                        console.log("set");
                    }    
                }
            }            
        },
        {
            lineWidth: 1,
            lineColor: "black",
            offset : 0,
            labels: {
                enabled: false
            }    
        }],
        
        yAxis: [  
        {
            id : 'mainAxeValeurs',
            title: {
                text: '',
            },
            height: '100%',
            gridLineWidth: 1,
            gridLineColor: "#ededed",                    
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            endOnTick: false,
            startOnTick: false,
            labels : {
                align : 'left',
                x : 5,
                style: {
                    color: "black"
                }
            },
            showLastLabel: true,
            opposite: true, 
            offset : 20,
            crosshair: {
                snap: false
            }                         
        },
        {
            id : 'axeVolumes',
            title: null,
            top: '85%',
            height: '0%',
            gridLineWidth: 1,
            gridLineColor: "#ededed",      
            lineWidth: 1,
            lineColor: "black",
            tickWidth: 1,
            tickLength: 5,
            tickColor: 'black',
            offset : 20,
            scalable: false,
            labels : {
                align : 'left',
                x : 5,
                style: {
                    color: "black"
                }
            },
            showEmpty : false,
            showLastLabel: true,
            endOnTick: false,
            crosshair: {
                snap: false
            }   
        }],
        
        crosshairsLabels: {
            enabled: true,
            fontSize: '11px',
            fontFamily : 'Tahoma',
            backgroundColor: "#FFEE00",
            borderColor: "black",
            borderWidth: 1,
            yValueDecimals : [nbDecimals,nbDecimals,1],  
            yAxisLinked : [0,2],
            xAxisLinked : [0]
        }
    };
    
    var chart = new Highcharts.StockChart(options);
    chart.showLoading();
                               
    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        context : document.body,
        async : true,
        data : {codeZB : codeZB, type : "chart", fields: "Date,Open,High,Low,Close"},
        type : 'GET',
        success : function(data)
        {
        var aDataQuote;    
            try
            {
                aDataQuote = JSON.parse(data)    
            }
            catch(e)
            {
                $('#'+inDiv).css('display','none');
                console.log("erreur JSON parse : "+e);
                console.log("data received : "+data);
                return;
            }
            var chartSeries = {                          
                type : sGraphStyle,
                name : sTitle,   
                data : [],//aDataQuote,
                id : 'valeurs',
                yAxis: 'mainAxeValeurs',
                //zIndex : 3,
                tooltip: {
                    pointFormat : tooltipValueFormatOHLC
                },
                dataGrouping: {
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                }
            };
            
            var now = new Date().getTime();
            var i = aDataQuote.length-1; 
            while((i>=0)&&(aDataQuote[i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
            {        
                chartSeries.data.unshift(aDataQuote[i]);
                i--;                
            } 

            chart.addSeries(chartSeries,false,false);
            aChartSeriesID.push(chartSeries.id);

            $.ajax({url : URL_SERVEUR+'atDataFeed.php',
                context : document.body,
                async : true,
                data : {codeZB : codeZB, type : "volumes"},
                type : 'GET',
                success : function(data)
                {
                    try
                    {
                        aDataQuote = JSON.parse(data)    
                    }
                    catch(e)
                    {
                        $('#'+inDiv).css('display','none');
                        console.log("erreur JSON parse : "+e);
                        console.log("data received : "+data);
                        return;
                    }

                    var volumeSeries = {
                        type : 'column',
                        name : 'Volumes',
                        data : [],//aDataQuote,
                        yAxis: 'axeVolumes',
                        id : 'volumes',
                        tooltip: {
                            pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y}</b></td></tr>'
                        },
                        dataGrouping: {
                            units:[
                                ['day',[1]]
                            ],
                            dateTimeLabelFormats: {
                                day : [dateFormatDay],
                                week: [dateFormatWeek]
                            }
                        }
                    };

                    var now = new Date().getTime();
                    var i = aDataQuote.length-1; 
                    while((i>=0)&&(aDataQuote[i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
                    {        
                        volumeSeries.data.unshift(aDataQuote[i]);
                        i--;                
                    }

                    if(aDataQuote.length>0)
                    {
                        chart.addSeries(volumeSeries,false,false);
                        bGotVolumes = true;
                        aChartSeriesID.push(volumeSeries.id);
                        chart.get('axeVolumes').update({
                            height: '15%',
                            tickPixelInterval: chart.plotHeight*(0.1)
                            },false);
                        chart.get('mainAxeValeurs').update({
                            height : '85%'
                            },false);
                        chart.xAxis[1].update({
                            offset: -chart.plotHeight*0.15
                            },false);
                    }


                    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
                        context : document.body,
                        async : true,
                        data : {codeZB : codeZB, type : "moyennes"},
                        type : 'GET',
                        success : function(data)
                        {
                            try
                            {
                                aDataQuote = JSON.parse(data)    
                            }
                            catch(e)
                            {
                                $('#'+inDiv).css('display','none');
                                console.log("erreur JSON parse : "+e);
                                console.log("data received : "+data);
                                return;
                            }

                            var mma20 = {
                                type : 'line',
                                color : "#0000FF",
                                data : [],//aDataQuote[0], 
                                yAxis: 'mainAxeValeurs',
                                lineWidth: 1,
                                name : 'MMA(20)',
                                id : 'MMA20',
                                tooltip: {
                                    pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.4f}</b></td></tr>'
                                },
                                //zIndex : 2,
                                dataGrouping: {
                                    units:[
                                        ['day',[1]]
                                    ],
                                    dateTimeLabelFormats: {
                                        day : [dateFormatDay],
                                        week: [dateFormatWeek]
                                    }
                                }
                            };

                            var mma50 = {
                                type : 'line',
                                color : "#FF00FF",
                                data : [],//aDataQuote[1],
                                yAxis: 'mainAxeValeurs',
                                lineWidth: 1,
                                name : 'MMA(50)',
                                id : 'MMA50',
                                tooltip: {
                                    pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.4f}</b></td></tr>'
                                },
                                //zIndex : 1,
                                dataGrouping: {
                                    units:[
                                        ['day',[1]]
                                    ],
                                    dateTimeLabelFormats: {
                                        day : [dateFormatDay],
                                        week: [dateFormatWeek]
                                    }
                                }
                            };

                            var mma100 = {
                                type : 'line',
                                color : "#FFA500",
                                data : [],//aDataQuote[2],
                                yAxis: 'mainAxeValeurs',
                                lineWidth: 1,
                                name : 'MMA(100)',
                                id : 'MMA100',
                                tooltip: {
                                    pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.4f}</b></td></tr>'
                                },
                                //zIndex : 0,
                                dataGrouping: {
                                    units:[
                                        ['day',[1]]
                                    ],
                                    dateTimeLabelFormats: {
                                        day : [dateFormatDay],
                                        week: [dateFormatWeek]
                                    }
                                }
                            };  

                            var mma20V = {
                                type : 'line',
                                color : "#0000FF",
                                data : [],//aDataQuote[3], 
                                yAxis: 'axeVolumes',
                                lineWidth: 1,
                                name : 'MMA(20) volumes',
                                id : 'MMA20V',
                                tooltip: {
                                    pointFormat : '<tr><td style="padding:0;font-size:12px"><span style="color: {series.color};">{series.name}</span>: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:,.0f}</b></td></tr>'
                                },
                                //zIndex : 0,
                                dataGrouping: {
                                    units:[
                                        ['day',[1]]
                                    ],
                                    dateTimeLabelFormats: {
                                        day : [dateFormatDay],
                                        week: [dateFormatWeek]
                                    }
                                }
                            };

                            var now = new Date().getTime();
                            var i = aDataQuote[0].length-1; 
                            while((i>=0)&&(aDataQuote[0][i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
                            {
                                mma20.data.unshift(aDataQuote[0][i]);
                                i--;                
                            }

                            var i = aDataQuote[1].length-1; 
                            while((i>=0)&&(aDataQuote[1][i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
                            {
                                mma50.data.unshift(aDataQuote[1][i]);
                                i--;                
                            }

                            var i = aDataQuote[2].length-1; 
                            while((i>=0)&&(aDataQuote[2][i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
                            {
                                mma100.data.unshift(aDataQuote[2][i]); 
                                i--;                
                            }

                            var i = aDataQuote[3].length-1;

                            while((i>=0)&&(aDataQuote[3][i][0]>(now-(3600*24*365*nbAnneeHisto*1000)))&&bGotVolumes)
                            {
                                mma20V.data.unshift(aDataQuote[3][i]);
                                i--;                
                            }

                            aMoyennes['day'] = [mma20.data,mma50.data,mma100.data,mma20V.data];          

                            chart.addSeries(mma20,false,false);
                            aChartSeriesID.push(mma20.id);
                            chart.addSeries(mma50,false,false);
                            aChartSeriesID.push(mma50.id);
                            chart.addSeries(mma100,!bGotVolumes,false);
                            aChartSeriesID.push(mma100.id);

                            if(bGotVolumes)
                            {
                                chart.addSeries(mma20V,true,false);
                                aChartSeriesID.push(mma20V.id);
                            }


                            $.ajax({url : URL_SERVEUR+'atDataFeed.php',
                                context : document.body,
                                async : true,
                                data : {type : 'analyses' , codeZB : codeZB, periode : 'DAY'},
                                type : 'GET',
                                success : function(data)
                                {
                                    var aDataAT,
                                    idLigneInt = 1;
                                    try
                                    {
                                        aDataAT = JSON.parse(data)    
                                    }
                                    catch(e)
                                    {
                                        $('#'+inDiv).css('display','none');
                                        console.log("erreur JSON parse : "+e);
                                        console.log("data received : "+data);
                                        return;
                                    } 

                                    var now = new Date().getTime();   
                                    $.each(aDataAT,function(index,aData)
                                    {
                                        if(aData.length == 7)
                                        {
                                            /*var trendSeries = {
                                            type : 'scatter',
                                            color : aData[1],
                                            id : aData[0],
                                            data : [[Math.max(aData[3],(now-(3600*24*365*nbAnneeHisto*1000))),aData[4]],[Math.max(aData[5],(now-(3600*24*365*nbAnneeHisto*1000))),aData[6]]],
                                            yAxis: 'secAxeValeurs',
                                            lineWidth: aData[2],
                                            enableMouseTracking : false,
                                            zIndex : 3,
                                            marker: {
                                            enabled: false
                                            }              
                                            };

                                            var lastDate = chart.get("valeurs").xData.slice(-1)[0];
                                            var a = (aData[6]-aData[4])/(aData[5]-aData[3]);
                                            var b = aData[4]-(a*aData[3]);

                                            trendSeries.data.push([lastDate,lastDate*a+b]);

                                            chart.addSeries(trendSeries);
                                            aChartSeriesID.push(trendSeries.id);
                                            aAT['day'].push(aData[0]);*/
                                        }
                                        else if(aData.length == 6)
                                        {
                                            var lastDate = chart.get("valeurs").xData.slice(-1)[0];

                                            var atSeries = {
                                                type : 'scatter',
                                                color : aData[1],
                                                id : aData[0],
                                                data : [[Math.max(aData[3],(now-(3600*24*365*nbAnneeHisto*1000))),aData[4]],[lastDate,aData[4]]],
                                                yAxis: 'mainAxeValeurs',
                                                lineWidth: aData[2],
                                                enableMouseTracking : false,
                                                //zIndex : 3,
                                                marker: {
                                                    enabled: false
                                                }   
                                            };

                                            chart.addSeries(atSeries,false,false);
                                            aChartSeriesID.push(atSeries.id);

                                            var opacityVal = ((chart.get('mainAxeValeurs').toPixels(aData[4])-7<chart.plotBox.y)||(chart.get('mainAxeValeurs').toPixels(aData[4])+7>chart.plotBox.y+chart.plotBox.height)) ? 0 : 1;

                                            var textLabel = chart.renderer.text(aData[4].toFixed(parseInt(aData[5][1])),
                                                Math.max(chart.plotBox.x,chart.xAxis[0].toPixels(aData[3]))+3,
                                                chart.get('mainAxeValeurs').toPixels(aData[4])-2)
                                            .css({
                                                fontFamily : 'Tahoma',
                                                fontSize: '11px',
                                                color: 'white'
                                            }).
                                            attr({
                                                id : 'text'+aData[0],
                                                zIndex :4,
                                            })
                                            .add();

                                            chart.renderer.rect(textLabel.getBBox().x-3,
                                                textLabel.getBBox().y-2,
                                                textLabel.getBBox().width+6,
                                                textLabel.getBBox().height,
                                                0)
                                            .attr({
                                                fill: aData[1],
                                                stroke: aData[1],
                                                'stroke-width': 1,
                                                opacity: opacityVal,
                                                zIndex :3,
                                                id : 'label'+aData[0]
                                            })
                                            .add();

                                            aAtFlags['day'].push([aData[0],aData[3],aData[4]]);
                                            aAT['day'].push(aData[0]);
                                        }
                                        else
                                        {
                                            var lastDate = chart.get("valeurs").xData.slice(-1)[0];

                                            var ligneIntSeries = {
                                                type : 'scatter',
                                                color : 'black',
                                                id : "ligneInt"+idLigneInt+"DAY",
                                                data : [[Math.max(aData[1],(now-(3600*24*365*nbAnneeHisto*1000))),aData[2]],[lastDate,aData[2]]],
                                                yAxis: 'mainAxeValeurs',
                                                lineWidth: 1,
                                                dashStyle: 'ShortDash',
                                                enableMouseTracking : false,
                                                //zIndex : 3,
                                                marker: {
                                                    enabled: false
                                                }   
                                            };

                                            chart.addSeries(ligneIntSeries,false,false);
                                            aChartSeriesID.push(ligneIntSeries.id);

                                            var opacityVal = ((chart.get('mainAxeValeurs').toPixels(aData[2])-7<chart.plotBox.y)||(chart.get('mainAxeValeurs').toPixels(aData[2])+7>chart.plotBox.y+chart.plotBox.height)) ? 0 : 1;

                                            var textLabel = chart.renderer.text(aData[2].toFixed(parseInt(aData[3][1])),
                                                Math.max(chart.plotBox.x,chart.xAxis[0].toPixels(aData[1]))+3,
                                                chart.get('mainAxeValeurs').toPixels(aData[2])-2)
                                            .css({
                                                fontFamily : 'Tahoma',
                                                fontSize: '11px',
                                                color: 'black'
                                            }).
                                            attr({
                                                id : 'textLigneInt'+idLigneInt+"DAY",
                                                zIndex :4,
                                            })
                                            .add();

                                            chart.renderer.rect(textLabel.getBBox().x-3,
                                                textLabel.getBBox().y-2,
                                                textLabel.getBBox().width+6,
                                                textLabel.getBBox().height,
                                                0)
                                            .attr({
                                                fill: 'white',
                                                stroke: 'black',
                                                'stroke-width': 1,
                                                opacity: opacityVal,
                                                zIndex :3,
                                                id : 'labelLigneInt'+idLigneInt+"DAY"
                                            })
                                            .add();   

                                            aAtFlags['day'].push(['LigneInt'+idLigneInt+"DAY",aData[1],aData[2]]);
                                            aAT['day'].push("ligneInt"+idLigneInt+"DAY");

                                            idLigneInt++;    
                                        }  
                                    });
                                    
                                    bChartDrawn = true;
                                    chart.redraw();
                                    chart.hideLoading();
                                    chart.rangeSelector.clickButton(2,chart.rangeSelector.buttonOptions[2],true);  
                                }
                            });

                        }
                    });

                }
            });
        }
    });
        
    $('#candle').click(function()
    {
        if($(this).attr('selected')!="selected")
        {
            var chart = $('#'+inDiv).highcharts();
            chart.get('valeurs').update({
                type : 'candlestick',
                color: '#FF0000',
                tooltip: {
                    pointFormat : tooltipValueFormatOHLC
                }
            });
            $('#candle').attr('src',"https://www.zonebourse.com/images/3C_CandleStick_on.gif");
            $('#line').attr('src',"https://www.zonebourse.com/images/3C_Line_of.gif");
            $('#ohlc').attr('src',"https://www.zonebourse.com/images/3C_OHLC_of.gif");

            $('#candle').attr({selected : true});
            $('#line').attr({selected : false});
            $('#ohlc').attr({selected : false});
        }            
    });

    $('#line').click(function()
    {
        if($(this).attr('selected')!="selected")
        {
            var chart = $('#'+inDiv).highcharts();
            chart.get('valeurs').update({
                type : 'line',
                color : '#1A324A',
                tooltip: {
                    pointFormat : tooltipValueFormatEOD
                }
            });

            $('#candle').attr('src',"https://www.zonebourse.com/images/3C_CandleStick_of.gif");
            $('#line').attr('src',"https://www.zonebourse.com/images/3C_Line_on.gif");
            $('#ohlc').attr('src',"https://www.zonebourse.com/images/3C_OHLC_of.gif");

            $('#candle').attr({selected : false});
            $('#line').attr({selected : true});
            $('#ohlc').attr({selected : false});
        }                
    });

    $('#ohlc').click(function()
    {
        if($(this).attr('selected')!="selected")
        {
            var chart = $('#'+inDiv).highcharts();
            chart.get('valeurs').update({
                type : 'ohlc',
                color : '#000000',
                tooltip: {
                    pointFormat : tooltipValueFormatOHLC
                }
            });
            $('#candle').attr('src',"https://www.zonebourse.com/images/3C_CandleStick_of.gif");
            $('#line').attr('src',"https://www.zonebourse.com/images/3C_Line_of.gif");
            $('#ohlc').attr('src',"https://www.zonebourse.com/images/3C_OHLC_on.gif");

            $('#candle').attr({selected : false});
            $('#line').attr({selected : false});
            $('#ohlc').attr({selected : true});
        }                 
    });
    
    $('#periode').change(function(p)
    {
        var periode = this.value,
            aSeriesToUpdate = ["valeurs","volumes","MMA20","MMA50","MMA100","MMA20V"];
        $.each(aSeriesToUpdate,function(index,idSeries){
            if(chart.get(idSeries))
            {
                chart.get(idSeries).update({
                    dataGrouping: {
                        units:[
                            [periode,[1]]
                        ]
                    }
                },
                false);
            }    
        });
        if(typeof aMoyennes[periode] === "undefined")
        {
            $.ajax({url : URL_SERVEUR+'atDataFeed.php',
                    context : document.body,
                    async : true,
                    data : {codeZB : codeZB, type : "moyennes", cycle : periode.toUpperCase()+"1"},
                    type : 'GET',
                    success : function(data)
                    {
                        try
                        {
                            aDataQuote = JSON.parse(data)    
                        }
                        catch(e)
                        {
                            $('#'+inDiv).css('display','none');
                            console.log("erreur JSON parse : "+e);
                            console.log("data received : "+data);
                            return;
                        }
                        
                        var now = new Date().getTime();
                        
                        var mma20Data = [],
                            mma50Data = [],
                            mma100Data = [],
                            mma20VData = [];
                            
                        var i = aDataQuote[0].length-1;      
                        while((i>=0)&&(aDataQuote[0][i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
                        {
                            mma20Data.unshift(aDataQuote[0][i]);
                            i--;                
                        }
                        
                        var i = aDataQuote[1].length-1; 
                        while((i>=0)&&(aDataQuote[1][i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
                        {
                            mma50Data.unshift(aDataQuote[1][i]);
                            i--;                
                        }
                        
                        var i = aDataQuote[2].length-1; 
                        while((i>=0)&&(aDataQuote[2][i][0]>(now-(3600*24*365*nbAnneeHisto*1000))))
                        {
                            mma100Data.unshift(aDataQuote[2][i]||null); 
                            i--;                
                        }
                        
                        var i = aDataQuote[3].length-1;
                        while((i>=0)&&(aDataQuote[3][i][0]>(now-(3600*24*365*nbAnneeHisto*1000)))&&bGotVolumes)
                        {
                            mma20VData.unshift(aDataQuote[3][i]||null);
                            i--;                
                        }
                        
                        aMoyennes[periode] = [mma20Data,mma50Data,mma100Data,mma20VData];  
                        
                        chart.get("MMA20").update({
                            data : mma20Data
                        },
                        false);
                        chart.get("MMA50").update({
                            data : mma50Data
                        },
                        false);
                        chart.get("MMA100").update({
                            data : mma100Data
                        },
                        false);
                        
                        if(bGotVolumes)
                        {
                            chart.get("MMA20V").update({
                                data : mma20VData
                            },
                            false);
                        }
                        chart.redraw();  
                    }
            });    
        }
        else
         {
            chart.get("MMA20").update({
                data : aMoyennes[periode][0]
            },
            false);
            chart.get("MMA50").update({
                data : aMoyennes[periode][1]
            },
            false);
            chart.get("MMA100").update({
                data : aMoyennes[periode][2]
            },
            false);
            
            if(bGotVolumes)
            {
                chart.get("MMA20V").update({
                    data : aMoyennes[periode][3]
                },
                false);   
            }
                
        }
        
        
        if(aAT[periode].length==0)
        {
            $.ajax({url : URL_SERVEUR+'atDataFeed.php',
                context : document.body,
                async : true,
                data : {type : 'analyses' , codeZB : codeZB, periode : periode.toUpperCase()},
                type : 'GET',
                success : function(data)
                {
                    var aDataAT,
                        idLigneInt = 1;
                    try
                    {
                        aDataAT = JSON.parse(data)    
                    }
                    catch(e)
                    {
                        $('#'+inDiv).css('display','none');
                        console.log("erreur JSON parse : "+e);
                        console.log("data received : "+data);
                        return;
                    }
                    var now = new Date().getTime();
                    $.each(aDataAT,function(index,aData){
                        if(aData.length == 7)
                        {
                            /*var trendSeries = {
                                type : 'scatter',
                                color : aData[1],
                                id : aData[0],
                                data : [[Math.max(aData[3],(now-(3600*24*365*nbAnneeHisto*1000))),aData[4]],[Math.max(aData[5],(now-(3600*24*365*nbAnneeHisto*1000))),aData[6]]],
                                yAxis: 'secAxeValeurs',
                                lineWidth: aData[2],
                                enableMouseTracking : false,
                                zIndex : 3,
                                marker: {
                                    enabled: false
                                }              
                            };
                            
                            var lastDate = chart.get("valeurs").xData.slice(-1)[0];
                            var a = (aData[6]-aData[4])/(aData[5]-aData[3]);
                            var b = aData[4]-(a*aData[3]);
                            
                            trendSeries.data.push([lastDate,lastDate*a+b]);

                            chart.addSeries(trendSeries);
                            aChartSeriesID.push(trendSeries.id);
                            aAT[periode].push(aData[0]);*/   
                               
                        }
                        else if(aData.length == 6)
                        {
                            var lastDate = chart.get("valeurs").xData.slice(-1)[0];
                            
                            var atSeries = {
                                type : 'scatter',
                                color : aData[1],
                                id : aData[0],
                                data : [[Math.max(aData[3],(now-(3600*24*365*nbAnneeHisto*1000))),aData[4]],[lastDate,aData[4]]],
                                yAxis: 'mainAxeValeurs',
                                lineWidth: aData[2],
                                enableMouseTracking : false,
                                //zIndex : 3,
                                marker: {
                                    enabled: false
                                },
                                visible: $('#atButton').prop('checked')  
                            };
                            
                            chart.addSeries(atSeries);
                            aChartSeriesID.push(atSeries.id);
                                                       
                            var opacityVal = ((chart.get('mainAxeValeurs').toPixels(aData[4])-7<chart.plotBox.y)||(chart.get('mainAxeValeurs').toPixels(aData[4])+7>chart.plotBox.y+chart.plotBox.height)) ? 0 : 1;
                            
                            var textLabel = chart.renderer.text(aData[4].toFixed(parseInt(aData[5][1])),
                                                                Math.max(chart.plotBox.x,chart.xAxis[0].toPixels(aData[3]))+3,
                                                                chart.get('mainAxeValeurs').toPixels(aData[4])-2)
                            .css({
                                fontFamily : 'Tahoma',
                                fontSize: '11px',
                                color: 'white'
                            }).
                            attr({
                                id : 'text'+aData[0],
                                zIndex :4,
                            })
                            .add();
                            
                            chart.renderer.rect(textLabel.getBBox().x-3,
                                                textLabel.getBBox().y-2,
                                                textLabel.getBBox().width+6,
                                                textLabel.getBBox().height,
                                                0)
                            .attr({
                                fill: aData[1],
                                stroke: aData[1],
                                'stroke-width': 1,
                                opacity: opacityVal,
                                zIndex :3,
                                id : 'label'+aData[0]
                            })
                            .add();  
                            
                            aAtFlags[periode].push([aData[0],aData[3],aData[4]]);
                            aAT[periode].push(aData[0]);
                        }
                        else
                        {
                            var lastDate = chart.get("valeurs").xData.slice(-1)[0];
                            
                            var ligneIntSeries = {
                                type : 'scatter',
                                color : 'black',
                                id : "ligneInt"+idLigneInt+periode.toUpperCase(),
                                data : [[Math.max(aData[1],(now-(3600*24*365*nbAnneeHisto*1000))),aData[2]],[lastDate,aData[2]]],
                                yAxis: 'mainAxeValeurs',
                                lineWidth: 1,
                                dashStyle: 'ShortDash',
                                enableMouseTracking : false,
                                //zIndex : 3,
                                marker: {
                                    enabled: false
                                },
                                visible: $('#atButton').prop('checked')   
                            };
                               
                            chart.addSeries(ligneIntSeries);
                            aChartSeriesID.push(ligneIntSeries.id);
                            
                            var opacityVal = ((chart.get('mainAxeValeurs').toPixels(aData[2])-7<chart.plotBox.y)||(chart.get('mainAxeValeurs').toPixels(aData[2])+7>chart.plotBox.y+chart.plotBox.height)) ? 0 : 1;
                            var nbChar = parseInt(Math.log10(aData[2]))+parseInt(aData[3][1]);
                            
                            var textLabel = chart.renderer.text(aData[2].toFixed(parseInt(aData[3][1])),
                                                                Math.max(chart.plotBox.x,chart.xAxis[0].toPixels(aData[1]))+3,
                                                                chart.get('mainAxeValeurs').toPixels(aData[2])-2)
                            .css({
                                fontFamily : 'Tahoma',
                                fontSize: '11px',
                                color: 'black'
                            }).
                            attr({
                                id : 'textLigneInt'+idLigneInt+periode.toUpperCase(),
                                zIndex :4,
                            })
                            .add();
                            
                            chart.renderer.rect(textLabel.getBBox().x-3,
                                                textLabel.getBBox().y-2,
                                                textLabel.getBBox().width+6,
                                                textLabel.getBBox().height,
                                                0)
                            .attr({
                                fill: 'white',
                                stroke: 'black',
                                'stroke-width': 1,
                                opacity: opacityVal,
                                zIndex :3,
                                id : 'labelLigneInt'+idLigneInt+periode.toUpperCase()
                            })
                            .add();  
                            
                            aAtFlags[periode].push(['LigneInt'+idLigneInt+periode.toUpperCase(),aData[1],aData[2]]);
                            aAT[periode].push("ligneInt"+idLigneInt+periode.toUpperCase());
                            
                            idLigneInt++;    
                        }   
                    });  
                }
            });   
        }  
         
        $.each(aAT['day'],function(index,id){
            chart.get(id).update({
                visible: ((periode=="day")&&($('#atButton').prop('checked')))   
            },
            false);    
        });
        $.each(aAT['week'],function(index,id){
            chart.get(id).update({
                visible: ((periode=="week")&&($('#atButton').prop('checked')))   
            },
            false);    
        });   
            
        chart.redraw();                                     
    });
        
    $('#logScale').change(function()
    {   
        var newType = (this.checked) ? 'logarithmic' : 'linear';
        chart.get('mainAxeValeurs').update({
            type: newType
        },false);
                 
     });
     
    $('#atButton').change(function()
    {
        var aCycle = ($('#periode').val()=='day') ? ['DAY','CT','MT'] : ['WEEK','LT'];
            aSeriesToUpdate = array_diff(aChartSeriesID,["valeurs","volumes","MMA20","MMA50","MMA100","MMA20V"]);
        $.each(aSeriesToUpdate,function(index,idSeries){
            var bInArrayCycle = false;
            $.each(aCycle,function(index,cycle){
                bInArrayCycle = bInArrayCycle || (idSeries.indexOf(cycle)>=0);    
            });
            if(chart.get(idSeries)&&bInArrayCycle)
            {
                chart.get(idSeries).update({
                    visible: $('#atButton').prop('checked')
                },
                false);
            }    
        });
        chart.redraw();
        
    });
        
}

function refreshLastData(codeZB,externcode,inDiv)
{
    var chart = $("#"+inDiv).highcharts();

    $.ajax({url : document.location.origin+"/mods_a/charts/latestData.php",
        context : document.body,
        async : true,
        data : {CODEZB : codeZB, EXTERN_CODE: externcode},
        type : 'GET',
        success : function(data)
        {
            var aDataQuote;    
            try
            {
                aDataQuote = JSON.parse(data)    
            }
            catch(e)
            {
                console.log("erreur JSON parse : "+e);
                console.log("data received : "+data);
                return false;
            }
            
            var seriesVolumes = chart.get("volumes"),
                seriesValeur = chart.get("valeurs");
 
            if(seriesValeur)
            {
                var lastPoint = seriesValeur.options.data[seriesValeur.options.data.length-1],
                    lastPointDate = new Date(lastPoint[0]),
                    lastDataDate = new Date(aDataQuote[0]);
                    
                if((lastPointDate.getDate()==lastDataDate.getDate())&&(lastPointDate.getMonth()==lastDataDate.getMonth())&&(lastPointDate.getFullYear()==lastDataDate.getFullYear()))
                {
                    lastPoint[1] = aDataQuote[1];
                    lastPoint[2] = aDataQuote[2];
                    lastPoint[3] = aDataQuote[3];
                    lastPoint[4] = aDataQuote[4];
                    
                }
                else
                {
                    seriesValeur.options.data.push([aDataQuote[0],aDataQuote[1],aDataQuote[2],aDataQuote[3],aDataQuote[4]]);   
                }            
            
                seriesValeur.setData(seriesValeur.options.data,false);
            }
            
            if(seriesVolumes&& aDataQuote[5])
            {
                var lastPoint = seriesVolumes.options.data[seriesVolumes.options.data.length-1],
                    lastPointDate = new Date(lastPoint[0]),
                    lastDataDate = new Date(aDataQuote[0]);
                    
                if((lastPointDate.getDate()==lastDataDate.getDate())&&(lastPointDate.getMonth()==lastDataDate.getMonth())&&(lastPointDate.getFullYear()==lastDataDate.getFullYear()))
                {
                    lastPoint[1] = aDataQuote[5];
                }
                else
                {
                    seriesVolumes.options.data.push([aDataQuote[0],aDataQuote[5]]);
                }
                
                seriesVolumes.setData(seriesVolumes.options.data,false);    
            }
            
            chart.redraw();
        }
     });                                                                                  
}

function drawGraphSousJacent(aCodeZB,aNames,inDiv,decimalsToDisplay,aWords,animated,bIsMobile)
{
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    animated = (typeof animated === "undefined") ? false : animated;
    
    (function (H) {
    var Axis = H.Axis,
        inArray = H.inArray,
        wrap = H.wrap;

    wrap(Axis.prototype, 'adjustTickAmount', function (proceed) {
        var chart = this.chart,
            primaryAxis = chart[this.coll][0],
            primaryThreshold,
            primaryIndex,
            index,
            newTickPos,
            threshold;

        // Find the index and return boolean result
        function isAligned(axis) {
            index = inArray(threshold, axis.tickPositions); // used in while-loop
            return axis.tickPositions.length === axis.tickAmount && index === primaryIndex;
        }

        if (chart.options.chart.alignThresholds && this !== primaryAxis) {
            primaryThreshold = (primaryAxis.series[0] && primaryAxis.series[0].options.threshold) || 0;
            threshold = (this.series[0] && this.series[0].options.threshold) || 0;

            primaryIndex = primaryAxis.tickPositions && inArray(primaryThreshold, primaryAxis.tickPositions);

            if (this.tickPositions && this.tickPositions.length &&
                    primaryIndex > 0 &&
                    primaryIndex < primaryAxis.tickPositions.length - 1 &&
                    this.tickAmount) {

                // Add tick positions to the top or bottom in order to align the threshold
                // to the primary axis threshold
                while (!isAligned(this)) {

                    if (index < primaryIndex) {
                        newTickPos = this.tickPositions[0] - this.tickInterval;
                        this.tickPositions.unshift(newTickPos);
                        this.min = newTickPos;
                    } else {
                        newTickPos = this.tickPositions[this.tickPositions.length - 1] + this.tickInterval;
                        this.tickPositions.push(newTickPos);
                        this.max = newTickPos;
                    }
                    proceed.call(this);
                }
            }

        } else {
            proceed.call(this);
        }
    });
}(Highcharts)); 
        
    var options = {
        chart : {
            alignThresholds: true,
            renderTo : inDiv,       
            style :
            {
                fontFamily : 'Arial, Helvetica, Sans-Serif'
            },
            events: {
                load: function(){   
                    if(this.chartHeight < 500)
                        return;
                                              
                    var imageHeight = 25;
                    var imageWidth = 240;
                    
                    this.renderer.image("https://www.zonebourse.com/images/pdf_Report/"+aWords[0].capitalize()+".png",70,55,imageWidth,imageHeight).css({opacity: 0.5}).attr({zIndex: 2}).add();
                }
            }            
        },
        
        colors: ["#1a324a",'#F34348','#90ed7d','#f7a35c','#8085e9','#612332','#e4d354','#3480de','#28bd48','#91e8e1'], 

        exporting : {
            enabled : false
        },

        credits : {
            enabled : true,
            href : null,
            text : '\u00A9'+aWords[0],
            style : {
                fontSize : '12px'               
            } 
        },               

        legend : {
            enabled : true
        },

        tooltip: {
            backgroundColor: {
                linearGradient: {
                    x1: 0,
                    y1: 0,
                    x2: 0,
                    y2: 1
                },
                stops: [
                    [0, 'white'],
                    [1, '#EEE']
                ]
            },
            borderColor: 'gray',
            borderWidth: 1,
            borderRadius: 5,
            shared : true,
            headerFormat: '<span style="font-size:12px">'+aWords[1]+' : <b>{point.key}</b></span><br><table style="min-width:150px;">',
            footerFormat: '</table>',
            useHTML: true                          
        },
        
        rangeSelector : configSelectorLong,
        
        responsive: {
            rules:[{
                chartOptions: {
                    chart: {
                        spacingBottom: null,
                        marginBottom: 35,
                        
                    },
                    navigator: {
                        enabled: false
                    },
                    rangeSelector: {
                        inputEnabled: false
                    }
                    ,
                    scrollbar: {
                        enabled: false
                    }
                },
                condition: {
                    maxHeight: 500
                }
            }]    
        },
        
        navigator : { 
            xAxis : {  
                labels: {
                    style : {
                        color: "black"
                    }
                }
            }
        }, 

        xAxis : [
        {
            labels : {   
                align : 'center',
                style : {
                    color: "black"
                },                         
            },
            lineWidth : 1,
            lineColor : 'black',
            gridLineColor : "#ededed",
            gridLineWidth: 1,
            tickLength : 5,
            tickColor : 'black',       
            title : null,
            showFirstLabel: true,
            range: 1000*3600*24*365  
        }, 
        {
            lineWidth : 1,
            lineColor : 'black',
            linkedTo: 0,       
            opposite : true,
            labels : {
                enabled : false
            },
            title: null,
            tickLength : 0    
        }], 

        yAxis : [{ 
            id: 'leftAxis',
            lineWidth : 1,   
            gridLineColor : "#ededed",
            title : {
                text: aNames[0],
                style : {
                    color: "black"
                }
            },                            
            opposite : false, 
            lineColor : 'black',
            tickWidth : 1,
            tickLength : 5,
            tickColor : 'black',
            labels : {    
                format : '{value}%',
                verticalAlign : 'middle',
                style : {
                    color: "black"
                }          
            },                       
        },
        {
            id: 'rightAxis',
            lineWidth : 1,   
            gridLineColor : "#ededed",
            title : {
                text: aNames[1],
                style : {
                    color: "black"
                }
            },          
            lineColor : 'black',
            tickWidth : 1,
            tickLength : 5,
            tickColor : 'black',
            labels : {    
                format : '{value}%',
                verticalAlign : 'middle',
                style : {
                    color: "black"
                }          
            }, 
            offset : 20                       
        }],

        plotOptions : {
            series: {
                compare: "percent",
                dataGrouping: {
                    dateTimeLabelFormats :{
                        day: [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                },
                states: {
                    hover: {
                        lineWidth: 2
                    }
                },
                tooltip : {
                    pointFormat : '<tr><td nowrap style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.'+decimalsToDisplay+'f}({point.change}%)</b></td></tr>'
                }       
            },
            line: {
                lineWidth : 2
            }
        }                
    };
    
    var chart = new Highcharts.StockChart(options);     
        
    if(animated)
        chart.showLoading();

    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        context : document.body,
        async : true,
        data : {aCodeZB : aCodeZB, type : "ssjacent"},
        type : 'GET',
        success : function(data)
        {
        var aDataQuote;    
            try
            {
                aDataQuote = JSON.parse(data)    
            }
            catch(e)
            {
                $('#'+inDiv).css('display','none');
                console.log("erreur JSON parse : "+e);
                console.log("data received : "+data);
                return;
            }
            
            var seriesPD = {
                id : 'produitDer',
                name : aNames[0],
                yAxis: 0,
                legendIndex: 0,
                data : aDataQuote[0], 
                dataGrouping: {
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                }                
            };
            
            var seriesSSJ = {
                id : 'sous-jacent',
                name : aNames[1],
                yAxis: 1,
                legendIndex: 1,
                data : aDataQuote[1],   
                dataGrouping: {
                    units:[
                        ['day',[1]]
                    ],
                    dateTimeLabelFormats: {
                        day : [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                }                 
            };
            
            chart.addSeries(seriesPD,aDataQuote[1].length==0,aDataQuote[1].length==0);
            
            if(aDataQuote[1].length>0)
                chart.addSeries(seriesSSJ,true,true);
            
            chart.rangeSelector.buttons[2].element.onclick()      
            
            chart.hideLoading();
        }
    });            
}

function drawGraphFonds(codeZB,name,inDiv,aWords,animated,bIsMobile)
{
    animated = (typeof animated === "undefined") ? false : animated;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    
    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        context : document.body,
        async : animated,
        data : {codeZB : codeZB, type : "chart", fields : "Date,Close"},
        type : 'GET'
    })
    .done(function(data)
    {    
        try
        {
            aDataQuote = JSON.parse(data)    
        }
        catch(e)
        {                                        
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }                                                               
            
        var options = {
            chart : {
                renderTo : inDiv,
                marginTop : 10,
                spacingTop : 10,
                spacingBottom: 20         
            }, 
            
            credits : {
                enabled : true,
                href : null,
                text : '\u00A9'+aWords[0],
                style : {
                    fontSize : '12px'               
                } 
            },               

            legend : {
                enabled : false
            },  
            
            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                shared : true,
                headerFormat: '<span style="font-size:12px">'+aWords[1]+' : <b>{point.key}</b></span><br><table style="min-width:150px;">',
                footerFormat: '</table>',
                useHTML: true                          
            },
            
            responsive: {
                rules: [{
                    chartOptions: {
                        rangeSelector: configSelectorMini,
                        xAxis : [{ 
                        },
                        {
                            visible: false
                        }],
                        yAxis : [{
                            id: 'leftAxis',
                            visible: false
                        },{
                            id: 'rightAxis',
                            labels: {
                                align: "left",
                                verticalAlign : 'middle'
                            },
                            offset : 10
                        }],                          
                    },
                    condition: {
                        maxWidth: 660    
                    }
                },
                {
                    chartOptions: {
                        exporting : {
                            enabled : true,
                            buttons: {
                                contextButton: {
                                    theme: {
                                        fill: "#004EFF",
                                        states: {
                                            hover: {
                                                fill: '#004EFF'
                                            },
                                            select: {
                                                fill: '#004EFF'
                                            }
                                        }                                                
                                    },
                                    symbolStroke: "white",
                                    symbolStrokeWidth: 2,
                                    menuItems: [{
                                        textKey: "printChart",
                                        onclick: function (){this.print()}
                                    },
                                    {
                                        separator: true
                                    },
                                    {
                                        textKey: "downloadPNG",
                                        onclick: function (){this.exportChart()}   
                                    },
                                    {
                                        textKey: "downloadJPEG",
                                        onclick: function (){this.exportChart({type:"image/jpeg"})}   
                                    },
                                    {
                                        textKey: "downloadSVG",
                                        onclick: function (){this.exportChart({type:"image/svg+xml"})}   
                                    }]
                                }
                            }
                        }
                    },
                    condition: {
                        minWidth: 660
                    }
                }]      
            },
            
            rangeSelector : configSelectorLong,
            
            navigator : {
            series :{
                lineColor:'#4B6793'
            }, 
                xAxis : {  
                    labels: {
                        style : {
                            color: "black"
                        }
                    }
                },
                baseSeries: codeZB
            }, 

            xAxis : [
            {
                labels : {   
                    align : 'center',
                    style : {
                        color: "black"
                    },                         
                },
                lineWidth : 1,
                lineColor : 'black',
                gridLineColor : "#ededed",
                gridLineWidth: 1,
                tickLength : 5,
                tickColor : 'black',       
                title : null,
                showFirstLabel: true,
                range: 1000*3600*24*365  
            }, 
            {
                lineWidth : 1,
                lineColor : 'black',
                linkedTo: 0,       
                opposite : true,
                labels : {
                    enabled : false
                },
                title: null,
                tickLength : 0    
            }], 

            yAxis : [{
                id: 'leftAxis',
                lineWidth : 1,   
                gridLineColor : "#ededed",
                opposite : false, 
                lineColor : 'black',
                tickWidth : 1,
                tickLength : 5,
                tickColor : 'black',
                labels : {    
                    format : '{value}%',
                    verticalAlign : 'middle',
                    style : {
                        color: "black"
                    }          
                },                       
            },
            {
                id: 'rightAxis',
                lineWidth : 1,   
                gridLineColor : "#ededed",
                lineColor : 'black',
                tickWidth : 1,
                tickLength : 5,
                tickColor : 'black',
                linkedTo : 0,
                labels : {    
                    format : '{value}%',
                    verticalAlign : 'middle',
                    style : {
                        color: "black"
                    }          
                },
                offset : 20                       
            }],
            
            plotOptions : {
                series: { 
                    turboThreshold: 0,
                    compare: 'percent',
                    dataGrouping: {
                        dateTimeLabelFormats :{
                            day: [dateFormatDay],
                            week: [dateFormatWeek]
                        }
                    },
                    states: {
                        hover: {
                            lineWidth: 2
                        }
                    }       
                },
                line: {
                    lineWidth : 2
                }
            },
            
            series: [{
            color:'#4B6793',                          
                type : 'line', 
                name : name, 
                id: codeZB,  
                data : aDataQuote,
                yAxis: 0,
                //zIndex : aValues.length,
                tooltip : {
                    pointFormat : '<tr><td nowrap style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.change}%</b></td></tr>'
                }            
            }]
        };
        
        var chart = new Highcharts.StockChart(options);    
    }); 
}