/*  */
function getIdNotation(attrValues)
{
  var str = attrValues[1];
  var regex_id_notation = (/ID_NOTATION=(\d+)/);
  var found = attrValues[1].match(regex_id_notation);
  if (found) {
        return found[1];
  } else {
     return false;    
  } 
}

function clearElement(span_element,classn)
{
 if (document.getElementById(span_element))
  document.getElementById(span_element).className = classn;   
}

/* Palmares outils */ 
function myPalmaresFilter(Id, event, row, attrNames, attrValues) {
 var table = document.getElementById("tabPalmares");   
 var rows = table.getElementsByTagName("tr");
 var cels = rows[row].getElementsByTagName("td");
 var sClassName = rows[row].className;
 //id="iAL2" onmouseover="shInfBul(150,200,'iAL2',4647)" onmouseout="HideInfoBul()"
 var str = attrValues[0];
    //alert(row);
    if (str.length > 20) str = str.substr(0, 20) + "..";
    var sIdNotation = getIdNotation(attrValues);
    if (sIdNotation) {
        rows[row].onclick=function(){document.location.href='/mods_a/stock/getfiche.php?ID_NOTATION=' + sIdNotation};
        rows[row].onmouseover=function(){this.className='Rollover1';majZBScan('IN'+sIdNotation,'')};
        rows[row].onmouseout=function(){this.className=sClassName}; 
        return '<a title="' + attrValues[0] + '" href="/mods_a/stock/getfiche.php?ID_NOTATION=' + sIdNotation + '">' + str + '</a>';
    } else {
        return str ;    
    }  
}

/* Palmares Home */ 
function myPalHomeFilter(Id, event, row, attrNames, attrValues) { 
 var str = attrValues[0];
  
 if (str.length > 14) str = str.substr(0, 14) + "..";
 var sIdNotation = getIdNotation(attrValues);
 if (sIdNotation) {
        return '<a title="' + attrValues[0] + '" href="/mods_a/stock/getfiche.php?ID_NOTATION=' + sIdNotation + '">' + str + '</a>';
 } else {
        return str ;    
 }  
}

/* Global */ 
function myFilter(Id, event, row, attrNames, attrValues) {
   var sMyValue;
   var sMyNames;
   sMyValue = String(attrValues);
   sMyNames = String(attrNames);
   if (attrNames == "TOTAL_VOLUME" || attrNames == "VOLUME_RANGE")
   {
    return sMyValue.replace(/\./g," ");  
   }
   else if (attrNames == "PERFORMANCE_PCT" || attrNames == "CN_DIFF_REL_RANGE")
   {
    return sMyValue.replace(/\,/g,".");  
   }
   else if (attrNames == "DATETIME_PRICE")
   {
    return sMyValue.substring(8,10)+"/"+sMyValue.substring(5,7)+" "+sMyValue.substring(11,19);  
   }
   else if (attrNames == "DATETIME_ASK,DATETIME_BID")
   {
    if (attrValues[0]>attrValues[1])
     sMyValue = String(attrValues[0]);
    else
     sMyValue = String(attrValues[1]); 
    return sMyValue.substring(8,10)+"/"+sMyValue.substring(5,7)+" "+sMyValue.substring(11,19);  
   }
   else if (attrNames == "ASK,BID")
   {
    var iBid = parseFloat(attrValues[0]);
    var iAsk = parseFloat(attrValues[1]);
    var myRes = (iBid+iAsk)/2;
    if (myRes>0)
     window.setTimeout('clearElement("JS_PRICE", "fvPrice cPos")', 1);  
    else if(myRes<0)
     window.setTimeout('clearElement("JS_PRICE", "fvPrice cNeg")', 1);   
    window.setTimeout('clearElement("JS_PRICE", "fvPrice")', 1500);   
    return(myRes.toFixed(2));
   }
   else if (attrNames == "PERFORMANCE_PCT,ASK,BID")
   {
    var myPerf = 0.0;
    var iBid = parseFloat(attrValues[1]);
    var iAsk = parseFloat(attrValues[2]);
    var myRes = (iBid+iAsk)/2;
    if (aStreamValue[0] != 0)
    {
      var drV = parseFloat(aStreamValue[0])
      myPerf = (myRes.toFixed(2)-drV)*100/drV;
    }
    var sRet = "";
    if (myPerf>0)
    {
     sRet = "+";
     window.setTimeout('clearElement("JS_PERFORMANCE_PCT", "fvPerf cPos")', 1);
    }    
    else if(myPerf<0)
     window.setTimeout('clearElement("JS_PERFORMANCE_PCT", "fvPerf cNeg")', 1);   
    else
     window.setTimeout('clearElement("JS_PERFORMANCE_PCT", "fvPerf cNeu")', 1);      
    sRet += myPerf.toFixed(2)+"%"
    return(sRet);
   }
   else if (attrNames == "PERFORMANCE_PCT,PRICE")
   {
    var myPerf = 0.0;
    var myRes = parseFloat(attrValues[1]);
    if (aStreamValue[0] != 0)
    {
      var drV = parseFloat(aStreamValue[0])
      myPerf = (myRes.toFixed(2)-drV)*100/drV;
    }
    var sRet = "";
    if (myPerf>0)
    {
     sRet = "+";
     window.setTimeout('clearElement("JS_PERFORMANCE_PCT", "fvPerf cPos")', 1);
    }    
    else if(myPerf<0)
     window.setTimeout('clearElement("JS_PERFORMANCE_PCT", "fvPerf cNeg")', 1);   
    else
     window.setTimeout('clearElement("JS_PERFORMANCE_PCT", "fvPerf cNeu")', 1);      
    sRet += myPerf.toFixed(2)+"%"
    return(sRet);
   }
   else if (attrNames == "PERFORMANCE_PCT,PRICE,DAX")
   {
    var myPerf = 0.0;
    var myRes = parseFloat(attrValues[1]);
    if (aStreamValue[0] != 0)
    {
      var drV = parseFloat(aStreamValue[0])
      myPerf = (myRes.toFixed(2)-drV)*100/drV;
    }
    var sRet = "";
    var sOldPerf = document.getElementById("JS_PERFORMANCE_PCT_DAX").innerHTML;
  /*  if (myPerf>sOldPerf)
     window.setTimeout('clearElement("JS_PERFORMANCE_PCT_DAX", "right sBgPos large45")', 1);  
    else if(myPerf<sOldPerf)
     window.setTimeout('clearElement("JS_PERFORMANCE_PCT_DAX", "right sBgNeg large45")', 1);
    else
     window.setTimeout('clearElement("JS_PERFORMANCE_PCT_DAX", "right sBgNeu large45")', 1);*/     
    if (myPerf>0)
    {
     sRet = "+";
     window.setTimeout('clearElement("JS_PERFORMANCE_PCT_DAX", "right cPos large45")', 1800);
    }    
    else if(myPerf<0)
     window.setTimeout('clearElement("JS_PERFORMANCE_PCT_DAX", "right cNeg large45")', 1800);   
    else
     window.setTimeout('clearElement("JS_PERFORMANCE_PCT_DAX", "right cNeu large45")', 1800);      
    sRet += myPerf.toFixed(2)+"%"
    return(sRet);
   }                                 
   else if (attrNames == "NAME_SECURITY,QUOTE_REQUEST")
   {
    var str = attrValues[0];
    //alert(row);
    if (str.length > 20) str = str.substr(0, 20) + "..";
      var regex_id_notation = (/ID_NOTATION=(\d+)/);
      var found = attrValues[1].match(regex_id_notation)
    if (found) {
        return '<a title="' + attrValues[0] + '" href="/mods_a/stock/getfiche.php?ID_NOTATION=' + found[1] + '">' + str + '</a>';
    } else {
        return str ;    
    }
   }
   else if (attrNames == "PRICE,EUR")
   {
    return attrValues[0]+"�";
   }
   else if (sMyNames.substr(0,11) == "PRICE,PERFV")
   {
    var iLineData;
    var iLineDataS;
    var iLineDataSense;
    iLineData = parseInt(sMyNames.substr(11,3))+1000;
    iLineDataS = parseInt(sMyNames.substr(11,3));
    iLineDataSense = parseInt(sMyNames.substr(11,3))+2000;
     
    var myPerf = 0.0;
    var myRes = parseFloat(attrValues[0]);
    var mySens = parseFloat(aStreamValue[iLineDataSense])
    //alert(attrValues[0]);
    
    if (aStreamValue[iLineData] != 0)
    {
      var drV = parseFloat(aStreamValue[iLineData])
      //alert("("+myRes+"-"+drV+")/"+drV*100);
      myPerf = (myRes-drV)/drV*100*mySens;
    }
    var sRet = "";
    if (myPerf>0)
    {
     sRet = "+";
     window.setTimeout('clearElement("PERFV_'+iLineDataS+'", "center cPos")', 1800);
    }    
    else if(myPerf<0)
     window.setTimeout('clearElement("PERFV_'+iLineDataS+'", "center cNeg")', 1800);   
    else
     window.setTimeout('clearElement("PERFV_'+iLineDataS+'", "center cNeu")', 1800);      
    sRet += myPerf.toFixed(2)+"%"      
    return(sRet);  
   }
   return attrValues;
}

/*****************************************************************/
/* LIVE 102012                                                   */
/*****************************************************************/
var oldFVprice = 0;
var oldListprice = new Array();
var FVPriceTO;
var session_status = new myMDGSessionStatus();
function myMDGSessionStatus() {};
myMDGSessionStatus.prototype.handleStatus = function(status) {
  var tag  = document.getElementById("status_field");
  if (tag)
  {
   var code = status.getStatusCode();
   if      ((code & MDG.SessionStatus.UNDEFINED)       != 0 ) tag.innerHTML = '<img src="/images/icones/led_g.png">';
   else if ((code & MDG.SessionStatus.INIT)            != 0 ) tag.innerHTML = '<img src="/images/icones/led_jc.png">';
   else if ((code & MDG.SessionStatus.OK_POLL)         != 0 ) tag.innerHTML = '<img src="/images/icones/led_j.png">';
   else if ((code & MDG.SessionStatus.OK_PULL)         != 0 ) tag.innerHTML = '<img src="/images/icones/led_b.png">';
   else if ((code & MDG.SessionStatus.OK_PUSH)         != 0 ) tag.innerHTML = '<img src="/images/icones/led_v.png">';
   else if ((code & MDG.SessionStatus.ERROR)           != 0 ) tag.innerHTML = '<img src="/images/icones/led_rc.png">';
   else if ((code & MDG.SessionStatus.LOST_CONNECTION) != 0 ) tag.innerHTML = ' <img src="/images/icones/led_r.png">';
   else tag.innerHTML = '<img src="/images/icones/led_g.png">';
  }
};

function calculateTimeout(expiryTime, timeDifference)
{
    var timeDiff = timeDifference * 1000;
    var requestTime = expiryTime + timeDiff;
    var timestamp = new Date();
    var timeout = requestTime - timestamp.getTime();
    return timeout;
}

function convertTZ(date, tzString) {
    return new Date((typeof date === "string" ? new Date(date) : date).toLocaleString("en-US", {timeZone: tzString}));   
}

function dateToFVDate(date)
{
    if (SiteLangage && SiteLangage==2)
     date = convertTZ(date, "America/New_York");
    var h = date.getHours();
    var i = date.getMinutes();
    var s = date.getSeconds();
    var d = date.getDate();
    var m = date.getMonth()+1;
    if (SiteLangage && SiteLangage==2)
    {
     var ap = "am";
     if (h>=12)
     {
      h-=12;
      ap="pm";
     }
     return ''+(m<=9?'0'+m:m)+'/'+(d<=9?'0'+d:d)+' '+(h<=9?'0'+h:h)+':'+(i<=9?'0'+i:i)+':'+(s<=9?'0'+s:s)+" "+ap;
    }
    else
     return ''+(d<=9?'0'+d:d) +'/'+(m<=9?'0'+m:m)+' '+(h<=9?'0'+h:h)+':'+(i<=9?'0'+i:i)+':'+(s<=9?'0'+s:s);
}

function ZBJS_colorPrice(price,line)
{
    if (line==2)
    {
      window.clearTimeout(FVPriceTO); 
      if (price>oldFVprice)
       FVPriceTO=window.setTimeout('clearElement("zbjsfv'+line+'_dr", "cPos")', 1);  
      else if(price<oldFVprice)
       FVPriceTO=window.setTimeout('clearElement("zbjsfv'+line+'_dr", "cNeg")', 1);
      FVPriceTO=window.setTimeout('clearElement("zbjsfv'+line+'_dr", "colorBlack")', 1800); 
    }
    else if (oldFVprice!=0)
    {
      window.clearTimeout(FVPriceTO); 
      if (price>oldFVprice)
       FVPriceTO=window.setTimeout('clearElement("zbjsfv'+line+'_dr", "fvPrice cPos")', 1);  
      else if(price<oldFVprice)
       FVPriceTO=window.setTimeout('clearElement("zbjsfv'+line+'_dr", "fvPrice cNeg")', 1);
      FVPriceTO=window.setTimeout('clearElement("zbjsfv'+line+'_dr", "fvPrice colorBlack")', 1800); 
    }
    oldFVprice = price;   
}

function ZBJS_BGcolorPrice(price,name,perf,inv)
{
    if (!oldListprice[name])
    {
     oldListprice[name] = new Array();
     oldListprice[name]["class"] = document.getElementById(name).className; 
    }
    
    var sAddClass = "";
    if (perf!=false)
    {
     if (perf>0)
      sAddClass = " cPos";    
     else if(perf<0)
      sAddClass = " cNeg";    
     else
      sAddClass = " cNeu"; 
    } 
    if (oldListprice[name]["dr"]!=0)
    {
      window.clearTimeout(oldListprice[name]["timeout"]); 
      if (price>oldListprice[name]["dr"])
      {
       if (inv)
        oldListprice[name]["timeout"]=window.setTimeout('clearElement("'+name+'", "'+oldListprice[name]["class"]+sAddClass+' sBgNeg")', 1);
       else
        oldListprice[name]["timeout"]=window.setTimeout('clearElement("'+name+'", "'+oldListprice[name]["class"]+sAddClass+' sBgPos")', 1);
       oldListprice[name]["timeout"]=window.setTimeout('clearElement("'+name+'", "'+oldListprice[name]["class"]+sAddClass+'")', 1800); 
      } 
      else if(price<oldListprice[name]["dr"])
      {
       if (inv)
        oldListprice[name]["timeout"]=window.setTimeout('clearElement("'+name+'", "'+oldListprice[name]["class"]+sAddClass+' sBgPos")', 1);
       else
        oldListprice[name]["timeout"]=window.setTimeout('clearElement("'+name+'", "'+oldListprice[name]["class"]+sAddClass+' sBgNeg")', 1);
       oldListprice[name]["timeout"]=window.setTimeout('clearElement("'+name+'", "'+oldListprice[name]["class"]+sAddClass+'")', 1800);
      }
      else
       oldListprice[name]["timeout"]=window.setTimeout('clearElement("'+name+'", "'+oldListprice[name]["class"]+sAddClass+'")', 1) 
    }
    oldListprice[name]["dr"] = price;   
}

/****************/
/* ZBLive START */
/****************/

function ZBL_priceFV(data,bCBK,bCBKPreAfterMarket)
{
  try
  {
     var value = data.PRICE;
     var valuePerf=data.PERFORMANCE_PCT
     var myDate=new Date(data.DATETIME_PRICE*1000);
     var addID = "";
     
     if (isNaN(value))
      return;
      
     if(bCBKPreAfterMarket==true)
      addID="_PAM";
     
     document.getElementById("zbjsfv_dr"+addID).innerHTML = value;
     if(bCBKPreAfterMarket!=true)
      ZBJS_colorPrice(value,"");
     var sRet="";
     if (bCBK==true && bCBKPreAfterMarket==true)
     {
      if (!isNaN(value) && aStreamValue[2] != 0)
      {
       var drV = parseFloat(aStreamValue[2]);
       var myPerf = (value-drV)*100/drV;
      }   
     }
     else if (bCBK==true)
     {
      if (!isNaN(value) && aStreamValue[0] != 0)
      {
       var drV = parseFloat(aStreamValue[0]);
       var myPerf = (value-drV)*100/drV;
      }   
     }
     else
      var myPerf = parseFloat(valuePerf);
     
     if (isNaN(value) || isNaN(myPerf))
      return;
     
     if (myPerf>0)
     {
      sRet = "+";
      window.setTimeout('clearElement("zbjsfv_pf'+addID+'", "fvPerf cPos")', 1);
     }    
     else if(myPerf<0)
      window.setTimeout('clearElement("zbjsfv_pf'+addID+'", "fvPerf cNeg")', 1);   
     else
      window.setTimeout('clearElement("zbjsfv_pf'+addID+'", "fvPerf cNeu")', 1); 
     sRet += myPerf.toFixed(2)+"%";
     document.getElementById("zbjsfv_pf"+addID).innerHTML = sRet;
     if(bCBKPreAfterMarket!=true)
      document.getElementById("zbjsfv_dt"+addID).innerHTML = dateToFVDate(myDate);
     //document.getElementById("zbjsfv_dtl").innerHTML = dateToFVDate(myDate);
  }
  catch(err)
  {
   console.log(err);
  }
  return "";
}

function ZBL_priceFV2(data)
{
  try
  {
     var iBid = parseFloat(data.BID);
     var iAsk = parseFloat(data.ASK);
     
     var lBid = data.BID.toString().split(".")[1].length;
     var lAsk = data.ASK.toString().split(".")[1].length;
     
     var iPrecision = 2;
     if (lBid>iPrecision)
       iPrecision = lBid;
     if (lAsk>iPrecision)
       iPrecision = lAsk; 
     
     var valueDateBid=data.DATETIME_BID;
     var valueDateAsk=data.DATETIME_ASK;
     
     if (valueDateBid>valueDateAsk)
      valueDate=valueDateBid;
     else
      valueDate=valueDateAsk;
     
     var myDate=new Date(valueDate*1000,);
     var myRes = (iBid+iAsk)/2;     
     if (!isNaN(myRes))
     {
      document.getElementById("zbjsfv_dr").innerHTML = myRes.toFixed(iPrecision);
      ZBJS_colorPrice(myRes,"");
     }
     if (!isNaN(myRes) && aStreamValue[0] != 0)
     {
      var drV = parseFloat(aStreamValue[0]);
      var sRet="";
      var myPerf = (myRes-drV)*100/drV;
      if (myPerf>0)
      {
       sRet = "+";
       window.setTimeout('clearElement("zbjsfv_pf", "fvPerf cPos")', 1);
      }    
      else if(myPerf<0)
       window.setTimeout('clearElement("zbjsfv_pf", "fvPerf cNeg")', 1);   
     else
       window.setTimeout('clearElement("zbjsfv_pf", "fvPerf cNeu")', 1); 
      sRet += myPerf.toFixed(2)+"%";
      document.getElementById("zbjsfv_pf").innerHTML = sRet;
     }
     if (!isNaN(myDate))
      document.getElementById("zbjsfv_dt").innerHTML = dateToFVDate(myDate);
  }
  catch(err)
  {
   //alert(err);
  }
  return "";
}

function ZBL_Mutli(data,multiType,source)
{
  try
  {
   var value=data.PRICE;
   var high=data.HIGH;
   var low=data.LOW;
   var id_notation_tmp=data.ID_NOTATION;
   var valuePerf=data.PERFORMANCE_PCT;
   var noHighLow = false;
   if (source=="ttmzero") 
    id_notation_tmp = data.id;
   if (source=="msci") 
    id_notation_tmp = data.id;
   
   
   // Alternative DR
   if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation_tmp] != "undefined" && typeof aStreamValue[id_notation_tmp]['t'] != "undefined"  && aStreamValue[id_notation_tmp]['t'] == 2)
   {
     //var iBid = parseFloat(obj.getRawValue("BID"));
     //var iAsk = parseFloat(obj.getRawValue("ASK"));
     //var valueDateBid=obj.getValue("DATETIME_BID");
     //var valueDateAsk=obj.getValue("DATETIME_ASK");
     //debugger;
     var iBid = parseFloat(data.BID);
     var iAsk = parseFloat(data.ASK);
     var valueDateBid=data.DATETIME_BID;
     var valueDateAsk=data.DATETIME_ASK;
     noHighLow = true;
      
    if (iBid && iAsk && iBid!="_NA_" && iAsk!="_NA_" && Math.abs(valueDateBid-valueDateAsk)<900)
    {
     var myRes = (iBid+iAsk)/2;
     if (!isNaN(myRes) && typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation_tmp] != "undefined" && typeof aStreamValue[id_notation_tmp]['q'] != "undefined" && aStreamValue[id_notation_tmp]['q'] != 0) // q = close
     {
      var drV = parseFloat(aStreamValue[id_notation_tmp]['q']);
      valuePerf = (myRes-drV)*100/drV;
      value = myRes.toFixed(3);
     }
     else
      return "";
    }
    else
     return "";
   }
   // Alternative DR FONDS
   if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation_tmp] != "undefined" && typeof aStreamValue[id_notation_tmp]['t'] != "undefined"  && aStreamValue[id_notation_tmp]['t'] == 3)
   {
     myRes = value;
     if (!isNaN(myRes) && typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation_tmp] != "undefined" && typeof aStreamValue[id_notation_tmp]['q'] != "undefined" && aStreamValue[id_notation_tmp]['q'] != 0) // q = close
     {
      var drV = parseFloat(aStreamValue[id_notation_tmp]['q']);
      valuePerf = (myRes-drV)*100/drV;
      noHighLow = true;
     }
     else
      return "";
   }
   // PERF HOME
   if (document.getElementById("zbjsh_pfh_"+id_notation_tmp))
   {
    if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation_tmp] != "undefined")
    {
     var sRet="";
     var myPerf=0;
     if (aStreamValue[id_notation_tmp])
     {
      myPerf = (value - aStreamValue[id_notation_tmp])  * 100 / aStreamValue[id_notation_tmp];
     }
     if (myPerf>0)
      sRet = "+";
     sRet += myPerf.toFixed(2)+"%";
     ZBJS_BGcolorPrice(value,"zbjsh_pfh_"+id_notation_tmp,myPerf,false);
     document.getElementById("zbjsh_pfh_"+id_notation_tmp).innerHTML = sRet;
    }
   }
   // MORNING STAR
   if (multiType=='multiMS' || multiType=='multiMS2')
   {      
     var iBid = parseFloat(data.BID);
     var iAsk = parseFloat(data.ASK);
     
     var lBid = data.BID.toString().split(".")[1].length;
     var lAsk = data.ASK.toString().split(".")[1].length;
     
     var iPrecision = 2;
     if (lBid>iPrecision)
       iPrecision = lBid;
     if (lAsk>iPrecision)
       iPrecision = lAsk;  
     
     var myRes = (iBid+iAsk)/2;     
     if (!isNaN(myRes))
     {
      value = myRes.toFixed(iPrecision);
     }
     // 
     if (multiType=='multiMS2')
     {
        if (!isNaN(myRes) && typeof aStreamValue != "undefined" && typeof aStreamValue[data.ID_MORNINGSTAR] != "undefined" && typeof aStreamValue[data.ID_MORNINGSTAR]['q'] != "undefined" && aStreamValue[data.ID_MORNINGSTAR]['q'] != 0) // q = close
        {
          var drV = parseFloat(aStreamValue[data.ID_MORNINGSTAR]['q']);
          var myPerf = (myRes-drV)*100/drV;
          valuePerf = myPerf.toFixed(2);
          noHighLow = true;
        }
     }
     else
     {
         if (!isNaN(myRes) && typeof aStreamValue != "undefined" && typeof aStreamValue["multiMS"] != "undefined" && typeof aStreamValue["multiMS"][data.ID_MORNINGSTAR] != "undefined" &&  aStreamValue["multiMS"][data.ID_MORNINGSTAR] != 0)
         {
          var drV = parseFloat(aStreamValue["multiMS"][data.ID_MORNINGSTAR]);
          var myPerf = (myRes-drV)*100/drV;
          valuePerf = myPerf.toFixed(2);
         }
     }
     
     if (valuePerf>0)
      valuePerf = "+"+valuePerf;

     id_notation_tmp = data.ID_MORNINGSTAR;
   } 
   // PERF HOME TAB
   if (multiType.substring(0,6)=='multi3')
   {
           
           
           element = multiType.substring(7);
           if (document.getElementById("zbjsh_dr_"+element+"_"+id_notation_tmp))
           {
            value = parseFloat(value);
            document.getElementById("zbjsh_dr_"+element+"_"+id_notation_tmp).innerHTML = value;
            ZBJS_BGcolorPrice(value,"zbjsh_dr_"+element+"_"+id_notation_tmp,false,false);
           }
           if (document.getElementById("zbjsh_drR0_"+element+"_"+id_notation_tmp))
           {
            value = parseFloat(value);
            document.getElementById("zbjsh_drR0_"+element+"_"+id_notation_tmp).innerHTML = value.toFixed(0);
            ZBJS_BGcolorPrice(value.toFixed(0),"zbjsh_drR0_"+element+"_"+id_notation_tmp,false,false);
           }
           if (document.getElementById("zbjsh_pfh_"+element+"_"+id_notation_tmp))
           {
            if (Array.isArray(aStreamValue['multi']))
            {
             var sRet="";
             var myPerf=0;
             if (aStreamValue['multi'][id_notation_tmp])
             {
              myPerf = (value - aStreamValue['multi'][id_notation_tmp])  * 100 / aStreamValue['multi'][id_notation_tmp];
             }
             if (myPerf>0)
              sRet = "+";
             sRet += myPerf.toFixed(2)+"%";
             ZBJS_BGcolorPrice(value,"zbjsh_pfh_"+element+"_"+id_notation_tmp,myPerf,false);
             document.getElementById("zbjsh_pfh_"+element+"_"+id_notation_tmp).innerHTML = sRet;
            }
           }
   } 
    
   
   var id_notation_list = new Array();
   if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation_tmp] != "undefined" && typeof aStreamValue[id_notation_tmp]['m'] != "undefined")
   {
    for (var i=1;i<=aStreamValue[id_notation_tmp]['m'];i++)
    {
     id_notation_list[i-1] = id_notation_tmp+"_"+i;
    }
   }
   else
   {
    id_notation_list[0] = id_notation_tmp;
   }
   for (var i=0;i<id_notation_list.length;i++)
   {
       id_notation = id_notation_list[i];
       if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation] != "undefined" && typeof aStreamValue[id_notation]['x'] != "undefined")
         value= value * aStreamValue[id_notation]['x'];
       if (document.getElementById("zbjsh_dr_"+id_notation))
       {
        if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation] != "undefined" && typeof aStreamValue[id_notation]['c'] != "undefined")
         document.getElementById("zbjsh_dr_"+id_notation).innerHTML = value+aStreamValue[id_notation]['c']; 
        else
         document.getElementById("zbjsh_dr_"+id_notation).innerHTML = value;
        ZBJS_BGcolorPrice(value,"zbjsh_dr_"+id_notation,false,false);
       }
       if (document.getElementById("zbjsh_drR0_"+id_notation))
       {
        
        value = parseFloat(value).toFixed(0);
        document.getElementById("zbjsh_drR0_"+id_notation).innerHTML = value;
        ZBJS_BGcolorPrice(value,"zbjsh_drR0_"+id_notation,false,false);
       }
       if (document.getElementById("zbjsh_pb_"+id_notation)&&!noHighLow)
       {
        if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation] != "undefined" && typeof aStreamValue[id_notation]['c'] != "undefined")
         document.getElementById("zbjsh_pb_"+id_notation).innerHTML = low+aStreamValue[id_notation]['c']; 
        else
         document.getElementById("zbjsh_pb_"+id_notation).innerHTML = low;
        ZBJS_BGcolorPrice(low,"zbjsh_pb_"+id_notation,false,false);
       }
       if (document.getElementById("zbjsh_ph_"+id_notation)&&!noHighLow)
       {
        if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation] != "undefined" && typeof aStreamValue[id_notation]['c'] != "undefined")
         document.getElementById("zbjsh_ph_"+id_notation).innerHTML = high+aStreamValue[id_notation]['c']; 
        else
         document.getElementById("zbjsh_ph_"+id_notation).innerHTML = high;
        ZBJS_BGcolorPrice(high,"zbjsh_ph_"+id_notation,false,false);
       }
       if (document.getElementById("zbjsh_pf_"+id_notation))
       {   
        var sRet="";
        var myPerf="";
        if (typeof valuePerf != "undefined")
         myPerf = parseFloat(valuePerf);
        else if (aStreamValue['multi'][id_notation_tmp])
         myPerf = (value - aStreamValue['multi'][id_notation_tmp])  * 100 / aStreamValue['multi'][id_notation_tmp];       
        if (myPerf>0)
         sRet = "+";
        sRet += myPerf.toFixed(2)+"%";
        ZBJS_BGcolorPrice(value,"zbjsh_pf_"+id_notation,myPerf,false);
        document.getElementById("zbjsh_pf_"+id_notation).innerHTML = sRet;
       }
       // Ma liste position
       if (document.getElementById("zbjsh_pfml_"+id_notation))
       { 
        if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation] != "undefined" && typeof aStreamValue[id_notation]['s'] != "undefined" && typeof aStreamValue[id_notation]['e'] != "undefined" && aStreamValue[id_notation]['e']!= null)
        {
         var sRet="";
         var myPerf=0;
         if (aStreamValue[id_notation]['e'])
         {
          myPerf = (value - aStreamValue[id_notation]['e'])  * 100 / aStreamValue[id_notation]['e'] * aStreamValue[id_notation]['s'];
         }
         if (myPerf>0)
          sRet = "+";
         sRet += myPerf.toFixed(2)+"%";
         var inv = false;
         if (aStreamValue[id_notation]['s']==-1)
         {
          inv=true;
         }
         ZBJS_BGcolorPrice(value,"zbjsh_pfml_"+id_notation,myPerf,inv);
         document.getElementById("zbjsh_pfml_"+id_notation).innerHTML = '<div>'+sRet+'<div title="Modifier la position" class="cray"></div></div>';
        }
       } 
       // Portfolio Manager
       if (document.getElementById("zbjsh_pfl_"+id_notation))
       { 
        if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation] != "undefined" && typeof aStreamValue[id_notation]['s'] != "undefined" && typeof aStreamValue[id_notation]['e'] != "undefined" && aStreamValue[id_notation]['e']!= null)
        {
         var sRet="";
         var myPerf=0;
         if (aStreamValue[id_notation]['e'])
         {
          myPerf = (value - aStreamValue[id_notation]['e'])  * 100 / aStreamValue[id_notation]['e'] * aStreamValue[id_notation]['s'];
         }
         if (myPerf>0)
          sRet = "+";
         sRet += myPerf.toFixed(2)+"%";
         var inv = false;
         if (aStreamValue[id_notation]['s']==-1)
         {
          inv=true;
         }
         ZBJS_BGcolorPrice(value,"zbjsh_pfl_"+id_notation,myPerf,inv);
         document.getElementById("zbjsh_pfl_"+id_notation).innerHTML = sRet;
        }
       }
       // Portfolio Manager PIP
       if (document.getElementById("zbjsh_pfp_"+id_notation))
       {
        if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation] != "undefined" && typeof aStreamValue[id_notation]['s'] != "undefined" && typeof aStreamValue[id_notation]['e'] != "undefined" && typeof aStreamValue[id_notation]['f'] != "undefined")
        {
         var sRet="";
         var myPerf=0;
         if (aStreamValue[id_notation]['e'])
         {
          myPerf = (value - aStreamValue[id_notation]['e'])  * aStreamValue[id_notation]['f'] * aStreamValue[id_notation]['s'];
         }
         if (myPerf>0)
          sRet = "+";
         sRet += myPerf.toFixed(2);
         var inv = false;
         if (aStreamValue[id_notation]['s']==-1)
         {
          inv=true;
         }
         ZBJS_BGcolorPrice(value,"zbjsh_pfp_"+id_notation,myPerf,inv);
         document.getElementById("zbjsh_pfp_"+id_notation).innerHTML = sRet; 
        }
       }
   }
  }
  catch(err)
  {
   console.log(id_notation+" : "+err);
  }
  return "";
}

/****************/
/*  ZBLive END  */
/****************/

function ZBJS_Mutli(obj, subscription, value, row)
{
  try
  {
   var value=obj.getRawValue("PRICE");
   var high=obj.getRawValue("HIGH");
   var low=obj.getRawValue("LOW");
   var id_notation_tmp=obj.getRawValue("ID_NOTATION");
   var valuePerf=obj.getRawValue("PERFORMANCE_PCT");
   var noHighLow = false;
   
   // Alternative DR
   if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation_tmp] != "undefined" && typeof aStreamValue[id_notation_tmp]['t'] != "undefined"  && aStreamValue[id_notation_tmp]['t'] == 2)
   {
     var iBid = parseFloat(obj.getRawValue("BID"));
     var iAsk = parseFloat(obj.getRawValue("ASK"));
     var valueDateBid=obj.getValue("DATETIME_BID");
     var valueDateAsk=obj.getValue("DATETIME_ASK");
     noHighLow = true;
      
    if (iBid && iAsk && iBid!="_NA_" && iAsk!="_NA_" && Math.abs(valueDateBid-valueDateAsk)<900)
    {
     var myRes = (iBid+iAsk)/2;
     if (!isNaN(myRes) && typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation_tmp] != "undefined" && typeof aStreamValue[id_notation_tmp]['q'] != "undefined" && aStreamValue[id_notation_tmp]['q'] != 0) // q = close
     {
      var drV = parseFloat(aStreamValue[id_notation_tmp]['q']);
      valuePerf = (myRes-drV)*100/drV;
      value = myRes.toFixed(3);
     }
     else
      return "";
    }
    else
     return "";
   }
   // Alternative DR FONDS
   if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation_tmp] != "undefined" && typeof aStreamValue[id_notation_tmp]['t'] != "undefined"  && aStreamValue[id_notation_tmp]['t'] == 3)
   {
     myRes = value;
     if (!isNaN(myRes) && typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation_tmp] != "undefined" && typeof aStreamValue[id_notation_tmp]['q'] != "undefined" && aStreamValue[id_notation_tmp]['q'] != 0) // q = close
     {
      var drV = parseFloat(aStreamValue[id_notation_tmp]['q']);
      valuePerf = (myRes-drV)*100/drV;
      noHighLow = true;
     }
     else
      return "";
   }
   
   var id_notation_list = new Array();
   if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation_tmp] != "undefined" && typeof aStreamValue[id_notation_tmp]['m'] != "undefined")
   {
    for (var i=1;i<=aStreamValue[id_notation_tmp]['m'];i++)
    {
     id_notation_list[i-1] = id_notation_tmp+"_"+i;
    }
   }
   else
   {
    id_notation_list[0] = id_notation_tmp;
   }
   for (var i=0;i<id_notation_list.length;i++)
   {
       id_notation = id_notation_list[i];
       if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation] != "undefined" && typeof aStreamValue[id_notation]['x'] != "undefined")
         value= value * aStreamValue[id_notation]['x'];
       if (document.getElementById("zbjsh_dr_"+id_notation))
       {
        if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation] != "undefined" && typeof aStreamValue[id_notation]['c'] != "undefined")
         document.getElementById("zbjsh_dr_"+id_notation).innerHTML = value+aStreamValue[id_notation]['c']; 
        else
         document.getElementById("zbjsh_dr_"+id_notation).innerHTML = value;
        ZBJS_BGcolorPrice(value,"zbjsh_dr_"+id_notation,false,false);
       }
       if (document.getElementById("zbjsh_drR0_"+id_notation))
       {
        
        value = parseFloat(value).toFixed(0);
        document.getElementById("zbjsh_drR0_"+id_notation).innerHTML = value;
        ZBJS_BGcolorPrice(value,"zbjsh_drR0_"+id_notation,false,false);
       }
       if (document.getElementById("zbjsh_pb_"+id_notation)&&!noHighLow)
       {
        if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation] != "undefined" && typeof aStreamValue[id_notation]['c'] != "undefined")
         document.getElementById("zbjsh_pb_"+id_notation).innerHTML = low+aStreamValue[id_notation]['c']; 
        else
         document.getElementById("zbjsh_pb_"+id_notation).innerHTML = low;
        ZBJS_BGcolorPrice(low,"zbjsh_pb_"+id_notation,false,false);
       }
       if (document.getElementById("zbjsh_ph_"+id_notation)&&!noHighLow)
       {
        if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation] != "undefined" && typeof aStreamValue[id_notation]['c'] != "undefined")
         document.getElementById("zbjsh_ph_"+id_notation).innerHTML = high+aStreamValue[id_notation]['c']; 
        else
         document.getElementById("zbjsh_ph_"+id_notation).innerHTML = high;
        ZBJS_BGcolorPrice(high,"zbjsh_ph_"+id_notation,false,false);
       }
       if (document.getElementById("zbjsh_pf_"+id_notation))
       {   
        var sRet="";
        var myPerf = parseFloat(valuePerf);
        if (myPerf>0)
         sRet = "+";
        sRet += myPerf.toFixed(2)+"%";
        ZBJS_BGcolorPrice(value,"zbjsh_pf_"+id_notation,valuePerf,false);
        document.getElementById("zbjsh_pf_"+id_notation).innerHTML = sRet;
       }
       // Ma liste position
       if (document.getElementById("zbjsh_pfml_"+id_notation))
       { 
        if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation] != "undefined" && typeof aStreamValue[id_notation]['s'] != "undefined" && typeof aStreamValue[id_notation]['e'] != "undefined" && aStreamValue[id_notation]['e']!= null)
        {
         var sRet="";
         var myPerf=0;
         if (aStreamValue[id_notation]['e'])
         {
          myPerf = (value - aStreamValue[id_notation]['e'])  * 100 / aStreamValue[id_notation]['e'] * aStreamValue[id_notation]['s'];
         }
         if (myPerf>0)
          sRet = "+";
         sRet += myPerf.toFixed(2)+"%";
         var inv = false;
         if (aStreamValue[id_notation]['s']==-1)
         {
          inv=true;
         }
         ZBJS_BGcolorPrice(value,"zbjsh_pfml_"+id_notation,myPerf,inv);
         document.getElementById("zbjsh_pfml_"+id_notation).innerHTML = '<div>'+sRet+'<div title="Modifier la position" class="cray"></div></div>';
        }
       } 
       // Portfolio Manager
       if (document.getElementById("zbjsh_pfl_"+id_notation))
       { 
        if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation] != "undefined" && typeof aStreamValue[id_notation]['s'] != "undefined" && typeof aStreamValue[id_notation]['e'] != "undefined" && aStreamValue[id_notation]['e']!= null)
        {
         var sRet="";
         var myPerf=0;
         if (aStreamValue[id_notation]['e'])
         {
          myPerf = (value - aStreamValue[id_notation]['e'])  * 100 / aStreamValue[id_notation]['e'] * aStreamValue[id_notation]['s'];
         }
         if (myPerf>0)
          sRet = "+";
         sRet += myPerf.toFixed(2)+"%";
         var inv = false;
         if (aStreamValue[id_notation]['s']==-1)
         {
          inv=true;
         }
         ZBJS_BGcolorPrice(value,"zbjsh_pfl_"+id_notation,myPerf,inv);
         document.getElementById("zbjsh_pfl_"+id_notation).innerHTML = sRet;
        }
       }
       // Portfolio Manager PIP
       if (document.getElementById("zbjsh_pfp_"+id_notation))
       {
        if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation] != "undefined" && typeof aStreamValue[id_notation]['s'] != "undefined" && typeof aStreamValue[id_notation]['e'] != "undefined" && typeof aStreamValue[id_notation]['f'] != "undefined")
        {
         var sRet="";
         var myPerf=0;
         if (aStreamValue[id_notation]['e'])
         {
          myPerf = (value - aStreamValue[id_notation]['e'])  * aStreamValue[id_notation]['f'] * aStreamValue[id_notation]['s'];
         }
         if (myPerf>0)
          sRet = "+";
         sRet += myPerf.toFixed(2);
         var inv = false;
         if (aStreamValue[id_notation]['s']==-1)
         {
          inv=true;
         }
         ZBJS_BGcolorPrice(value,"zbjsh_pfp_"+id_notation,myPerf,inv);
         document.getElementById("zbjsh_pfp_"+id_notation).innerHTML = sRet; 
        }
       }
       // PERF HOME
       if (document.getElementById("zbjsh_pfh_"+id_notation))
       {
        if (typeof aStreamValue != "undefined" && typeof aStreamValue[id_notation] != "undefined")
        {
         var sRet="";
         var myPerf=0;
         if (aStreamValue[id_notation])
         {
          myPerf = (value - aStreamValue[id_notation])  * 100 / aStreamValue[id_notation];
         }
         if (myPerf>0)
          sRet = "+";
         sRet += myPerf.toFixed(2)+"%";
         ZBJS_BGcolorPrice(value,"zbjsh_pfh_"+id_notation,myPerf,false);
         document.getElementById("zbjsh_pfh_"+id_notation).innerHTML = sRet;
        }
       }
   }
  }
  catch(err)
  {
   console.log(id_notation+" : "+err);
  }
  return "";
}

function ZBJS_priceFVout(obj, subscription, value, row)
{
  try
  {
    if (obj.isValid())
    {
     value = obj.getRawValue("PRICE");
     var valueDate=obj.getValue("DATETIME_PRICE");
     var valuePerf=obj.getRawValue("PERFORMANCE_PCT");
     var myDate=new Date(Date.parse(valueDate));
     document.getElementById("zbjsfv_dr").innerHTML = value;
     ZBJS_colorPrice(value,2);
     if (!isNaN(value) && aStreamValue[2] != 0)
     {
      var drV = parseFloat(aStreamValue[2]);
      var sRet="";
      var myPerf = (value-drV)*100/drV;
      if (myPerf>0)
      {
       sRet = "+";
       window.setTimeout('clearElement("zbjsfv_pf", "fvPerf cPos")', 1);
      }    
      else if(myPerf<0)
       window.setTimeout('clearElement("zbjsfv_pf", "fvPerf cNeg")', 1);   
      else
       window.setTimeout('clearElement("zbjsfv_pf", "fvPerf cNeu")', 1); 
      sRet += myPerf.toFixed(2)+"%";
      document.getElementById("zbjsfv_pf").innerHTML = sRet;
     }
     //document.getElementById("zbjsfv_dt").innerHTML = dateToFVDate(myDate);
    }
  }
  catch(err)
  {
   //alert(err);
  }
  return "";
}



function ZBJS_priceFV2(obj, subscription, value, row)
{
  try
  {
    if (obj.isValid())
    {
     var iBid = parseFloat(obj.getRawValue("BID"));
     var iAsk = parseFloat(obj.getRawValue("ASK"));
     var valueDateBid=obj.getValue("DATETIME_BID");
     var valueDateAsk=obj.getValue("DATETIME_ASK");
     
     if (valueDateBid>valueDateAsk)
      valueDate=valueDateBid;
     else
      valueDate=valueDateAsk;
     
     var myDate=new Date(Date.parse(valueDate));
     var myRes = (iBid+iAsk)/2;     
     if (!isNaN(myRes))
     {
      document.getElementById("zbjsfv_dr").innerHTML = myRes.toFixed(3);
      ZBJS_colorPrice(myRes,"");
     }
     if (!isNaN(myRes) && aStreamValue[0] != 0)
     {
      var drV = parseFloat(aStreamValue[0]);
      var sRet="";
      var myPerf = (myRes-drV)*100/drV;
      if (myPerf>0)
      {
       sRet = "+";
       window.setTimeout('clearElement("zbjsfv_pf", "fvPerf cPos")', 1);
      }    
      else if(myPerf<0)
       window.setTimeout('clearElement("zbjsfv_pf", "fvPerf cNeg")', 1);   
     else
       window.setTimeout('clearElement("zbjsfv_pf", "fvPerf cNeu")', 1); 
      sRet += myPerf.toFixed(2)+"%";
      document.getElementById("zbjsfv_pf").innerHTML = sRet;
     }
     if (!isNaN(myDate))
      document.getElementById("zbjsfv_dt").innerHTML = dateToFVDate(myDate);
    }
  }
  catch(err)
  {
   //alert(err);
  }
  return "";
}

function ZBJS_priceFV(obj, subscription, value, row)
{
  try
  {
    if (obj.isValid())
    {
     value = obj.getRawValue("PRICE");
     var valueDate=obj.getValue("DATETIME_PRICE");
     var valuePerf=obj.getRawValue("PERFORMANCE_PCT");
     var myDate=new Date(Date.parse(valueDate));
     document.getElementById("zbjsfv_dr").innerHTML = value;
     ZBJS_colorPrice(value,"");
     var sRet="";
     var myPerf = parseFloat(valuePerf);
     if (myPerf>0)
     {
      sRet = "+";
      window.setTimeout('clearElement("zbjsfv_pf", "fvPerf cPos")', 1);
     }    
     else if(myPerf<0)
      window.setTimeout('clearElement("zbjsfv_pf", "fvPerf cNeg")', 1);   
     else
      window.setTimeout('clearElement("zbjsfv_pf", "fvPerf cNeu")', 1); 
     sRet += myPerf.toFixed(2)+"%";
     document.getElementById("zbjsfv_pf").innerHTML = sRet;
     document.getElementById("zbjsfv_dt").innerHTML = dateToFVDate(myDate);
     //document.getElementById("zbjsfv_dtl").innerHTML = dateToFVDate(myDate);
    }
  }
  catch(err)
  {
   //alert(err);
  }
  return "";
}


function ZBJS_TopFlop(mdgObject, subscription, isTop, addOn)
{
      try
      { 
        if (isTop==true)
         addI=0;
        else
         addI=10;  
        
        for (i=1; i<=mdgObject.getValue("AMOUNT"); i++)
        {   
                nameSecurity    = mdgObject.getValue("NAME_SECURITY", i);
                idNotation    = mdgObject.getValue("ID_NOTATION", i);
                performancePct  = mdgObject.getRawValue("CN_DIFF_REL_RANGE", i);
                quote = mdgObject.getRawValue("BASE_QUOTE_RANGE", i);

                var idName = "JS_NAME_" + (i + addI) + "_" + addOn; 
                var idPerformancePct = "JS_PERF_" + (i + addI) + "_" + addOn;
     
                if (nameSecurity.length > 16) nameSecurity = nameSecurity.substr(0, 16) + "..";
                document.getElementById(idName).innerHTML = '<a href="mods_a/stock/getfiche.php?ID_NOTATION='+idNotation+'">'+nameSecurity+"</a>";
                document.getElementById(idPerformancePct).innerHTML = parseFloat(performancePct).toFixed(2)+"%";
                ZBJS_BGcolorPrice(quote,idPerformancePct,performancePct);
        }
        var expiryTime = mdgObject.getExpiryTime();
        var timeDifference = mdgSession.getTimeDifference();
        var timestamp = new Date();
        var timeout = calculateTimeout(expiryTime, timeDifference);
        if (timeout<10000)
         timeout=10000;
        if (isTop==true)
         window.setTimeout("requestMdgObjectTopFlop"+addOn+"(true)", timeout);
        else
         window.setTimeout("requestMdgObjectTopFlop"+addOn+"(false)", timeout); 
        return true;
     }
     catch(err)
     {
       //alert(err);
       return false;
     }
}  

function topFlopHandlerTop0(mdgObject, subscription)
{
    this.consume = function(mdgObject, subscription)
    {
      return ZBJS_TopFlop(mdgObject, subscription, true, "0");         
    }; 
}

function topFlopHandlerFlop0(mdgObject, subscription)
{
    this.consume = function(mdgObject, subscription)
    {
      return ZBJS_TopFlop(mdgObject, subscription, false, "0");         
    }; 
}

function topFlopHandlerTop1(mdgObject, subscription)
{
    this.consume = function(mdgObject, subscription)
    {
      return ZBJS_TopFlop(mdgObject, subscription, true, "1");         
    }; 
}

function topFlopHandlerFlop1(mdgObject, subscription)
{
    this.consume = function(mdgObject, subscription)
    {
      return ZBJS_TopFlop(mdgObject, subscription, false, "1");         
    }; 
}

/*****************************************************************/
/* ZBLIVE                                                        */
/*****************************************************************/
function myInArray(myArray,p_val) {
    for(var i = 0, l = myArray.length; i < l; i++) {
        if(myArray[i] == p_val) {
            return true;
        }
    }
    return false;
}

var NbLn=0;
var aZBL_list = new Array(1001,1002,1003,1004);
var aZBL_Slist = new Array("FV0");
function ZBL_update(id,s)
{
 try
 {
  NbLn++;
  if (id==4)
  {
  var myElem4 = document.getElementById('ZBL4').innerHTML;
  var myElem5 = document.getElementById('ZBL5').innerHTML;
  var myElem6 = document.getElementById('ZBL6').innerHTML;
  document.getElementById('ZBL5').innerHTML=myElem4;
  document.getElementById('ZBL6').innerHTML=myElem5;
  document.getElementById('ZBL7').innerHTML=myElem6;   
 }
  if (id==8)
  {
  var myElem8 = document.getElementById('ZBL8').innerHTML;
  document.getElementById('ZBL9').innerHTML=myElem8;   
 }
  if (id==19)
  {
  var myElem19 = document.getElementById('ZBL19').innerHTML;
  document.getElementById('ZBL20').innerHTML=myElem19;   
 }
  if (myInArray(aZBL_list,id)||myInArray(aZBL_Slist,id.substring(0,3)))
  { 
  var myTab = document.getElementById('ZBL'+id);
  myTab.deleteRow(myTab.rows.length-1);
  var myRow = myTab.insertRow(0);
  var myCell = myRow.insertCell(0);
  myCell.innerHTML=s;
  myRow.id = 'selem'+NbLn; 
  highlight('selem'+NbLn);
 }
  else
  {
  var myTab = document.getElementById('ZBL'+id);
  myTab.innerHTML=s;
  highlight('ZBL'+id); 
 }
 }
 catch(err)
 {
   //alert(id+" : "+err);
 }
}

function highlight(id)
{
 //document.getElementById('music').src='/temp/ding.wav';
 window.setTimeout('clearElement("'+id+'", "sBgNeu")', 1);   
 window.setTimeout('clearElement("'+id+'", "")', 3000);  
}

var aStImg = new Array();
function StreamImage(newSrc,img,num,duration,preload)
{
 if (preload)
 {
  if (!aStImg[num])
   aStImg[num]=new Image();
  aStImg[num].src=newSrc+'&'+(new Date()).getTime();
  window.setTimeout('StreamImage("'+newSrc+'","'+img+'",'+num+',"'+duration+'", 0)', 500);
 }
 else if (aStImg[num].complete)
 {
   document.getElementById(img).src=aStImg[num].src;
   window.setTimeout('StreamImage("'+newSrc+'","'+img+'",'+num+',"'+duration+'", 0)', duration*1000);
 } 
 else
  window.setTimeout('StreamImage("'+newSrc+'","'+img+'",'+num+',"'+duration+'", 0)', 500); 
}
   
function ZBL_forum(id,s)
{
    var curElement = document.activeElement;
    if(s.trim() != '' && s != null && curElement.className!='content')
    {
        $('.zone_forum').first().replaceWith(s);
        $('#table_forum').find('tbody').find('tr').eq(0).addClass('animated fadeInUp');
    }
    else if(curElement.className!='content')
    {
        window.location.reload();
    }
    $("a.single_image").fancybox(); 
}

String.prototype.replaceAll = function(searchStr, replaceStr) {
    var str = this;

    // no match exists in string?
    if(str.indexOf(searchStr) === -1) {
        // return string
        return str;
    }

    // replace and remove first match, and do another recursirve search/replace
    return (str.replace(searchStr, replaceStr)).replaceAll(searchStr, replaceStr);
}

if (typeof startStreaming === "function") { 
    startStreaming();
}