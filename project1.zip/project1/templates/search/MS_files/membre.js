MAJ_add = function()
{
   var bSuiveurs = false;
   var dt = false;
    
   this.OnSuccess = function()
   {
     var texte = this.GetResponseText();
     if(texte.split("|"))
        var aElems = texte.split("|");
     if(aElems[1] == "0")
     {
           alert("Erreur "+aElems[2]+" "+aElems[3]);
           return;
     }
     var id_client = aElems[2];
     if(aElems[3] == "add")
     {
        if (SiteLangage==2)
         var sEtat = "delete";        
        else
         var sEtat = "supprimer";
        var sShow = aElems[4];
        var sAlertes = "off";
        var sTextOnOff = "<img src='/images/communaute/alerte_email_off.png' align='absmiddle'>";
        var numofsuiv = parseInt(window.document.getElementById("suiv_"+id_client).innerHTML);
        numofsuiv++;
        window.document.getElementById("suiv_"+id_client).innerHTML = numofsuiv;
     }
     else
     {
        if (this.dt)
        {
         if (SiteLangage==2)
          var sEtat = "add";        
         else
          var sEtat = "ajouter";
         var sShow = aElems[4];
         var sAlertes = "off";
         var sTextOnOff = "<img src='/images/communaute/alerte_email_off.png' align='absmiddle'>";
         var numofsuiv = parseInt(window.document.getElementById("suiv_"+id_client).innerHTML);
         numofsuiv--;
         window.document.getElementById("suiv_"+id_client).innerHTML = numofsuiv;
        }
        else
        {
         window.document.getElementById("line_"+id_client).style.display="none";
         return;
        }
     }
     
     var sImgAlertes = window.document.getElementById("add_"+id_client);  
     sImgAlertes.title = sEtat;
     sImgAlertes.innerHTML = sShow;
     if (this.bSuiveurs){ 
      sImgAlertes.onclick="";
      sImgAlertes.style.cursor="default";
     }
     
     var sImgAlertes = window.document.getElementById("alertes_"+id_client);  
     if (sImgAlertes)
     {
      sImgAlertes.title = sAlertes;
      sImgAlertes.innerHTML = sTextOnOff;
     }   
  }

  this.Action = function(id_client,pseudo)
  {
   var sAdded = window.document.getElementById("add_"+id_client).title;
   if(sAdded == "supprimer" || sAdded == "delete")
   {
    if (SiteLangage==2)
     var answer = confirm("Do you want to remove \""+pseudo+"\" of your favorite members ?");
    else
     var answer = confirm("Voulez-vous supprimer \""+pseudo+"\" de vos membres favoris ?");
    if (answer==true)
     this.Exec(id_client); 
   }
   else
    this.Exec(id_client);   
  }
  
  this.Exec = function(id_client)
  {
      var sAdded = window.document.getElementById("add_"+id_client).title;
      if(sAdded == "supprimer" || sAdded == "delete")
         var sAction = "del";
      else if (this.bSuiveurs)
         var sAction = "add_suiveur";
      else
         var sAction = "add";  
      var uri = "/mods_a/membre/AJAX_liste.php?iEntree="+id_client+"&sAction="+sAction;

      this.InitializeRequest('POST', uri);
      this.Commit(null);
  }
} 
    MAJ_add.prototype = new ajax(); 
    myMAJ_add = new MAJ_add();   
    myMAJ_add.dt = true;
       
    
// Liste de valeurs    
function alive()
{
  $.ajax({
       url : '/mods_a/alive.php',
       type : 'GET',
       dataType : 'html',
    });
  setTimeout(alive, 300000);
}   

function ajouterML(nom_valeur, codezb, cle)
{
//        myMaListe = new MaListe(1);
    var URL = '/mods_a/membre/AJAX_valeurs.php?sCleValeurs='+cle;      
    URL = URL+'&action=add&codezb='+codezb; 
    $.get(URL, function() {
        window.location.href = "?sCleValeurs="+cle;
    });
}   
    
function MaListeCorrectTH() {
    $("#maliste th").each(function(i) {
         $(this).find("a.title").css("font-weight", "bold");
         if(i<6) return true;

         var width = $(this).find("a.title").width()+17; 
         if($(this).find("a.tri").attr("tri") != "none")
            width += 13;
         $(this).css('min-width', width);
    });    
}

function MaListe(iLanguage)
{
    setTimeout(alive, 300000);
    this.iLanguage = iLanguage;
//    this.iNbCols = iNbCols;
    this.debug = true;
    this.fadeTime = 2000, this.beforeFadeTime = 1000;
    this.rowBG = new Array('#F6F6F6', '#FFF');
    this.nbColsMax = 20;
    this.alerteInitDataTable = false;
    this.droppedTR;
//    this.bodyRect = document.body.getBoundingClientRect();
    
    var tab = $('#t_maliste').attr("tab");
    var cle = $('#t_maliste').attr("cle"), thisC = this;
    this.URL = '/mods_a/membre/AJAX_valeurs.php?sCleValeurs='+cle+'&iTab='+tab
        +'&bModeSecours='+bModeSecours; 
    this.bListeAuto = (["consulte_1", "session_1", "consulteglobal_1"].indexOf($('#t_maliste').attr("cle")) != -1);
        
    this.ajouter = function(nom_valeur, codezb, cle)
    {
//        myMaListe = new MaListe(1);
        var URL = '/mods_a/membre/AJAX_valeurs.php?sCleValeurs='+cle;      
        URL += URL+'&action=add&codezb='+codezb; 
        $.get(URL, function() {
            window.location.href("?sCleValeurs="+cle);
        });
    }           
    
    this.action = function(action, param) {
         this.hideMsg();
         var sort = "";
         if(action == "sort")
            sort = encodeURI(param);
         else if(action == "cols")
            var modele = param;
         else
            var codezb = typeof param !== 'undefined' ? param : null;  
         var URL = this.URL+'&action='+action;
         if(codezb)
            URL += '&codezb='+codezb;
         if(name = encodeURI($('#t_maliste input').eq(0).val())) 
            URL += '&sName='+name;
         var init = bind = true;
         bind = false;
         if(action == "cols" || action == "sort")
         {
            if(action == "cols")
            {
                var cols;
                if(!(cols = arguments[2]))
                    cols = this.getCols();
                URL += '&sCols='+cols; 
                URL += '&iModele='+modele; 
//                init = bind = false;
            }
            var $el = $("#table_container").parent(); // que tableau
         }
         else         
            var $el = $("#t_maliste");  // inclure menu
         
         var a = { "sort": sort };
         
         if(action == "add")
         {
            var aCodezbOrdre = this.getCodezbOrdre();
            aCodezbOrdre = this.addCodezbToOrdre(aCodezbOrdre, codezb);
            var a = { "sort": sort, "aCodezbOrdre" : aCodezbOrdre };    
         }

         $el.load(URL, a, function(){
            if(init)
               thisC.initDataTable(action, codezb);
            if(bind) 
               thisC.bindEvents(1); 
            if(action == "add")
            {    
            }
         });
         
         return false;    
    }
    
    this.initModeSecours = function() {
//         $('.maliste_body th:nth-child(6)').css("border-left", "solid 1px #C0C0C0");
         $('.maliste_body tr td:nth-child(6)').css("border-left", "solid 1px #C0C0C0");
         MaListeCorrectTH();   
         this.addTrIds();   
    }

    
    this.addTrIds = function() {
        $("#maliste tbody tr").each(function() {
             i++;
             $(this).attr('id', i);
        });         
    }          
    
    this.initDataTable = function(action, codezb) {
         var this_ = this;
        
         if(this.alerteInitDataTable)
            alert("initDataTable "+action);
         if($.fn.dataTable.isDataTable( '#maliste' ))
         {
            var table = $('#maliste').DataTable();
            table.destroy();
            $('#maliste .DataTables_sort_wrapper').contents().unwrap();
            $('#maliste .DataTables_sort_icon').remove();
         }               
         
         $("#maliste tr").each(function(i) {
             $(this).attr('id', i);
             if(i == 0)
                sEl = "th";
             else
                sEl = "td";
             if(parseInt($(sEl+":first-child", this).html()) === i)
                return true;
             $(this).prepend('<'+sEl+' style="display:none">'+i+'</td>');
         }); 
//                  
//         this.iNbCols = $("#maliste thead th").length;
            
         var sSelector = ".move_r";
         if(this.bListeAuto)
            sSelector = "";

         iNbCols = $("#maliste_thead th").length;
         aCols = new Array();
         for(i=0;i<iNbCols;i++)
             aCols.push(i);
                      
         var oDataTable = $("#maliste").DataTable( { 
            rowReorder: {
                selector: sSelector
            },  
            "dom" : "Rlfrtip",
            "paging":   false,
            "info":     false,
            "filter":   false, 
//            "scrollX": true,            
            "columnDefs": [
                { "orderable": false, "targets": aCols }
            ],     
            "colReorder": {
                fixedColumnsLeft: 6,
                fixedColumnsRight: iNbFixDr,
                "reorderCallback": jQuery.proxy(this.updateCols, this)      
            },    
            
            "initComplete": function () {
                this_.updateRows(codezb, false);     
                $('#maliste .DataTables_sort_wrapper').contents().unwrap();
                MaListeCorrectTH();
                
            },
                            
         } );
         
         oDataTable.on( 'row-reorder', function ( e, diff, edit ) {
             this_.updateRows(null, true);  
         } );     
         
//         $('#container').css( 'display', 'block' );
//         oDataTable.columns.adjust().draw();                  
         
           
          
           
    }
    
    this.updateCols = function() {
        var aColsOrdre = this.getColsOrdre();
        var a = { "aColsOrdre" : aColsOrdre };
        var URL = this.URL+'&action=updateCols&iModele='+iModele;
        $.get(URL, a ,function( data )  {
        } )       
    }
    
    this.getColsOrdre = function() {
        var aOrdre = new Array();
        $("#maliste thead th").each(function() {
            var idcol = $(this).attr("icol");
            aOrdre.push(idcol);
        });
        return aOrdre;
    }    
    
    /* Changer ordre Lignes*/
    this.updateRows = function(/*newPosition*/codezb, saveOrder) 
    {         
        var this_ = this;
        var i = 0, myClass = this;
        this.addTrIds();
    
        
        if(!saveOrder) 
        { 
            if(codezb)
               this_.blinkCodezb(codezb);            
            return;
        }
        
        var aCodezbOrdre = this.getCodezbOrdre();
        var a = { "aCodezbOrdre" : aCodezbOrdre };
        var URL = this.URL+'&action=updateRows';
        
        $.getJSON(URL, a,function( data )  {
            i = 0;
            $("#maliste tbody tr").each(function() {
                i++;
                $(this).css('background-color', myClass.rowBG[i%2]);   
            }); 
            if(codezb)
               this_.blinkCodezb(codezb);    
        } );
        
    }
    
    /* Clignoter fond jaune */
    this.blinkCodezb = function(codezb) {
        myClass = this;
        $("#maliste tr div.iconeSuppr[codezb='"+codezb+"']").closest("tr").each(function() {
                $(this).delay(myClass.beforeFadeTime).css('background-color', '#FFEE00');
                var col = myClass.rowBG[(parseFloat($(this).attr("id")))%2];
                $(this).animate({backgroundColor: col}, myClass.fadeTime);
        });         
    }
    
    this.getCodezbOrdre = function() {
        var aOrdre = new Array();
        var id, codezb;
        $("#maliste tbody tr").each(function() {
            id = $(this).attr("id");
            codezb = $("div.iconeSuppr", this).attr("codezb");
            aOrdre[id] = codezb;
        });
        return aOrdre;
    }
    
    this.addCodezbToOrdre = function(aOrdre, codezb) {
        aOrdreNew = new Array();
        aOrdreNew[1] = codezb;
        
        for(var i in aOrdre)
        {
            if(i == 0)
                continue;
            j = parseInt(i)+1;
            aOrdreNew[j] = aOrdre[i];
        }
        
        return aOrdreNew;
    }
    
    this.hideMsg = function() {
         $('div.listePresente').css('visibility', 'hidden');
    }
    
    this.CalendarSetup = function(today) {
         //var today = $.datepicker.formatDate('yymmdd', new Date());
         var min_date = '19900101';
         Calendar.setup({
             inputField : 'date_achat',
             trigger    : 'date_achat',
             selectionType: Calendar.SEL_SINGLE,
             onSelect   : function() { this.hide(); },    
             dateFormat : sDateFormat,
             min        : min_date,
             max        : today,
             selection  : today,       
         });        
    }
    
    this.getCols = function() {
        var cols = [];
        $('#vue_col input:checkbox:checked').each(function(index,element){
            cols.push($(element).prop("value")); 
        });
        sCols = cols.toString();
        return sCols;
    }

    this.bindEvents = function(etape) 
    {
         var etape = typeof etape !== 'undefined' ? etape : 1; 
         var this_ = this;
         //var debug_all = true;

         $("*").off('click.maliste');
         $("*").off('mousedown.maliste');
//         if(["consulte", "session", "consulte_global"].indexOf($('#t_maliste').attr("cle")) != -1) 
         if(this.bListeAuto)
         {     
             $('#div_maliste').on('mousedown.maliste', '#maliste div.iconeSuppr, #modif .mod, #maliste .move_r,#maliste ._ma_position,#maliste ._alerte,#recherche_menu_liste .code', function()
             {
                     /* Copier Liste */
                    $("body").prepend("<div id='copy'></div>"); 
                    $("#copy").load(this_.URL+"&action=copier", function()
                    {
                         $('#can, .copycl').bind('click.maliste', function()
                         {
                             $("#copy").remove();
                         });     
                         $('#copy form').submit('click.maliste', function()
                         {
                             var selected = $("#copy select").val();
                             var nom = $("#copy input").val(); 
                             var param = { duplicate: {selected: $("#copy select").val(), nom: $("#copy input").val()} };
                             $("#copy").load(this_.URL+"&action=copier2", param, function()
                             {
                                $('.copycl').bind('click.maliste', function(){ window.location.href = '?'; });
                             });
                             return false;
                         });
                    });
                    return false;
             });
         }
         if(etape == 1)
         {
             /* Supprimer valeur */
             $('#div_maliste').on('click.maliste', '#maliste div.iconeSuppr', function(){
                var codezb = $(this).attr("codezb");
                this_.action("del", codezb);
             });
          
             /* Bouton ajouter valeur */
             $('#div_maliste').on('click.maliste', '#recherche_menu_liste button.ajouter', function(){
                 var codezb = $('#autocomplete_liste').attr("codezb");
                 this.action("add", codezb);
                 return false;
             }); 
               
             /* Modifier Liste */
             $('#div_maliste').on('click.maliste', 'a.mod', function(){
                 var URL = this_.URL+'&action=modify';
                 $('#t_maliste form').eq(0).load(URL, function() { /*this_.bindEvents(2);*/ });
                 return false;
             });             
             
             /* Alerte Actu */
             $('#div_maliste').on('click.maliste', '.tabBody_Liste2 tr td._alerte img', function(){
                 var src_ = $(this).attr("src");  
                 var tr = $(this).closest("tr");
                 var codezb = tr.find("div.iconeSuppr").attr("codezb");                 
                 var URL = encodeURI(this_.URL+'&action=alerte&codezb='+codezb+'&src='+src_);
                 var this__ = this;
                 $.getJSON(URL, function(data) {
                        $(this__).attr("src", data.src).attr("title", data.title);  
                 } );
                 return false;
             });   
             
             /* Ouvrir Ma position */
             //$('#t_maliste .tabBody_Liste2 tr td._ma_position a, #t_maliste .tabBody_Liste2 tr td._ma_position .cray, #ouvrir_position .annuler span').on('click.maliste', function(){
             $('#div_maliste').on('click.maliste', ".tabBody_Liste2 tr td._ma_position .ajouter_pos, .tabBody_Liste2 tr td._ma_position .cray, #ouvrir_position .annuler span", function(){
                 var tr = $(this).closest("tr");
                 var codezb = tr.find("div.iconeSuppr").attr("codezb");
                 var id_notation = tr.find("div.iconeSuppr").attr("id_notation");
                 var prix = tr.find("div.iconeSuppr").attr("prix_revient");
                 if(!prix)
                    prix = tr.find("div.iconeSuppr").attr("prix");
                 var date = tr.find("div.iconeSuppr").attr("date");
                 var qt = tr.find("div.iconeSuppr").attr("qt");
                 var cur = tr.find("div.iconeSuppr").attr("cur");
                 var nbr_cols = tr.find("td").length;
                 var tr_ici = $('#ouvrir_position table[codezb='+codezb+']').length != 0;
                 var tr_old = $('#ouvrir_position');//.parent();

                 if(tr_old.length)
                 {
                    tr_old.remove();
                 }
                 if(tr_ici)
                 {
                    return false;
                 }
                 
                 var URL = encodeURI(this_.URL+'&action=ouvrir_position&codezb='+codezb+'&id_notation='+id_notation+'&prix='+prix+'&date='+date+'&qt='+qt+'&cur='+cur);
                 //var URL = encodeURI('/mods_a/membre/AJAX_valeurs.php?action=ouvrir_position&sCleValeurs='+cle+'&iTab='+tab+'&codezb='+codezb+'&prix='+prix+'&date='+date+'&qt='+qt+'&cur='+cur);
                 $.getJSON(URL, function(data) {
                        var today = data.today;    
//                        tr.after("<tr id='ouvrir_position' style='background-color:"+tr.css('background-color')+"'><td colspan='"+(nbr_cols)+"'>"+data.src+"</td></tr>");
                        tr.after("<tr id='ouvrir_position' style='background-color:#FFEE00'><td colspan='"+(nbr_cols)+"'>"+data.src+"</td></tr>");
                        this_.CalendarSetup(today);
                 } );
                 return false;
             });   
             
             /* Rajouter valeur */
             $('#div_maliste .code input').eq(1).on('click.maliste', function(){
                 var mots = $('#t_maliste .code input').eq(0).val();
                 if(mots == 'Code ou Libell�' || mots == 'Symbol or Keyword(s)' || $.trim(mots) == '')
                 {
                    if(this_.iLanguage == 1) 
                        alert("Veillez renseigner le code ou libell� de la valeur.");
                    else
                        alert("Please enter the symbol or name of the instrument.");
                    return false;
                 }
                 var tab = $('#t_maliste').attr("tab");
                 var cle = $('#t_maliste').attr("cle");  
                 
                 window.location.href = '?sCleValeurs='+cle+'&iTab='+tab+'&mots='+mots;
                 return false;
             });  
             
             
             $(document).on('change', '#select_modele', function(event){
             
                 var sCols = $(this).find(':selected').val();
                 var iModele = $(this).find(':selected').attr('modele') 
                 this_.action("cols", iModele, sCols);
                 return true;
             });   
             

             /* Modeles colonnes */
             $('#div_maliste').on('click.maliste', '#vue_mod li', function(event){
                 var target = event.target.nodeName;
                 var input = $("input", this);
                 if(target != "INPUT")
                    $(input).prop("checked", !$(input).prop("checked"));
                 if(!$(input).prop("checked"))
                     return true;
                 var sCols = $(input).val();
                 $("#vue_mod li input[value!='"+sCols+"']").each(function() {
                     $(this).prop("checked", false);
                 });  
                     
                 var iModele = $(this).attr("modele");                 
                 var bPersonnalise = (iModele == iModelePersonnalise);
                 if(bPersonnalise)
                 {
                     var aCols = sCols.split(",");  
                     $("#vue_col li input").each(function() {
                         $(this).prop("checked", aCols.indexOf($(this).val()) >= 0);
                     });  
                 }
                 
                 if(bPersonnalise)
                 {
                    $("#vue_col").show();
                    $("#vue_mod").css("border-bottom", "0");
                    $("#vue_col li:first-child").css("border-top", 0);
                 }
                 else
                 {
                    $("#vue_col").hide();
                    $("#vue_mod").css("border-bottom", "solid 1px #c0C0C0");
                 }
                 
                 this_.action("cols", iModele, sCols);
                 return true;
             });                
             
             /* Rajouter colonne */
             $('#div_maliste').on('click.maliste', '#vue_col li[class!="vue_rub"]', function(event){
                 var target = event.target.nodeName;
                 var input = $("input", this);
                 if(target != "INPUT")
                    $(input).prop("checked", !$(input).prop("checked"));
                 if($(input).prop("checked") && (this_.iNbCols-4) >= this_.nbColsMax)
                 {
                     $(input).prop("checked", false);
                     alert("Vous avez atteint la limite de "+(this_.nbColsMax - 1)+" colonnes.");
                     return true;
                 }
                 
                 var sCols = this_.getCols();
                 $('#vue_mod li input').each(function() 
                 {
                     if($(this).prop("checked"))
                     {
                         $(this).attr("value", sCols);
                         iModele = $(this).parent().attr("modele");
                     }
                 }); 
                 
                 this_.action("cols", iModele, sCols);
                 return true;
             });    
                           
             /* Ouvrir et fermer menu colonnes */           
             $('#div_maliste').on('click.maliste', '.vue_div button, #vue_ferm', function(event){    //,    
                 var o_new = '1';
                 var v_new = 'block';
                 var ul = $('.vue_div > div');
                 if(ul.css('opacity') == '1')
                 {
                    o_new = '0';
                    v_new = 'none'; 
                 }           
                 ul.css('opacity', o_new);
                 ul.css('display', v_new);
             }); 
             
             /* trier */
             $('#div_maliste').on('click.maliste', 'th a', function(event){
                 var href = $(this).attr("href");
                 this_.action("sort", href);
                 return false;
             });              
                   
         /*}
         // modifier nom, suppr liste, retour
         else if(etape == 2)
         {  */
               $('#div_maliste').on('click.maliste', '#lmod', function(){  
                 return this_.action("name");
               });   
               $('#div_maliste').on('click.maliste', '#lsup', function(){  
                   if(this_.iLanguage == 1) 
                     var sQuestion = "Voulez-vous vraiment vider la liste '"+$('#t_maliste input').eq(0).val()+"' ?";
                   else if(this_.iLanguage == 3) 
                     var sQuestion = "Wollen Sie die Liste '"+$('#t_maliste input').eq(0).val()+"' wirklich leeren?";                     
                   else
                     var sQuestion = "Do you really want to clear the list '"+$('#t_maliste input').eq(0).val()+"'?";
                   if(!confirm(sQuestion))
                        return false;
                   return this_.action("supp");
               }); 
               $('#div_maliste').on('click.maliste', '#lret', function(){  
                   return this_.action("ret");
               });              

         
         }
         
         // supprimer alerte portefeuille    
             $('#div_maliste').on('click.maliste', '#astuce_p .iconeSuppr', function(event){    //,    
                 var cle = $('#t_maliste').attr("cle"); 
                 $('#astuce_p').css('display', 'none');
                 var URL = encodeURI(this_.URL+'&action=msg_portif&msg_portif=0');
//                 var URL = encodeURI('/mods_a/membre/AJAX_valeurs.php?action=msg_portif&sCleValeurs='+cle+'&msg_portif=0');
                 $.get(URL);
             }); 
             
             $('#div_maliste').on('click.maliste','.LChartI', function(event) {
                var codezb = $("div.iconeSuppr", $(this).closest("tr")).attr("codezb");
                document.location.href = "/-"+codezb+"/graphiques-cours/";
             });
             
             $('#div_maliste').on('mouseover.maliste','.LChartI', function(event) {
                var this_ = this;
                var width = 300;
                var codezb = $("div.iconeSuppr", $(this_).closest("tr")).attr("codezb");
                var bodyRect = document.body.getBoundingClientRect(), 
                    elemRect = this.getBoundingClientRect(),/*+ window.scrollY,*/
                    listRect = $("#div_maliste")[0].getBoundingClientRect(),
                    y_offset   = elemRect.top  -listRect.top,/* - bodyRect.top,*/
                    x_offset   = elemRect.left - listRect.left - bodyRect.left + 25;
                var img = "<img src='https://www.zonebourse.com/zbcache/charts/ObjectChart.aspx?Name="+codezb+"&Type=Custom&Intraday=1&Width="+width+"&Height="+width+"&Cycle=DAY1&Duration=4&Render=Candle&ShowCopyright=0&ShowVolume=0&ShowName=1' />";
                var LChart = $('#LChart');
                LChart.detach()
                    .insertAfter(this)
                    .css("left", elemRect.left - listRect.left + 20)
                    .html(img).css("display", "block");
                                
                $(this_).on('mouseout', function() {
                    $('#LChart').css("display", "none");
                    $(this_).off( "mouseout");
                });                    
             });
         
          
         
         
         // acheter
         if(true || etape == 3)
         { 
             
             $('#div_maliste').on('click.maliste', '#ouvrir_position .valider button, #ouvrir_position .supprimer span',  function(event){
                 var target_id = event.target.id;
                 if(target_id == "psup")
                 {
                     if(this_.iLanguage == 1) 
                       var sQuestion = "Voulez-vous vraiment supprimer cette position ?";
                     else if(this_.iLanguage == 3) 
                       var sQuestion = "Wollen Sie diesen Trade wirklich l�schen?";                       
                     else
                       var sQuestion = "Do you really want to delete this trade?";
                     if(!confirm(sQuestion))
                        return false;                 
                 }
                 var table = $('#ouvrir_position table');
                 var cle = table.attr("cle");  
                 var codezb = table.attr("codezb");  
                 var id_notation = table.attr("id_notation");  
                 
                 var sens = table.find("input[name='sens']:checked").val();  
                 var date = table.find("input[name='date']").val();  
                 var prix = table.find("input[name='prix']").val(); 
                 var qt = table.find("input[name='qt']").val(); 
                 if($(this).parent().attr("class") == "supprimer")
                    qt = 0;
                 if(sens == 'V')
                    qt = -qt;
                 if(target_id == "psup")
                    prix = null;
                 if(aStreamValue[id_notation+"_1"])
                    aStreamValue[id_notation+"_1"]['e'] = prix; 
                    
                 var URL = encodeURI(this_.URL+'&action=acheter&codezb='+codezb+'&date='+date+'&prix='+prix+'&qt='+qt);
                 $('#t_maliste').parent().load(URL);   
                 return false;
             });           
         }         
    } 
    
}

function showHideMenuComptes(iIdCompte)
{
    var sNewMenuStyle = $("#menuComptes_"+iIdCompte).css("display")=="none" ? "table" : "none";
    $("#menuComptes_"+iIdCompte).css("display",sNewMenuStyle);
}