var Tempo = 1000; // en ms
var OpenDelay = 100; // en ms
var MouseStatus = "out";
var CurrentSsMenu = 0;
if (typeof CurrentTopMenu == 'undefined')
    var CurrentTopMenu = 0;
var TimeoutSet;

var selectedMenu = 0;

function hideSsElementDecal(ssElementH)
{
 if (CurrentSsMenu != ssElementH || MouseStatus == "on") return;
 hideSsElementReal(ssElementH);
}

function activSmenuDelay(selectMenu)
{
 window.clearTimeout(TimeoutSet);
 MouseStatus = "on";
 if (CurrentSsMenu == selectMenu) return;

  if (selectedMenu!=selectMenu)
  {
   if (selectMenu!=0)
   {
    document.getElementById("mT"+selectMenu).className+="Sel";
    if (document.getElementById("mS"+selectMenu))
     document.getElementById("mS"+selectMenu).style.display="block"; 
   }
   if (selectedMenu!=0)
   {
    var  reg=new  RegExp("(Sel)", "g");
    document.getElementById("mT"+selectedMenu).className=document.getElementById("mT"+selectedMenu).className.replace(reg,"");
    if (document.getElementById("mS"+selectedMenu)) 
     document.getElementById("mS"+selectedMenu).style.display="none";
   }
   selectedMenu=selectMenu;
  }
  CurrentSsMenu = selectMenu;
}

function activTopSmenu(selectMenu)
{
  if (CurrentTopMenu != selectMenu)
  {
   if (CurrentTopMenu!=0)
   {
    var  reg=new  RegExp("(Sel)", "g");
    document.getElementById("mTopT"+CurrentTopMenu).className=document.getElementById("mTopT"+CurrentTopMenu).className.replace(reg,"");
    if (document.getElementById("mTopS"+CurrentTopMenu)) 
     document.getElementById("mTopS"+CurrentTopMenu).style.display="none";
   }
   
   document.getElementById("mTopT"+selectMenu).className+="Sel";
   if(selectMenu==1)
        $("#logo_loggin").attr("src","/images/membre/not_logged_grey.png");
        
   if (document.getElementById("mTopS"+selectMenu))
   {
    document.getElementById("mTopS"+selectMenu).style.display="block";
    if($("input[name='login']").length>0)
     $("input[name='login']")[0].focus();
   }
   CurrentTopMenu = selectMenu; 
  }
  else
  {
    var  reg=new  RegExp("(Sel)", "g");
    document.getElementById("mTopT"+CurrentTopMenu).className=document.getElementById("mTopT"+CurrentTopMenu).className.replace(reg,"");
    if (document.getElementById("mTopS"+CurrentTopMenu)) 
     document.getElementById("mTopS"+CurrentTopMenu).style.display="none";
    CurrentTopMenu=0;
    
    if(selectMenu==1)
        $("#logo_loggin").attr("src","/images/membre/not_logged.png");
  }
}

function activSmenu(selectMenu)
{
 //
 window.clearTimeout(TimeoutSet);
 MouseStatus = "on";
 if (CurrentSsMenu == selectMenu) return;
 //
 if (selectedMenu!=0)
 {
    var  reg=new  RegExp("(Sel)", "g");
    document.getElementById("mT"+selectedMenu).className=document.getElementById("mT"+selectedMenu).className.replace(reg,"");
    if (document.getElementById("mS"+selectedMenu)) 
     document.getElementById("mS"+selectedMenu).style.display="none";
    selectedMenu=0;
    CurrentSsMenu = selectedMenu;
 } 
 //
 TimeoutOpenDelay = window.setTimeout("activSmenuDelay("+selectMenu+")", OpenDelay); 
}

function desactSmenu(selectMenu,sClass)
{
 //
 window.clearTimeout(TimeoutOpenDelay);
 //
 MouseStatus = "out";
 if (CurrentSsMenu == 0 || CurrentSsMenu != selectMenu) return;
 TimeoutSet = window.setTimeout("desactRealSmenu("+selectMenu+",'"+sClass+"')", Tempo); 
}

function desactRealSmenu(selectMenu,sClass)
{
 if (MouseStatus == "on") return; 
 if (CurrentSsMenu == 0) return;
 activSmenuDelay(0);
 CurrentSsMenu = 0;
}

function geturlMenu(sUrl)
{
 window.location.href = sUrl;
}

function addToFavorites() {
 if ( navigator.appName != 'Microsoft Internet Explorer' )
 { window.sidebar.addPanel("Zonebourse.com","http://www.zonebourse.com",""); }
 else { window.external.AddFavorite("http://www.zonebourse.com","Zonebourse.com"); }
} 