if(!configured)
{
    throw new Error('/js/utf-8/configGraph.js is not imported'); 
}

const BALANCE_VALO_HIST = 1, BALANCE_VALO_ANNEE = 2, BALANCE_VALO_MOIS = 3, 
      BALANCE_VALO_ANNUELLES = 4, BALANCE_VALO_MENSUELLES = 5, 
      BALANCE_VALO_QUOTIDIENNES = 6, BALANCE_VALO_HEBDOMADAIRES = 7, BALANCE_VALO_20JOURS = 8,
                                   
      TRADE_NOMBRE_REUSSITE = 9, TRADE_REPART_PERF = 10, TRADE_CAPITAUX = 11, TRADE_TYPE_ACTIF = 12,
      TRADE_EXPOSITION = 13,

      ORDRE_VALO_NB_ORDRES = 14, ORDRE_VALO_CAPITAUX = 15, ORDRE_CAPITAUX_CUMULES = 16, ORDRE_TYPE = 17,
      BALANCE_VALO_POURC = 18, BALANCE_PLUS_MOINS_VALUES_HEBDO = 19,

      BALANCE_VALO_HIST_JOUR = 20, BALANCE_PLUS_MOINS_VALUES_JOUR = 21, BALANCE_VALO_POURC_CONCOURS = 22,
      BALANCE_PLUS_MOINS_VALUES_JOUR_CONCOURS = 23, BALANCE_VALO_HIST_JOUR_CONCOURS = 24,

      OUTIL_CA = 25, OUTIL_VALO = 26, BALANCE_VALO_POURC_SYNTHESE = 27, 

      /*BALANCE_VALO_POURC_CONCOURS_AVEC_AR = 28,*/ BALANCE_VALO_POURC_AVEC_AR = 28, BALANCE_VALO_POURC_RAMENER_AR = 29,
      BALANCE_PLUS_MOINS_VALUES_MENSUELLE = 30, BALANCE_VALO_POURC_SYNTHESE_CONCOURS = 31;
      
var sLastBM = "",
    dataCompte = [],
    aQuotesBM = {},
    lastChart = "perf";
      

function linearChart(sInDiv,idCompte,sDebut,sFin,iType,sCurrency)
{    
    if(iType==BALANCE_VALO_POURC_CONCOURS||iType==BALANCE_VALO_POURC_RAMENER_AR||iType==BALANCE_VALO_POURC_SYNTHESE_CONCOURS)
    {
        var yTitle = tradsTM['Variation'],
            suffixTooltip = "%";   
    }
    else
    {
        var yTitle = tradsTM['Valorisation'],
            suffixTooltip = sCurrency;    
    }
    options = {
        chart : {
            renderTo: sInDiv,
            marginTop : 10,
            spacingTop : 10,
            spacingBottom: 20,
            spacingLeft: 10,     
            spacingRight: 0,     
            style :
            {
                fontFamily : 'Arial, Helvetica, Sans-Serif'
            }/*,
            events: {
                redraw: function()
                {
                    if(typeof showQuarters === "function")
                        showQuarters(sInDiv);        
                }
            } */          
        },
        
        exporting : {
            enabled : false,
        },

        credits : {
            enabled : false 
        },               

        legend : {
            enabled : true
        },

        tooltip: {
            backgroundColor: {
                linearGradient: {
                    x1: 0,
                    y1: 0,
                    x2: 0,
                    y2: 1
                },
                stops: [
                    [0, 'white'],
                    [1, '#EEE']
                ]
            },
            borderColor: 'gray',
            borderWidth: 1,
            borderRadius: 5,
            shared : true,
            headerFormat: '<span style="font-size:12px">'+tradsTM['Date']+' : <b>{point.key}</b></span><br><table style="min-width:150px;">',
            footerFormat: '</table>',
            useHTML: true                          
        },
        
        rangeSelector : {
            enabled: false
        },
        
        /*navigator : { 
            enabled: false
        },
        
        scrollbar : { 
            enabled: false
        }, */

        xAxis : [
        {
            labels : {   
                align : 'center',
                style : {
                    color: "black"
                }                         
            },
            lineWidth : 1,
            lineColor : 'black',
            gridLineColor : "#ededed",
            gridLineWidth: 1,
            tickLength : 5,
            tickColor : 'black',       
            title : null,
            showFirstLabel: true,    
            ordinal: true,
            //range: 1000*3600*24*365,
            /*breaks: [{ // Weekends
                from: Date.UTC(2011, 9, 7, 23, 59, 59),
                to: Date.UTC(2011, 9, 9, 23, 59, 59),
                repeat: 7 * 24 * 36e5
            }]*//*,
            events: {
                afterSetExtremes: function(){
                    if(this.chart.get("spread"))
                    {
                        var startCompte = 0,
                            startBM = 0,
                            normaCompte, normaBM,
                            aDataSpread = [],
                            tableOffset = 0;
                        
                        for(var i = 0; i < dataCompte.length; i++)
                        {
                            
                            var date = new Date(dataCompte[i][0]);
                            
                            if((!dataBM[i-tableOffset])||(dataCompte[i][0]>this.max)){ //Si fin benchmark
                                break;
                            }
                            
                            if(dataCompte[i][0]<this.min)
                                continue;
                                                    
                            while(dataCompte[i][0]>dataBM[i-tableOffset][0])  //Si d�calage date
                            {   
                                tableOffset--;
                            }
                                                    
                            while(dataCompte[i][0]<dataBM[i-tableOffset][0])  //Si d�calage date
                            {   
                                tableOffset++;
                            }
                            
                            startCompte = (startCompte==0) ? dataCompte[i][1] : startCompte;
                            startBM = (startBM==0) ? dataBM[i-tableOffset][1] : startBM;
                                
                            normaCompte =  dataCompte[i][1] / startCompte;       
                            normaBM =  dataBM[i-tableOffset][1] / startBM;
                            
                            aDataSpread.push([dataCompte[i][0],(normaCompte-normaBM)*100]);       
                        } 
                        this.chart.get("spread").update({
                            data: aDataSpread
                        },true);
                    }
                }
            }*/ 
        }], 

        yAxis : [
        {
            id: 'rightAxis',
            lineWidth : 1,   
            gridLineColor : "#ededed", 
            lineColor : 'black',
            tickWidth : 1,
            tickLength : 5,
            tickColor : 'black',
            labels : {    
                format : '{value}'+suffixTooltip,
                verticalAlign : 'middle',
                align: 'left',
                style : {
                    color: "black"
                }          
            },
            showFirstLabel: true,
            showLastLabel: true,
            offset : 20,
            height: "100%"                       
        },
        {
            id: 'rightAxisSpread',
            lineWidth : 1,   
            gridLineColor : "#ededed",
            lineColor : 'black',
            tickWidth : 1,
            tickLength : 5,
            tickColor : 'black',
            labels : {
                format : '{value}%',
                verticalAlign : 'middle',
                align: 'left',
                style : {
                    color: "black"
                }          
            },
            offset : 20,
            visible: false,
            height: "0%",
            top: "75%",
            startOnTick: false,
            endOnTick: false,
            showLastLabel: true                      
        }],

        plotOptions : {
            series: {
                dataGrouping :{
                    forced: 1,
                    units: [
                        ['day', [1]]
                    ],
                    dateTimeLabelFormats: {
                        day: [dateFormatDay]
                    }
                },
                states:{
                    hover:{
                        lineWidthPlus: 0
                    }
                }       
            },
            /*line: {
                compare: 'percent'
            }*/
        }
    };
    
    var chart = new Highcharts.StockChart(options);
    
    //Recup�re donn�es compte
    $.ajax({url : '/mods_a/charts/tmDataFeed.php',
        context : document.body,
        async : true,
        data : {idCompte : idCompte, type : iType, date_start: sDebut, date_end: sFin},
        type : 'GET'
    })
    .done(function(data)
    {    
        try
        {
            aDataQuote = JSON.parse(data)    
        }
        catch(e)
        {                                        
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        } 
        
        dataCompte = aDataQuote[0];
                        
        var chartSeries = {                          
            type : 'line',
            name : aDataQuote[1],
            color: "#004EFF",      
            lineWidth: 2,
            data : aDataQuote[0],
            id : idCompte,
            yAxis: "rightAxis",
            index: 0,
            zIndex: 3,
            tooltip : {
                pointFormat : '<tr><td nowrap style="padding:0;font-size:12px">{series.name} : </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.2f}'+suffixTooltip+'</b></td></tr>'
            },
            dataLabels: {
                shape: 'callout',
                backgroundColor: 'rgba(0, 0, 0, 0.75)',
                style: {
                    color: '#FFFFFF',
                    textShadow: 'none'
                },
                y: -10,
                
                enabled: true,
                allowOverlap: true,
                overflow: 'none',    
                crop: false,
                formatter: function () {
                    var series = this.series,
                        lastPoint = series ? series.groupedData[series.groupedData.length - 1] : undefined;
                        
                    if (lastPoint && lastPoint === this.point) {
                        return ((this.point.change) ? this.point.change.toFixed(2) : this.y.toFixed(2))+suffixTooltip;
                    }
                }       
            }            
        };                                   

        // Update the chart                              
        chart.addSeries(chartSeries,true,true);
        
        if((sLastBM != "") && ($("#"+sInDiv).parent().attr('class')) && ($("#"+sInDiv).parent().attr('class').indexOf('chart_with_benchmark') >= 0))
            changeBenchmark(document.getElementById("select_benchmark"));    
    });        
}

function columnChart(sInDiv,idCompte,sDebut,sFin,iType,sCurrency)
{
    options = {
        chart : {
            renderTo: sInDiv,
            /*marginTop : 10,
            spacingTop : 10,
            spacingBottom: 20,*/       
            style :
            {
                fontFamily : 'Arial, Helvetica, Sans-Serif'
            }            
        },
        
        exporting : {
            enabled : false,
        },

        credits : {
            enabled : false 
        },               

        legend : {
            enabled : true
        },

        tooltip: {
            backgroundColor: {
                linearGradient: {
                    x1: 0,
                    y1: 0,
                    x2: 0,
                    y2: 1
                },
                stops: [
                    [0, 'white'],
                    [1, '#EEE']
                ]
            },
            borderColor: 'gray',
            borderWidth: 1,
            borderRadius: 5,
            shared : true,
            headerFormat: '<span style="font-size:12px">'+tradsTM['Date']+' : <b>{point.key}</b></span><br><table style="min-width:150px;">',
            footerFormat: '</table>',
            useHTML: true                          
        },
        
        rangeSelector : {
            enabled: false
        },
        
        navigator : { 
            enabled: false
        },
        
        scrollbar : { 
            enabled: false
        },
        
        xAxis : [
        {
            labels : {   
                align : 'center',
                style : {
                    color: "black"
                },                         
            },
            lineWidth : 1,
            lineColor : 'black',
            gridLineColor : "#ededed",
            gridLineWidth: 1,
            tickLength : 5,
            tickColor : 'black',       
            title : null,
            showFirstLabel: true
        }, 
        {
            lineWidth : 1,
            lineColor : 'black',
            linkedTo: 0,       
            opposite : true,
            labels : {
                enabled : false
            },
            title: null,
            tickLength : 0   
        }],
        
        yAxis : [{
            id: 'leftAxis',
            lineWidth : 1,   
            gridLineColor : "#ededed",
            title : {
                text: tradsTM['pl_values']
            },                    
            opposite : false, 
            lineColor : 'black',
            tickWidth : 1,
            tickLength : 5,
            tickColor : 'black',
            labels : {    
                format : '{value}'+sCurrency,
                verticalAlign : 'middle',
                style : {
                    color: "black"
                }          
            },
            showFirstLabel: true,
            showLastLabel: true,
            plotLines: [{
                color: "black",
                value: 0,
                width: 1,
                zIndex: 2   
            }]                      
        },
        {
            id: 'rightAxis',
            lineWidth : 1,   
            gridLineColor : "#ededed",
            title : {
                text: null
            },  
            lineColor : 'black',
            tickWidth : 1,
            tickLength : 5,
            tickColor : 'black',
            linkedTo : 0,
            labels : {    
                format : '{value}'+sCurrency,
                verticalAlign : 'middle',
                style : {
                    color: "black"
                }          
            },
            showFirstLabel: true,
            showLastLabel: true                      
        }]
    };
    
    var chart = new Highcharts.StockChart(options);
    
    $.ajax({url : '/mods_a/charts/tmDataFeed.php',
        context : document.body,
        async : true,
        data : {idCompte : idCompte, type : iType, date_start: sDebut, date_end: sFin},
        type : 'GET'
    })
    .done(function(data)
    {    
        try
        {
            aDataQuote = JSON.parse(data)    
        }
        catch(e)
        {                                        
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
        
        if(iType==BALANCE_PLUS_MOINS_VALUES_JOUR)
        {
            var dataGroupingOption = {
                forced: 1,
                units: [
                    ['day', [1]]
                ],
                smoothed: true,
                dateTimeLabelFormats: {
                    day: [dateFormatDay]
                }
            };
        }
        else if(iType==BALANCE_PLUS_MOINS_VALUES_HEBDO)
        {
            var dataGroupingOption = {
                forced: 1,
                approximation: "average",
                units: [
                    ['week', [1]]
                ],
                dateTimeLabelFormats: {
                    week: [dateFormatWeek]
                }
            };    
        }
                        
        var chartSeries = {                          
            type : 'column',
            name : aDataQuote[1],
            data : aDataQuote[0],  
            dataGrouping : dataGroupingOption,
            color: "#00B400",
            negativeColor : "#DD0000",
            id : idCompte,
            yAxis: 0,
            zIndex : 2,
            legendIndex: 0,
            tooltip : {
                pointFormat : '<tr><td nowrap style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.2f}'+sCurrency+'</b></td></tr>'
            }            
        };                                   

        // Update the chart                              
        chart.addSeries(chartSeries,true,true);
    });   
}

function changeBenchmark(select)
{
    if(select.value=="not_set")
        return false;
        
    var aParamPerf = $('#param_perf').val().split(';');
    $('#param_perf').val(aParamPerf[0]+";"+select.value);
        
    var idChartDiv = $(".chart_with_benchmark").find('div')[0].id;
    var chart = $("#"+idChartDiv).highcharts();   
    
    if(aQuotesBM[sLastBM])
        chart.get(sLastBM).update({
            visible: false,
            showInLegend: false
        });   
    
    if(select.value=="")
    {
        $("#"+idChartDiv).css('height',$("#"+idChartDiv).attr('initHeight')+"px");
        
        if(chart.get("spread"))
            chart.get("spread").update({
                visible: false
            },false);   
        
        chart.get("rightAxis").update({
            height: "100%",   
        },false);   
        chart.get("rightAxisSpread").update({
            visible: false,
            height: "0%",    
        },true);
        
        chart.reflow();
    }
    else
    {
        $("#"+idChartDiv).css('height',parseInt($("#"+idChartDiv).attr('initHeight')*1.35)+"px"); 
        
        chart.get("rightAxis").update({
            height: "70%",     
        },false);    
        chart.get("rightAxisSpread").update({ 
            visible: true,
            height: "25%",    
        },false);  
        
        chart.reflow();
        
        if(aQuotesBM[select.value])
        {
             chart.get(select.value).update({
                visible: true,
                showInLegend: true
            });
            calculateSpread(select.value,idChartDiv);
        }
        else{
            addBenchmark(select.value,idChartDiv);
        }
    }
    sLastBM = select.value;
}

function addBenchmark(codezb,chartDiv)
{
    //r�cup�re donn�es benchmark
    var chart = $("#"+chartDiv).highcharts(),
        dBenchmarchBegin = new Date(chart.xAxis[0].getExtremes().min),
        dBenchmarchEnd = new Date(chart.xAxis[0].getExtremes().max);
      
    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        context : document.body,
        async : true,
        data : {codeZB : codezb, type : "chart", fields : "Date,Close", date_start: dBenchmarchBegin.getFullYear()+'-'+(dBenchmarchBegin.getMonth()+1)+'-'+dBenchmarchBegin.getDate(), date_end: dBenchmarchEnd.getFullYear()+'-'+(dBenchmarchEnd.getMonth()+1)+'-'+dBenchmarchEnd.getDate()},
        type : 'GET'
    })
    .done(function(data)
    {    
        try
        {
            aDataQuote = JSON.parse(data)    
        }
        catch(e)
        {                                        
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
        
        aQuotesBM[codezb] = aDataQuote;
                
        var chartSeries = {                          
            type : 'line',
            compare: 'percent',
            name : "Benchmark",
            color: Highcharts.getOptions().colors[1],   
            data : aDataQuote,
            id : codezb,
            yAxis: "rightAxis",
            index: 1,
            tooltip : {
                pointFormat : '<tr><td nowrap style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.change}%({point.y:.2f})</b></td></tr>'
            }            
        };                                   

        // Update the chart                              
        chart.addSeries(chartSeries,true,true);
        //chart.xAxis[0].setExtremes(null,null);
        calculateSpread(codezb,chartDiv);
    });   
}
        
function calculateSpread(codezb,chartDiv)
{   
    var chart = $("#"+chartDiv).highcharts(),
        dataCompte = chart.series[0].options.data;
    
    if(aQuotesBM[codezb] && (dataCompte.length>0) && (aQuotesBM[codezb].length>0))
    {
        
        var startBM = aQuotesBM[codezb][0][1],
            normaCompte, normaBM,
            dataCompteCopy = dataCompte.slice(0),
            aQuotesBMCopy = aQuotesBM[codezb].slice(0),
            aDataSpread = [],
            lastDataComtpe = lastBMQuote = null,
            currentBMQuote = aQuotesBMCopy.shift();
        
        while(lastDataCompte = dataCompteCopy.shift())
        {
            //TODO : cas plus de BM      
            
            if(!currentBMQuote && !lastBMQuote)
                break;
            
            var dateCompte = new Date(lastDataCompte[0]),                        
                dateBM = (currentBMQuote) ? new Date(currentBMQuote[0]) : new Date(0);
                    
            if(currentBMQuote)
            {                    
                //Si dateCompte > dateBM avec jour mois ann�e diff�rents    
                while(((dateCompte.getDate()!=dateBM.getDate())||(dateCompte.getMonth()!=dateBM.getMonth())||(dateCompte.getFullYear()!=dateBM.getFullYear())) && (dateCompte>dateBM))
                {
                    lastBMQuote = currentBMQuote.slice(0);
                    if(!(currentBMQuote = aQuotesBMCopy.shift()))
                        break;
                    dateBM = new Date(currentBMQuote[0]);     
                }
            }
            //No currentBMQuote ou dateCompte<dateBM
            if(!currentBMQuote || (((dateCompte.getDate()!=dateBM.getDate())||(dateCompte.getMonth()!=dateBM.getMonth())||(dateCompte.getFullYear()!=dateBM.getFullYear())) && (dateCompte<dateBM)))
                normaBM =  (lastBMQuote[1]-startBM) / startBM * 100;
            else
            {
                normaBM =  (currentBMQuote[1]-startBM) / startBM * 100;
                lastBMQuote = currentBMQuote.slice(0);
                currentBMQuote = aQuotesBMCopy.shift()    
            }
            aDataSpread.push([lastDataCompte[0],lastDataCompte[1]-normaBM]);       
        }    
        
        if(chart.get('spread'))
        {
            chart.get('spread').update({
                visible: true,
                data: aDataSpread
            });    
        }
        else
        {
            var SeriesSpread = {                          
                type : 'area',
                name : "Spread",
                color: "#10FF00",
                negativeColor: "#FF0000",
                negativeFillColor: "#FF0000",
                data : aDataSpread,
                id : "spread",
                yAxis: "rightAxisSpread",
                showInLegend: false,
                index: 2,
                tooltip : {
                    pointFormat : '<tr><td nowrap style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.2f}%</b></td></tr>'
                }            
            };                                   

            // Update the chart                              
            chart.addSeries(SeriesSpread,true,true);    
        }
    }
}

function showChart(sType)
{
    if(sType==lastChart)
        return false;
        
    var aParamPerf = $('#param_perf').val().split(';');
    
    switch(sType)
    {      
        case "perf" :
            $("#td_perf").css('display','table-cell');
            $("#td_valo").css('display','none');
            $("#td_pmv").css('display','none');
            $("#button_perf").addClass('selectedTDPerf');
            $("#button_valo").removeClass('selectedTDPerf');
            $("#button_pmv").removeClass('selectedTDPerf');
            
            $("#select_benchmark").attr("disabled",false);
            $("#select_benchmark").css("color","");
            
            $('#param_perf').val("1;"+aParamPerf[1]);
            
            var chart = $($("#td_perf").children('div')[0]).highcharts();
            chart.reflow();
            break;
            
        case "valo" :
            $("#td_perf").css('display','none');
            $("#td_valo").css('display','table-cell');
            $("#td_pmv").css('display','none');
            $("#button_perf").removeClass('selectedTDPerf');
            $("#button_valo").addClass('selectedTDPerf');
            $("#button_pmv").removeClass('selectedTDPerf');
            
            $("#select_benchmark").attr("disabled",true);
            $("#select_benchmark").css("color","gray");
            
            $('#param_perf').val("2;"+aParamPerf[1]);
            break;
            
        case "pmvalu" :
            $("#td_perf").css('display','none');
            $("#td_valo").css('display','none');
            $("#td_pmv").css('display','table-cell');
            $("#button_perf").removeClass('selectedTDPerf');
            $("#button_valo").removeClass('selectedTDPerf');
            $("#button_pmv").addClass('selectedTDPerf');
            
            $("#select_benchmark").attr("disabled",true);
            $("#select_benchmark").css("color","gray");
            
            $('#param_perf').val("3;"+aParamPerf[1]);
            break;     
    }
    lastChart=sType;   
}