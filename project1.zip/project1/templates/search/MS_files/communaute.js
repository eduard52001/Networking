$( document ).ready(function() {

 
	$(document).on( "click",".post", function() 
	{   
		post($(this));    
	});
 

	$(document).on( "click",".show_reponse", function() {
		
		var element = $(this);
		var data_id = element.attr('data-id');
		var result = data_id.split(',');
		var cpt = 0;
		var cptMouve = 0;
		var newId = [];
		//data-mouv
		var aMsgVisible = [];
		if(element.closest('.notification').find('.btn_form').length)
		{
			var sMsgVisible = element.closest('.notification').find('.btn_form').attr('data-msgVisible');
			if(sMsgVisible!='')
			aMsgVisible = sMsgVisible.split(',');
		}
		
		 
		 
		$.each(result, function( index, value ) {
			if(cpt<10)
			{ 
				element.closest('.notification').find('.reponse[data-id-message="'+value+'"]').removeClass('hide');
				element.closest('.notification').find('.reponse[data-id-message="'+value+'"]').hide();
				element.closest('.notification').find('.reponse[data-id-message="'+value+'"]').fadeIn(800);
 
				aMsgVisible.push(value); 
				cptMouve=value;
			}
			else
			{
				newId.push(value);
			}
			cpt++;
		});
		
		element.closest('.notification').find('.btn_form').attr('data-msgVisible',aMsgVisible.join(','));
		
		element.attr('data-id',newId.join(','));
		if(newId.length==0)
			element.remove();
		else
		{
			element.find('.nb').html(newId.length);
			
			if(element.attr('data-mouv')==1)
			{
				element.closest('.notification').find('.reponse[data-id-message="'+cptMouve+'"]').before(element.clone());
				element.remove();
			}
		}
	});
	
	$(document).on("click", ".next_notification", function() {


		$('.next_notification').html('<img width="100" src="http://www.zonebourse.com/images/loading_100.gif" style="margin:auto;display:block;" class="loader"   alt="loader" >');
		loadNotification(0);
		
	});	
	
  
	$(document).on("click", ".menu_block tbody td", function() {
	
		if($(this).closest('.menu_block').attr('data-ajax')=="0")
		{
			if(!$(this).hasClass('btn_title') && $(this).hasClass('btn_menu'))
			{ 
				$(this).closest('.block').find( ".menu_block" ).find( "td" ).each(function( index ) {
					if($( this ).find('img').length)
					{
						$( this ).find('img').attr('src',$( this ).find('img').attr('src').replace("_blanc", "_gris"));
					}
				});
			
				$(this).closest('.block').find('.item_block').hide();
				$(this).closest('.block').find('.item_block[data-id='+$(this).attr('data-id')+']').show();
				$(this).closest('.block').find('.btn_menu').removeClass('btn_menu_active');
				$(this).addClass('btn_menu_active');
				
				if($( this ).find('img').length)
				{
					$( this ).find('img').attr('src',$( this ).find('img').attr('src').replace("_gris", "_blanc"));
				}
			}
		}
		
	});
 
		
	
	
	
});

 
function loadNotification(first,idTopic=0,idNews=0,msgVisible='')
{
	var data = 'id='+$('#notification').attr('data-id')+
			'&codezb='+$('#notification').attr('data-codezb')+
			'&context='+$('#notification').attr('data-context')+
			'&notification='+$('#notification').attr('data-notification')+
			'&lastDate='+$('.next_notification').attr('data-lastDate')+
			'&nbrc='+$('#notification').attr('data-nbrc');
	
	if(idTopic!=0)
		data += '&idtopic='+idTopic;
	
	if(msgVisible!='')
		data += '&msgVisible='+msgVisible;
	
		
		$.ajax({
			beforeSend: function( xhr ) {
				if(first && idTopic==0)
				$('#notification').html('<img width="100" src="http://www.zonebourse.com/images/loading_100.gif" style="margin:auto;display:block;" class="loader"   alt="loader" >');
			},
			url: "/mods_a/forum/ajax_communaute.php",
			type        : 'GET',
			dataType    : 'html',
			data        : data,
			processData: false,
			contentType: false,
			success : function(code_html, statut){ 
			
				 
				if(idTopic!=0)
				{
					if($('#notification').find('input[name="idtopic"][value="'+idTopic+'"]').closest('.notification').length)
					{
						$('#notification').find('input[name="idtopic"][value="'+idTopic+'"]').closest('.notification').replaceWith(code_html);
					}
					if($('#notification').find('input[name="id_item"][value="'+idNews+'"]').closest('.notification').length)
					{
						$('#notification').find('input[name="id_item"][value="'+idNews+'"]').closest('.notification').replaceWith(code_html);
					}
				}
				else
				{
					$('.next_notification').remove();
					if(first)
					$('.loader').remove();
					$('#notification').append(code_html);
				}
			}
	});
}


function post(element)
{
	element.hide();
	element.closest('form').find('.loader').show();
	element.closest('form').find('.txt_success').hide();
	element.closest('form').find('.txt_error').hide();
	$('.txt_success').hide();


	
	/*ERROR*/
	var error = false; 
	$(this).closest('form').find('textarea[name="content"]').css('border','1px solid silver');
	if($.trim(element.closest('form').find('textarea[name="content"]').val())=='')
	{
		element.closest('form').find('textarea[name="content"]').css('border','1px solid red');
		error = true;
	}
	
	if(error)
	{
		element.closest('form').find('.loader').hide();
		element.closest('form').find('.post').show();  
		return;
	}
	else
	{
		var form = element.closest('form').get(0);
		var formData_context = new FormData(form);
		formData_context.append("ajax", '1');
		formData_context.append("action", 'post_wall'); 
				
	 
		 
		var request = $.ajax({
			  url: "/mods_a/forum/ajax_forum_action.php",
			  type        : 'POST',
			  dataType    : 'html',
			  data        : formData_context,
			  processData: false,
			  contentType: false,
			  success : function(code_html, statut){
				
				var obj = jQuery.parseJSON(code_html);
				var msgVisible = obj.idMessage+','+element.attr('data-msgVisible');
	
				loadNotification(1,obj.idTopic,obj.idNews,msgVisible);
			  }
		});  	
	}
	
           
	
}
