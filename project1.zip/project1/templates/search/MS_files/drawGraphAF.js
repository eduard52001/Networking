if(!configured)
{
    throw new Error('/js/utf-8/configGraph.js is not imported'); 
}

const SKIN_ZB = 1, 
      SKIN_BINCK = 2, 
      SKIN_BINCK_BE = 3, 
      SKIN_BINCK_IT = 4,
      SKIN_ALEX = 8,
      SKIN_PROTRADER = 9;    

function drawGraphEvoCptRes(codeZB,nomSoc,inDiv,aWords,isAsync,bIsMobile,periode)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    periode = (typeof periode === "undefined") ? "A" : periode;
    /**
    * Experimental Highcharts plugin to implement chart.alignThreshold option.
    * Author: Torstein HÃ¸nsi
    * Last revision: 2013-12-02
    */                         
    (function (H) {
        var each = H.each;
        H.wrap(H.Chart.prototype, 'adjustTickAmounts', function (proceed) {                  
            var ticksBelowThreshold = 0,
            ticksAboveThreshold = 0;
            if (this.options.chart.alignThresholds) {
                each(this.yAxis, function (axis) {
                    var threshold = axis.series[0] && axis.series[0].options.threshold || 0,
                    index = axis.tickPositions && axis.tickPositions.indexOf(threshold);

                    if (index !== undefined && index !== -1) {
                        axis.ticksBelowThreshold = index;
                        axis.ticksAboveThreshold = axis.tickPositions.length - index;
                        ticksBelowThreshold = Math.max(ticksBelowThreshold, index);
                        ticksAboveThreshold = Math.max(ticksAboveThreshold, axis.ticksAboveThreshold);
                    }
                });

                each(this.yAxis, function (axis) {

                    var tickPositions = axis.tickPositions;

                    if (tickPositions) {

                        if (axis.ticksAboveThreshold < ticksAboveThreshold) {
                            while (axis.ticksAboveThreshold < ticksAboveThreshold) {
                                tickPositions.push(
                                    tickPositions[tickPositions.length - 1] + axis.tickInterval
                                );
                                axis.ticksAboveThreshold++;
                            }
                        }

                        if (axis.ticksBelowThreshold < ticksBelowThreshold) {
                            while (axis.ticksBelowThreshold < ticksBelowThreshold) {
                                tickPositions.unshift(
                                    tickPositions[0] - axis.tickInterval
                                );
                                axis.ticksBelowThreshold++;
                            }

                        }
                        //axis.transA *= (calculatedTickAmount - 1) / (tickAmount - 1);
                        axis.min = tickPositions[0];
                        axis.max = tickPositions[tickPositions.length - 1];
                    }
                });
            } else {
                proceed.call(this);
            }

        });
        }(Highcharts));

    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        crossDomain: true,
        data : {codeZB : codeZB, t : 'ecr', iLang: iLang, p: periode},
        type : 'GET'
    })
    .done(function(data){
        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }

        var aYears = Object.keys(dataChart[1]);              
        var aData = dataChart[0];
        var sCurrency = dataChart[2];

        var size1, size2, size1r, size2r, sHeight, rotation, sBottom, mBottom, sTop, mTop, sLeft, sRight, yMargin, labelMargin;

        if($('#'+inDiv).height()<=300)
        {
            //Chart styles
            sBottom = 15;
            mBottom = 55;
            sTop = 0;
            mTop = 45;
            sLeft = 0;
            sRight = 3;

            //Title styles
            xTitle = 10;

            //legend styles
            sHeight = 8;

            //texts styles
            size1 = "10px";
            size2 = "8px";
            size1r = "12px";
            size2r = "10px";

            //axis styles
            yMargin = 3;
            labelMargin = 6;
        }
        else
        {
            //Chart styles
            sBottom = 25;
            mBottom = null;
            sTop = 0;
            mTop = 45;
            sLeft = null;
            sRight = null;

            //Title styles
            xTitle = 0;

            //legend styles
            sHeight = 12;

            //texts styles
            size1 = "12px";
            size2 = "12px";
            size1r = "14px";
            size2r = "14px";

            //axis styles
            yMargin = null;
            labelMargin = 10; 
        }

        if($('#'+inDiv).width()<=450)
        {
            //axis styles
            rotation = -45;
        }
        else
        {
            //axis styles
            rotation = 0;                
        }

        //Define the initial, basic options.
        var options = {
            chart: {                                              
                alignThresholds: true,
                alignTicks:false,      
                backgroundColor : aMainStyle.backgroundColor,
                //marginBottom : mBottom,
                renderTo : inDiv,                            
                spacingBottom: aMainStyle.spacingBottom,       
                spacingLeft: aMainStyle.spacingLeft,
                spacingRight: aMainStyle.spacingRight + ((periode=="Q") ? 15 : 0), 
                spacingTop : -10,    
            },

            credits : {
                enabled : true,                                                                                            
                href : null,
                position: {
                    align: aMainStyle.legendAlign,
                    x: 0
                },
                style : {
                    fontSize : aMainStyle.fontSize1               
                },
                text : '\u00A9'+aWords[0]+' - S&P Global Market Intelligence' 
            }, 

            exporting : {
                enabled : false
            },     

            legend : {
                borderWidth : 0,
                itemStyle :{
                    fontSize : aMainStyle.fontSize1,
                    fontWeight: "normal"
                },
                margin: aMainStyle.legendMargin,
                symbolHeight: aMainStyle.symbolHeight 
            },       

            loading: {
                hideDuration : 250,
                style : {
                    backgroundColor : 'gray'
                },
                labelStyle : {
                    color : 'white',
                    top: '45%'                             
                }
            },

            plotOptions: {
                column : {
                    borderWidth : 0,
                    pointPadding: 0.01,
                    shadow : false
                },
                line : {
                    marker : {
                        fillColor: 'black',    
                        radius: 3,
                        symbol: "circle"                     
                    },
                    shadow : true
                },
                series: {
                    animation: isAsync
                }      
            },      

            title : {           
                align : 'left',
                style :{
                    color : '#6e6e6e',
                    fontSize : aMainStyle.fontSize1,                           
                    fontWeight: 'bold'
                },
                text : nomSoc,
                x : 0
            },  

            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                shared : true,
                headerFormat: '<span style="font-size:12px;">'+aWords[7]+' : <b>{point.key}</b></span><br><table style="min-width:150px;font-size:12px;">',
                footerFormat: '</table>',
                useHTML: true                            
            },

            xAxis : [
            {
                categories : aYears,   
                gridLineColor : aMainStyle.xAxisgridLineColor, 
                gridLineDashStyle: aMainStyle.xAxisgridLineDashStyle,
                gridLineWidth : aMainStyle.xAxisgridLineWidth,   
                labels : {
                    autoRotation : [-45,0],
                    style : {
                        color: aMainStyle.xAxisLabelColor,
                        fontSize: aMainStyle.fontSize1,
                        fontWeight: aMainStyle.xAxisLabelWeight                            
                    },
                    y : -5
                },
                lineWidth : aMainStyle.xAxisTopLineWidth,
                opposite : true,
                tickWidth : aMainStyle.xAxisTopTickWidth
            },
            {
                categories : aYears,
                gridLineWidth : 0,
                labels : {
                    enabled : false
                },
                lineColor : aMainStyle.xAxisBottomLineColor,
                lineWidth: aMainStyle.xAxisBottomLineWidth,          
                linkedTo : 0,          
                tickWidth : aMainStyle.xAxisBottomTickWidth,
                zIndex: 4             
            }
            ],

            yAxis: [
            {
                gridLineWidth : aMainStyle.yAxisLeftGridLineWidth,      
                labels: {         
                    align: "right",
                    formatter: function () {
                        return Highcharts.numberFormat(this.value,0);
                    },
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                    x: -5 
                },
                lineColor : aMainStyle.yAxisLeftLineColor,
                lineWidth: aMainStyle.yAxisLeftLineWidth,   
                tickWidth : aMainStyle.yAxisLeftTickWidth,  
                title: {
                    style: {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1 
                    },
                    text: aWords[1]+" "+(sCurrency||'')
                }                                      
            },
            {    
                gridLineWidth : 0,
                labels :{         
                    align: "left", 
                    formatter: function(){
                        if((Number(this.value.toFixed(2))-this.value)!==0)
                            return Highcharts.numberFormat(this.value.toFixed(2))+"%";
                        else
                            return Highcharts.numberFormat(this.value)+"%";
                    },
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                    x : 5
                },
                lineWidth: aMainStyle.yAxisRightLineWidth,   
                opposite : true,    
                tickWidth : aMainStyle.yAxisRightTickWidth,
                title : {
                    text : null
                }                            
            }]
        };

        var chart = new Highcharts.Chart(options);     

        if(isAsync)
            chart.showLoading();

        var seriesCA = {
            type : 'column',
            yAxis : 0,
            color : '#333333',
            data : aData[0],
            name : aWords[2],
            id : 'ca',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.0f}&nbsp;M&nbsp;'+(sCurrency||'')+'</b></td></tr>'
            }               
        };

        var seriesRE = {
            type : 'column',
            yAxis : 0,
            color : '#FFCC33',
            data : aData[1],
            name : aWords[3],
            id : 're',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.0f}&nbsp;M&nbsp;'+(sCurrency||'')+'</b></td></tr>'
            }               
        };

        var seriesRN = {
            type : 'column',
            yAxis : 0,
            color : '#5AB400',
            data : aData[2],
            name : aWords[4],
            id : 'rn',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.0f}&nbsp;M&nbsp;'+(sCurrency||'')+'</b></td></tr>'
            }               
        };

        var seriesMN = {
            type : 'line',
            yAxis : 1,
            color : '#5AB400',
            data : aData[3],
            name : aWords[5],
            id : 'mn',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.2f}&nbsp;%</b></td></tr>'
            }              
        };

        var seriesME = {
            type : 'line',
            yAxis : 1,
            color : '#FFCC33', 
            data : aData[4],
            name : aWords[6],
            id : 'me',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.2f}&nbsp;%</b></td></tr>'
            }             
        };

        chart.addSeries(seriesCA,false,isAsync);
        chart.addSeries(seriesRE,false,isAsync);
        chart.addSeries(seriesRN,false,isAsync);
        chart.addSeries(seriesMN,false,isAsync);
        chart.addSeries(seriesME,true,isAsync);     //redraw chart after adding the last series    

        chart.hideLoading();      

    })
    .fail(function(xhr, textStatus){
        console.log( "error ajax : ");
        $.each(xhr,function(index,error){
            console.log( "["+index+"] -> "+error);     
        })
    });    
}


function drawGraphEvoCptResMini(codeZB,nomSoc,inDiv,aWords,isAsync,bIsMobile)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;

    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : 'ecrm', iLang: iLang},
        type : 'GET'
    })
    .done(function(data){    
        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
        var aYears = Object.keys(dataChart[1]);              
        var aData = dataChart[0];
        var sCurrency = dataChart[2];
        var lineWidth = 2;

        //Define the initial, basic options.
        var options = {

            chart: {
                alignTicks:true,
                backgroundColor : aMainStyle.backgroundColor,         
                marginTop : 45,
                renderTo : inDiv,    
                spacingBottom: aMainStyle.spacingBottom,
                spacingLeft: aMainStyle.spacingLeft,
                spacingRight: aMainStyle.spacingRight    
            },

            credits : {
                enabled : true,                                                                                            
                href : null,
                position: {
                    align: aMainStyle.legendAlign,
                    x: 0
                },
                style : {
                    fontSize : aMainStyle.fontSize1               
                },
                text : '\u00A9'+aWords[0]+' - S&P Global Market Intelligence' 
            },

            exporting : {
                enabled : false
            },       

            legend : {
                borderWidth : 0,
                itemStyle :{
                    fontSize : aMainStyle.fontSize1,
                    fontWeight: "normal"
                },
                margin: aMainStyle.legendMargin,
                symbolHeight : aMainStyle.symbolHeight
            },             

            loading: {
                hideDuration : 250,
                style : {
                    backgroundColor : 'gray'
                },
                labelStyle : {
                    color : 'white',
                    top: '45%'                             
                }
            },
            
            plotOptions: {
                column : {
                    borderWidth : 0,
                    pointPadding: 0.01,
                    shadow : false
                },
                line : {
                    marker : {
                        fillColor: 'black',
                        lineColor: 'white',
                        lineWidth: 2,
                        radius: 3,
                        symbol: "cirlce"                 
                    },
                    shadow : true
                },
                series: {
                    animation: isAsync
                }      
            },
            
            responsive: {
                rules : [{
                    chartOptions: {
                        xAxis : [
                        {
                            labels: {
                                rotation: -45
                            }
                        }]    
                    },
                    condition: {
                        maxWidth: 380 
                    }
                },
                {
                    chartOptions: {
                        chart:{
                            spacingBottom: aMainStyle.spacingBottom-3        
                        },
                        legend : {
                            margin: aMainStyle.legendMargin-3
                        }    
                    },
                    condition: {
                        maxHeight: 350 
                    }
                }]    
            },

            title : {           
                align : 'left',
                style :{
                    color : '#6e6e6e',
                    fontSize : aMainStyle.fontSize1,                           
                    fontWeight: 'bold'
                },
                text : nomSoc,
                x : 0
            }, 

            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                shared : true,
                headerFormat: '<span style="font-size:12px">'+aWords[5]+' : <b>{point.key}</b></span><br><table style="min-width:150px;">',
                footerFormat: '</table>',
                useHTML: true                            
            },

            xAxis : [
            {
                categories : aYears,   
                gridLineColor : aMainStyle.xAxisgridLineColor, 
                gridLineDashStyle: aMainStyle.xAxisgridLineDashStyle,
                gridLineWidth : aMainStyle.xAxisgridLineWidth,   
                labels : {
                    style : {
                        color: aMainStyle.xAxisLabelColor,
                        fontSize: aMainStyle.fontSize1,
                        fontWeight: aMainStyle.xAxisLabelWeight                            
                    },
                    y : -5
                },
                lineWidth : aMainStyle.xAxisTopLineWidth,
                opposite : true,
                tickWidth : aMainStyle.xAxisTopTickWidth
            },
            {
                categories : aYears,
                gridLineWidth : 0,
                labels : {
                    enabled : false
                },
                lineColor : aMainStyle.xAxisBottomLineColor,
                lineWidth: aMainStyle.xAxisBottomLineWidth,          
                linkedTo : 0,          
                tickWidth : aMainStyle.xAxisBottomTickWidth,
                zIndex: 4          
            }
            ],

            yAxis : [
            {
                gridLineWidth : aMainStyle.yAxisLeftGridLineWidth,      
                labels: {         
                    align: "right",
                    formatter: function () {
                        return Highcharts.numberFormat(this.value,0);
                    }, 
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                    x: -5 
                },
                lineColor : aMainStyle.yAxisLeftLineColor,
                lineWidth: aMainStyle.yAxisLeftLineWidth,   
                minPadding: 0.1,    
                tickWidth : aMainStyle.yAxisLeftTickWidth,  
                title: {
                    style: {
                        fontSize: aMainStyle.fontSize1,
                        color: aMainStyle.yAxisLabelColor
                    },
                    text: aWords[1]+" "+(sCurrency||'')
                },
                startOnTick: false                                      
            },
            {
                gridLineWidth : 0,
                labels :{         
                    align: "left", 
                    format: '{value}%',
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                    x : 5
                },
                lineWidth: aMainStyle.yAxisRightLineWidth, 
                opposite : true,
                tickWidth : aMainStyle.yAxisRightTickWidth,
                title : {
                    text : null
                }                                             
            }]
        };

        var chart = new Highcharts.Chart(options);     

        if(isAsync)
            chart.showLoading();

        var seriesCA = {
            type : 'column',
            yAxis : 0,
            color : '#333333',
            data : aData[0],
            name : aWords[2]+" ",
            id : 'ca',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.0f}&nbsp;M&nbsp;'+(sCurrency||'')+'</b></td></tr>'
            }
        };

        var seriesRN = {
            type : 'column',
            yAxis : 0,
            color : '#5AB400',
            data : aData[1],
            name : aWords[3],
            id : 'rn',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.0f}&nbsp;M&nbsp;'+(sCurrency||'')+'</b></td></tr>'
            }               
        };

        var seriesMN = {
            type : 'line',
            yAxis : 1,
            color : '#5AB400',
            data : aData[2],
            name : aWords[4],
            id : 'mn',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.2f}&nbsp;%</b></td></tr>'
            }              
        };  

        chart.addSeries(seriesCA,false,isAsync);
        chart.addSeries(seriesRN,false,isAsync);
        chart.addSeries(seriesMN,true,isAsync);     //redraw chart after adding the last series

        chart.hideLoading();

    })
    .fail(function(xhr, textStatus){
        console.log( "error ajax : ");
        $.each(xhr,function(index,error){
            console.log( "["+index+"] -> "+error);     
        })
    });
}


function drawGraphEvoCptResMiniLight(codezbinDiv,aWords)
{  
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;                                                                     
    /**
    * Experimental Highcharts plugin to implement chart.alignThreshold option.
    * Author: Torstein HÃ¸nsi
    * Last revision: 2013-12-02
    */                         
    (function (H) {
        var each = H.each;
        H.wrap(H.Chart.prototype, 'adjustTickAmounts', function (proceed) {
            var ticksBelowThreshold = 0,
            ticksAboveThreshold = 0;
            if (this.options.chart.alignThresholds) {
                each(this.yAxis, function (axis) {
                    var threshold = axis.series[0] && axis.series[0].options.threshold || 0,
                    index = axis.tickPositions && axis.tickPositions.indexOf(threshold);

                    if (index !== undefined && index !== -1) {
                        axis.ticksBelowThreshold = index;
                        axis.ticksAboveThreshold = axis.tickPositions.length - index;
                        ticksBelowThreshold = Math.max(ticksBelowThreshold, index);
                        ticksAboveThreshold = Math.max(ticksAboveThreshold, axis.ticksAboveThreshold);
                    }
                });

                each(this.yAxis, function (axis) {

                    var tickPositions = axis.tickPositions;

                    if (tickPositions) {

                        if (axis.ticksAboveThreshold < ticksAboveThreshold) {
                            while (axis.ticksAboveThreshold < ticksAboveThreshold) {
                                tickPositions.push(
                                    tickPositions[tickPositions.length - 1] + axis.tickInterval
                                );
                                axis.ticksAboveThreshold++;
                            }
                        }

                        if (axis.ticksBelowThreshold < ticksBelowThreshold) {
                            while (axis.ticksBelowThreshold < ticksBelowThreshold) {
                                tickPositions.unshift(
                                    tickPositions[0] - axis.tickInterval
                                );
                                axis.ticksBelowThreshold++;
                            }

                        }
                        //axis.transA *= (calculatedTickAmount - 1) / (tickAmount - 1);
                        axis.min = tickPositions[0];
                        axis.max = tickPositions[tickPositions.length - 1];
                    }
                });
            } else {
                proceed.call(this);
            }

        });
        }(Highcharts));

    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : true,
        data : {codeZB : codeZB, t : 'ecrm', iLang: iLang},
        type : 'GET'
    })
    .done(function(data){    
        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
        var aYearsTemp = Object.keys(dataChart[1]);              
        var aData = dataChart[0];
        var sCurrency = dataChart[2];
        var aYearsEstimated = [];
        var aPassedYears = [];
        var lineWidth = 2;
                
        while(elmnt = aYearsTemp.pop())
        {
            if(elmnt.indexOf("e")>=0)
                aYearsEstimated.unshift(elmnt);
            else
                aPassedYears.unshift(elmnt);        
        }
        
        if(aYearsEstimated.length>2)
            aYearsEstimated = aYearsEstimated.slice(0,2);
        if(aPassedYears.length>3)
            aPassedYears = aPassedYears.slice(-3);
            
        var aYears = aPassedYears.concat(aYearsEstimated);
        var dataLength = aData[0].length;
        
        for(i=(dataLength-1); i>=0; i--)
        {
            $.each(aData, function(index,seriesData)
            {
                if(aYears.indexOf(seriesData[i][0])==-1)
                    aData[index].splice(i,1);                    
            });        
        }

        //Define the initial, basic options.
        var options = {

            chart: {
                renderTo : inDiv,
                backgroundColor : 'white',  
                alignThresholds: true,
                spacingTop : 0,
                spacingLeft: 5,
                alignTicks:false
            },

            exporting : {
                enabled : false
            },

            title : { 
                text : ""
            },

            legend : { 
                enabled : false
            },

            credits : {
                enabled : false
            }, 

            loading: {
                hideDuration : 250,
                style : {
                    backgroundColor : 'gray'
                },
                labelStyle : {
                    color : 'white',
                    top: '45%'                             
                }
            },

            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                shared : true,
                headerFormat: '<span style="font-size:12px">'+aWords[4]+' : <b>{point.key}</b></span><br><table style="min-width:150px;">',
                footerFormat: '</table>',
                useHTML: true                            
            },

            xAxis : [{
                categories : aYears,
                opposite : true,
                gridLineDashStyle: 'Dot',
                gridLineWidth : 1,
                lineWidth : lineWidth,
                lineColor : '#A5A5A5',
                tickWidth : 0,           
                labels : {
                    style : {
                        fontWeight : 'bold'                            
                    },
                    rotation: -45,
                    y : -5
                }
            },
            {     
                categories : aYears,
                linkedTo : 0,
                gridLineWidth : 0,
                lineWidth: lineWidth,
                lineColor : '#A5A5A5',
                tickWidth : 2,
                tickLength : 5,
                tickColor : '#A5A5A5',   
                labels : {
                    enabled : false
                },
                offset: lineWidth / 2         
            }],

            yAxis : [{
                title : {
                    text : aWords[0]+" "+(sCurrency||''),
                    style : {
                        fontSize : "12px",        
                        color : "#434343"
                    }
                    //x : 8
                },
                alternateGridColor: "white",
                lineWidth: 2,
                lineColor : '#A5A5A5',
                tickWidth : 2,
                tickLength : 5,
                tickColor : '#A5A5A5',
                tickPixelInterval : 30,
                labels: {
                    formatter: function () {
                        return Highcharts.numberFormat(this.value,0);
                    },
                    x : -8 
                }                                             
            },
            {
                title : {
                    text : ''
                },
                lineWidth: 2,
                lineColor : '#A5A5A5',
                gridLineWidth : 0,
                tickWidth : 2,
                tickLength : 5,
                tickColor : '#A5A5A5',
                labels :{
                    format: '{value}%', 
                    x : 8
                },
                opposite : true,                                
            }],

            plotOptions: {
                column : {
                    borderWidth : 0,
                    pointPadding: 0.01,
                    shadow : true
                },
                line : {
                    marker : {
                        fillColor: 'black',
                        lineColor: 'white',
                        lineWidth: 2,
                        symbol: "circle"                     
                    },
                    shadow : true
                }      
            }

        };

        var chart = new Highcharts.Chart(options);     

        chart.showLoading();

        var seriesCA = {
            type : 'column',
            yAxis : 0,
            color : '#333333',
            data : aData[0],
            name : aWords[1],
            id : 'ca',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.0f}&nbsp;M&nbsp;'+(sCurrency||'')+'</b></td></tr>'
            }
        };

        var seriesRN = {
            type : 'column',
            yAxis : 0,
            color : '#5AB400',
            data : aData[1],
            name : aWords[2],
            id : 'rn',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.0f}&nbsp;M&nbsp;'+(sCurrency||'')+'</b></td></tr>'
            }               
        };

        var seriesMN = {
            type : 'line',
            yAxis : 1,
            color : '#5AB400',
            data : aData[2],
            name : aWords[3],
            id : 'mn',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.2f}&nbsp;%</b></td></tr>'
            }              
        };  

        chart.addSeries(seriesCA,false);
        chart.addSeries(seriesRN,false);
        chart.addSeries(seriesMN,true);     //redraw chart after adding the last series

        chart.hideLoading();

    })
    .fail(function(xhr, textStatus){
        console.log( "error ajax : ");
        $.each(xhr,function(index,error){
            console.log( "["+index+"] -> "+error);     
        })
    });
}


function drawGraphSitFin(codeZB,nomSoc,inDiv,aWords,isAsync,bIsMobile)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    /**
    * Experimental Highcharts plugin to implement chart.alignThreshold option.
    * Author: Torstein HÃ¸nsi
    * Last revision: 2013-12-02
    */


    (function (H) {
        var each = H.each;
        H.wrap(H.Chart.prototype, 'adjustTickAmounts', function (proceed) {
            var ticksBelowThreshold = 0,
            ticksAboveThreshold = 0;
            if (this.options.chart.alignThresholds) {
                each(this.yAxis, function (axis) {
                    var threshold = axis.series[0] && axis.series[0].options.threshold || 0,
                    index = axis.tickPositions && axis.tickPositions.indexOf(threshold);

                    if (index !== undefined && index !== -1) {
                        axis.ticksBelowThreshold = index;
                        axis.ticksAboveThreshold = axis.tickPositions.length - index;
                        ticksBelowThreshold = Math.max(ticksBelowThreshold, index);
                        ticksAboveThreshold = Math.max(ticksAboveThreshold, axis.ticksAboveThreshold);
                    }
                });

                each(this.yAxis, function (axis) {

                    var tickPositions = axis.tickPositions;

                    if (tickPositions) {

                        if (axis.ticksAboveThreshold < ticksAboveThreshold) {
                            while (axis.ticksAboveThreshold < ticksAboveThreshold) {
                                tickPositions.push(
                                    tickPositions[tickPositions.length - 1] + axis.tickInterval
                                );
                                axis.ticksAboveThreshold++;
                            }
                        }

                        if (axis.ticksBelowThreshold < ticksBelowThreshold) {
                            while (axis.ticksBelowThreshold < ticksBelowThreshold) {
                                tickPositions.unshift(
                                    tickPositions[0] - axis.tickInterval
                                );
                                axis.ticksBelowThreshold++;
                            }

                        }
                        //axis.transA *= (calculatedTickAmount - 1) / (tickAmount - 1);
                        axis.min = tickPositions[0];
                        axis.max = tickPositions[tickPositions.length - 1];
                    }
                });
            } else {
                proceed.call(this);
            }

        });
        }(Highcharts));

    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : 'sf', iLang: iLang},
        type : 'GET'
    })
    .done(function(data){

        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }

        var size1, size2, size1r, size2r, sHeight, rotation, sBottom, mBottom, sTop, mTop, sLeft, sRight, yMargin, labelMargin;

        if($('#'+inDiv).height()<=300)
        {
            //Chart styles
            sBottom = 15;
            mBottom = 55;
            sTop = 0;
            mTop = 45;
            sLeft = 0;
            sRight = 3;

            //Title styles
            xTitle = 10;

            //legend styles
            sHeight = 8;

            //texts styles
            size1 = "10px";
            size2 = "8px";
            size1r = "12px";
            size2r = "10px";

            //axis styles
            yMargin = 3;
            labelMargin = 6;
        }
        else
        {
            //Chart styles
            sBottom = 25;
            mBottom = null;
            sTop = 0;
            mTop = 45;
            sLeft = null;
            sRight = null;

            //Title styles
            xTitle = 0;

            //legend styles
            sHeight = 12;

            //texts styles
            size1 = "12px";
            size2 = "12px";
            size1r = "14px";
            size2r = "14px";

            //axis styles
            yMargin = null;
            labelMargin = 10; 
        }  

        var aData = dataChart[0];
        var aYears = new Array();  
        
        $.each(dataChart[1], function(index,indYear)
        {
            aYears.push(indYear);        
        });
         
        var bExtraPadding = true;
        $.each(aData[3], function(index,value)
        {
            bExtraPadding = bExtraPadding&&(value[1]===null);        
        }); 
        var iExtraPadding = bExtraPadding ? 10 : 0;  

        var sCurrency = dataChart[2];

        //Define the initial, basic options.
        var options = {
            chart: {                                              
                alignThresholds: true,
                alignTicks:false,      
                backgroundColor : aMainStyle.backgroundColor,
                marginBottom : mBottom,
                renderTo : inDiv,                            
                spacingBottom: sBottom,       
                spacingLeft: aMainStyle.spacingLeft,
                spacingRight: aMainStyle.spacingRight + iExtraPadding, 
                spacingTop : -10,    
            },

            credits : {
                enabled : true,                                                                                            
                href : null,
                position: {
                    align: aMainStyle.legendAlign,
                    x: 0
                },
                style : {
                    fontSize : aMainStyle.fontSize1               
                },
                text : '\u00A9'+aWords[0]+' - S&P Global Market Intelligence' 
            },

            exporting : {
                enabled : false
            },       

            legend : {
                borderWidth : 0,
                itemStyle :{
                    fontSize : aMainStyle.fontSize1,
                    fontWeight: "normal"
                },
                symbolHeight : sHeight
            },

            loading: {
                hideDuration : 250,
                style : {
                    backgroundColor : 'gray'
                },
                labelStyle : {
                    color : 'white',
                    top: '45%'                             
                }
            },

            plotOptions: {
                column : {
                    borderWidth : 0,
                    pointPadding: 0.01,
                    shadow : false,
                },
                line : {
                    marker : {
                        fillColor: 'black',
                        radius: 3,
                        symbol: "cirlce"                 
                    },
                    shadow : true,
                },
                series: {
                    animation: isAsync
                }      
            },
            
            responsive: {
                rules : [{ 
                    chartOptions: {
                        chart:
                        {
                            spacingRight : aMainStyle.spacingRight   
                        }   
                    },
                    condition: {
                        minWidth: 420 
                    }
                }]
            },    

            title : {           
                align : 'left',
                style :{
                    color : '#6e6e6e',
                    fontSize : aMainStyle.fontSize1,                           
                    fontWeight: 'bold'
                },
                text : nomSoc,
                x : 0
            },   

            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                shared : true,
                headerFormat: '<span style="font-size:12px;">'+aWords[7]+' : <b>{point.key}</b></span><br><table style="min-width:150px;font-size:12px;">',
                footerFormat: '</table>',
                useHTML: true
            },  

            xAxis : [
            {
                categories : aYears,   
                gridLineColor : aMainStyle.xAxisgridLineColor, 
                gridLineDashStyle: aMainStyle.xAxisgridLineDashStyle,
                gridLineWidth : aMainStyle.xAxisgridLineWidth,   
                labels : {
                    autoRotation : [-45,0],
                    style : {
                        color: aMainStyle.xAxisLabelColor,
                        fontSize: aMainStyle.fontSize1,
                        fontWeight: aMainStyle.xAxisLabelWeight                            
                    },
                    y : -5
                },
                lineWidth : aMainStyle.xAxisTopLineWidth,
                opposite : true,
                tickWidth : aMainStyle.xAxisTopTickWidth
            },
            {
                categories : aYears,
                gridLineWidth : 0,
                labels : {
                    enabled : false
                },
                lineColor : aMainStyle.xAxisBottomLineColor,
                lineWidth: aMainStyle.xAxisBottomLineWidth,          
                linkedTo : 0,          
                tickWidth : aMainStyle.xAxisBottomTickWidth,
                zIndex: 4             
            }
            ],

            yAxis : [
            {
                gridLineWidth : 0,      
                labels: {         
                    align: "right",
                    formatter: function () {
                        return Highcharts.numberFormat(this.value,0);
                    },
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                    x: -5 
                },
                lineColor : aMainStyle.yAxisLeftLineColor,
                lineWidth: aMainStyle.yAxisLeftLineWidth,     
                tickWidth : aMainStyle.yAxisLeftTickWidth,  
                title: {
                    style: {
                        fontSize: aMainStyle.fontSize1,
                        color: aMainStyle.yAxisLabelColor
                    },
                    text: aWords[1]+" "+(sCurrency||'')
                }                                      
            },
            {
                gridLineWidth : 0,
                labels :{         
                    align: "left", 
                    formatter: function(){
                        if((Number(this.value.toFixed(2))-this.value)!==0)
                            return Highcharts.numberFormat(this.value.toFixed(2));
                        else
                            return Highcharts.numberFormat(this.value);
                    },
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                    x : 5
                },
                lineWidth: aMainStyle.yAxisRightLineWidth,   
                opposite : true,  
                tickWidth : aMainStyle.yAxisRightTickWidth,  
                title : {
                    text : null  
                }                            
            }]
        };

        var chart = new Highcharts.Chart(options);

        if(isAsync)
            chart.showLoading();

        var seriesCA = {
            type : 'column',
            yAxis : 0,
            color : '#333333',
            data : aData[0],
            name : aWords[3],
            id : 'ca',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.0f}&nbsp;M&nbsp;'+(sCurrency||'')+'</b></td></tr>'
            }       
        };

        var seriesTD = {
            type : 'column',
            yAxis : 0,
            color : '#007FFF',
            data : aData[1],
            name : aWords[4],
            id : 'td',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.0f}&nbsp;M&nbsp;'+(sCurrency||'')+'</b></td></tr>'
            }     
        };

        var seriesEBITDA = {
            type : 'column',
            yAxis : 0,
            color : '#E98E16',
            data : aData[2],
            name : aWords[5],
            id : 'ebitda',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.0f}&nbsp;M&nbsp;'+(sCurrency||'')+'</b></td></tr>'
            }  
        };

        var seriesLEV = {
            type : 'line',
            yAxis : 1,
            color : '#E98E16', 
            data : aData[3],
            name : aWords[6],
            id : 'lev',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.3f}</b></td></tr>'
            }                
        };  

        chart.addSeries(seriesCA,false,isAsync);
        chart.addSeries(seriesTD,false,isAsync);
        chart.addSeries(seriesEBITDA,false,isAsync);
        chart.addSeries(seriesLEV,true,isAsync);        //redraw chart after adding the last series  

        chart.hideLoading();      
    }); 
}


function drawGraphSitBil(codeZB,nomSoc,inDiv,aWords,isAsync,bIsMobile)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;

    /**
    * Experimental Highcharts plugin to implement chart.alignThreshold option.
    * Author: Torstein HÃ¸nsi
    * Last revision: 2013-12-02
    */ 
    (function (H) {
        var each = H.each;
        H.wrap(H.Chart.prototype, 'adjustTickAmounts', function (proceed) {
            var ticksBelowThreshold = 0,
            ticksAboveThreshold = 0;
            if (this.options.chart.alignThresholds) {
                each(this.yAxis, function (axis) {
                    var threshold = axis.series[0] && axis.series[0].options.threshold || 0,
                    index = axis.tickPositions && axis.tickPositions.indexOf(threshold);

                    if (index !== undefined && index !== -1) {
                        axis.ticksBelowThreshold = index;
                        axis.ticksAboveThreshold = axis.tickPositions.length - index;
                        ticksBelowThreshold = Math.max(ticksBelowThreshold, index);
                        ticksAboveThreshold = Math.max(ticksAboveThreshold, axis.ticksAboveThreshold);
                    }
                });

                each(this.yAxis, function (axis) {


                    var tickPositions = axis.tickPositions;

                    if (tickPositions) {

                        if (axis.ticksAboveThreshold < ticksAboveThreshold) {
                            while (axis.ticksAboveThreshold < ticksAboveThreshold) {
                                tickPositions.push(
                                    tickPositions[tickPositions.length - 1] + axis.tickInterval
                                );
                                axis.ticksAboveThreshold++;
                            }
                        }

                        if (axis.ticksBelowThreshold < ticksBelowThreshold) {
                            while (axis.ticksBelowThreshold < ticksBelowThreshold) {
                                tickPositions.unshift(
                                    tickPositions[0] - axis.tickInterval
                                );
                                axis.ticksBelowThreshold++;
                            }

                        }
                        //axis.transA *= (calculatedTickAmount - 1) / (tickAmount - 1);
                        axis.min = tickPositions[0];
                        axis.max = tickPositions[tickPositions.length - 1];
                    }
                });
            } else {
                proceed.call(this);
            }

        });
        }(Highcharts));

    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        crossDomain: true,
        data : {codeZB : codeZB, t : 'sb', iLang: iLang},
        type : 'GET'
    })
    .done(function(data){

        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }

        var size1, size2, size1r, size2r, lBorder, sHeight, rotation, sBottom, mBottom, sTop, mTop, sLeft, sRight, yMargin, labelMargin;

        if($('#'+inDiv).height()<=300)
        {
            //Chart styles
            sBottom = 15;
            mBottom = 55;
            sTop = 0;
            mTop = 40;
            sLeft = 0;
            sRight = 10;

            //Title styles
            xTitle = 10;

            //legend styles
            lBorder = 1;
            sHeight = 8;

            //texts styles
            size1 = "10px";
            size2 = "8px";
            size1r = "12px";
            size2r = "10px";

            //axis styles
            yMargin = 3;
            labelMargin = 6;
        }
        else
        {
            //Chart styles
            sBottom = 25;
            mBottom = null;
            sTop = 0;
            mTop = 40;
            sLeft = null;
            sRight = null;

            //Title styles
            xTitle = 0;

            //legend styles
            lBorder = 2;
            sHeight = 12;

            //texts styles
            size1 = "12px";
            size2 = "12px";
            size1r = "14px";
            size2r = "14px";

            //axis styles
            yMargin = null;
            labelMargin = 10; 
        }

        if($('#'+inDiv).width()<=450)
        {
            //axis styles
            rotation = -45;
        }
        else
        {
            //axis styles
            rotation = 0;                
        }

        var aData = dataChart[0];
        var aYears = new Array();
        $.each(dataChart[1], function(index,indYear)
            {
                aYears.push(indYear);        
        });    
        var sCurrency = dataChart[2];

        //Define the initial, basic options.
        var options = {

            chart: {
                renderTo : inDiv,
                backgroundColor : '#EEEEEE',  
                alignThresholds: true,
                spacingBottom: sBottom,
                marginBottom : mBottom,
                spacingTop : sTop,
                marginTop : mTop,
                spacingLeft: sLeft,
                spacingRight: sRight,
                alignTicks:false
            },

            exporting : {
                enabled : false
            },

            title : { 
                text : nomSoc,
                align : 'left',
                style :{
                    fontSize : size1,                           
                    fontWeight: 'bold',
                    color : '#6e6e6e'
                },
                x : xTitle  
            },

            legend : {
                backgroundColor: 'white',
                borderWidth: lBorder,
                borderRadius: 3,
                itemStyle: {
                    fontSize : size2
                },
                symbolHeight: sHeight
            },

            credits : {
                enabled : true,
                href : null,
                text : '\u00A9'+aWords[0]+' - S&P Global Market Intelligence',
                style : {
                    fontSize : size2
                } 
            },

            loading: {
                hideDuration : 250,
                style : {
                    backgroundColor : 'gray'
                },
                labelStyle : {
                    color : 'white',
                    top: '45%'
                }
            },
            
            responsive: {
                rules : [{
                    chartOptions: {
                        legend : {
                            itemStyle :{
                                fontSize : size2r
                            }
                        },  
                        tooltip: {
                            headerFormat: '<span style="font-size:14px;">'+aWords[3]+' : <b>{point.key}</b></span><br><table style="min-width:250px;font-size:14px;">',
                        },
                        xAxis: {
                            labels : {
                                style : {
                                    fontSize : size2r
                                }
                            }
                        },
                        yAxis: [{
                            labels : {
                                style : {
                                    fontSize : size1r
                                }
                            },
                            tickPixelInterval : 100,
                            title : {
                                style: {
                                    fontSize: size1r
                                }
                            }
                        },{
                            labels : {
                                style : {
                                    fontSize : size1r
                                }
                            }
                        }]    
                    },
                    condition: {
                        minHeight: 600,
                        minWidth: 800 
                    }
                }]
            },

            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                shared : true,
                headerFormat: '<span style="font-size:12px;">'+aWords[3]+' : <b>{point.key}</b></span><br><table style="min-width:150px;font-size:12px;">',
                footerFormat: '</table>',
                useHTML: true
            },

            xAxis : [{
                categories : aYears,
                opposite : true,
                gridLineDashStyle: 'Dot',
                gridLineWidth : 1,
                gridLineColor : '#A5A5A5',
                lineWidth : 2,
                lineColor : '#A5A5A5',
                tickWidth : 0,  
                labels : {  
                    style : {
                        fontWeight : 'bold',
                        fontSize: size2                            
                    },
                    y : -5,
                    rotation: rotation
                }
                },
                {
                    categories : aYears,
                    linkedTo : 0,             
                    gridLineWidth : 0,
                    lineWidth: 2,
                    lineColor : '#A5A5A5',
                    tickWidth : 2,
                    tickLength : 5,
                    tickColor : '#A5A5A5',
                    labels : {
                        enabled : false
                    }            
            }],

            yAxis : [{
                title : {
                    text : (sCurrency||''),
                    style : {
                        fontSize : size1,
                        fontWeight : 'bold',
                        color : "#434343"
                    },
                    margin: yMargin
                },
                alternateGridColor: "white",
                lineWidth: 2,
                lineColor : '#A5A5A5',
                tickWidth : 2,
                tickLength : 5,
                tickColor : '#A5A5A5',
                labels : {
                    style : {
                        fontWeight : 'bold',
                        fontSize: size2                            
                    },
                    x: -labelMargin
                }

                },
                {
                    lineWidth: 2,
                    lineColor : '#A5A5A5',
                    title : null,
                    opposite : true
            }],

            plotOptions: {
                column : {
                    borderWidth : 0,
                    pointPadding: 0.01,
                    shadow : true
                },
                series: {
                    animation: isAsync
                }      
            }

        };

        var chart = new Highcharts.Chart(options);

        if(isAsync)
            chart.showLoading();

        var seriesANPA = {
            type : 'column',
            yAxis : 0,
            color : '#7041A7',
            data : aData[0],
            name : aWords[1],
            id : 'anpa',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.2f}&nbsp;'+(sCurrency||'')+'</b></td></tr>'
            }                
        };

        var seriesCFPA = {
            type : 'column',
            yAxis : 0,
            color : '#FF3366',
            data : aData[1],
            name : aWords[2],
            id : 'cfpa',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.2f}&nbsp;'+(sCurrency||'')+'</b></td></tr>'
            }                
        };     

        chart.addSeries(seriesANPA,false,isAsync);
        chart.addSeries(seriesCFPA,true,isAsync);       //redraw chart only after the last series is added

        chart.hideLoading();

    });

}    


function drawGraphPER(codeZB,nomSoc,inDiv,aWords,isAsync,bIsMobile,iSkin,type)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    iSkin = (typeof iSkin === "undefined") ? SKIN_ZB : iSkin;

    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : type, iLang: iLang},
        type : 'GET'
    })
    .done(function(data){                      
        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
         
        var aData = dataChart[0];
        
        var aYears = dataChart[1];          
        
        var size1, size2, size1r, size2r, sHeight, rotation, sBottom, mBottom, sTop, mTop, sLeft, sRight, yMargin, labelMargin;

        if($('#'+inDiv).height()<=250)
        {
            //Chart styles
            sBottom = 15;
            mBottom = 20;
            sTop = 0;
            mTop = 30;
            sLeft = 0;
            sRight = 10;

            //Title styles
            xTitle = 10;

            //legend styles
            sHeight = 8;

            //texts styles
            size1 = "10px";
            size2 = "8px";
            size1r = "12px";
            size2r = "0px";

            //axis styles
            yMargin = 3;
            labelMargin = 6;
        }
        else
        {
            //Chart styles
            sBottom = 25;
            mBottom = null;
            sTop = 0;
            mTop = 50;
            sLeft = null;
            sRight = 20;

            //Title styles
            xTitle = 0;

            //legend styles
            sHeight = 12;

            //texts styles
            size1 = "12px";
            size2 = "12px";
            size1r = "14px";
            size2r = "14px";

            //axis styles
            yMargin = null;
            labelMargin = 10; 
        }                                                              

        //Define the initial, basic options.
        var options = {

            chart: {                          
                alignTicks:false,              
                alignThresholds: true,         
                animation: isAsync,
                backgroundColor : aMainStyle.backgroundColor,     
                marginTop : 55,         
                renderTo : inDiv,         
                spacingBottom: aMainStyle.spacingBottom,  
                spacingLeft: aMainStyle.spacingLeft,
                spacingRight: aMainStyle.spacingRight
            },

            credits : {
                enabled : true,                                                                                            
                href : null,
                position: {
                    align: aMainStyle.legendAlign,
                    x: 0
                },
                style : {
                    fontSize : aMainStyle.fontSize1               
                },
                text : '\u00A9'+aWords[0]+' - S&P Global Market Intelligence'
            },

            exporting : {
                enabled : false
            },

            legend : {
                enabled : false
            },   

            loading: {
                hideDuration : 250,
                labelStyle : {
                    color : 'white',
                    top: '45%'                             
                },
                style : {
                    backgroundColor : 'gray'
                }
            },

            plotOptions: {
                column : {
                    borderWidth : 0,
                    shadow : false,    
                },
                series: {
                    animation: isAsync
                }      
            },

            title : { 
                align : 'left',    
                style :{
                    color : '#6e6e6e',
                    fontSize : aMainStyle.fontSize1,                           
                    fontWeight: 'bold'
                },
                text : nomSoc, 
                x : 0     
            },   

            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                shared : true,
                headerFormat: '<span style="font-size:12px;">'+aWords[1]+' : <b>{point.key}</b></span><br><table style="min-width:150px;font-size:12px;">',
                footerFormat: '</table>',
                useHTML: true
            },
               
            responsive: {
                rules : [{
                    chartOptions: {
                        chart: {
                            style: {
                                fontFamily: "Arial, Helvetica",
                                fontSize: "16px"
                            }
                        }, 
                        legend : {
                            itemStyle :{
                                fontSize : size2r
                            }
                        },
                        plotOptions:
                        {
                            column: {
                                dataLabels: {
                                    style: {
                                        fontSize: "16px"
                                    }    
                                }   
                            }  
                        },  
                        tooltip: {
                            headerFormat: '<span style="font-size:14px;">'+aWords[1]+' : <b>{point.key}</b></span><br><table style="min-width:150px;font-size:14px;">',
                        },
                        xAxis: {
                            labels : {
                                style : {
                                    fontSize : size2r
                                }
                            }
                        },
                        yAxis: [{
                            labels : {
                                style : {
                                    fontSize : size1r
                                }
                            },
                            tickPixelInterval : 100,
                            title : {
                                style: {
                                    fontSize: size1r
                                }
                            },
                            plotLines: [{
                                id: "avPER",
                                label: {
                                    style: {
                                        fontSize: "20px"
                                    }
                                }
                            }]
                        }]    
                    },
                    condition: {
                        minHeight: 600,
                        minWidth: 800 
                    }
                }]
            }, 

            xAxis : [
            {
                categories : aYears,
                opposite : true,
                gridLineDashStyle: aMainStyle.xAxisgridLineDashStyle,
                gridLineWidth : aMainStyle.xAxisgridLineWidth,
                gridLineColor : aMainStyle.xAxisgridLineColor,
                lineWidth : aMainStyle.xAxisTopLineWidth,
                tickWidth : aMainStyle.xAxisTopTickWidth, 
                labels : {
                    style : {
                        color: aMainStyle.xAxisLabelColor,
                        fontSize: aMainStyle.fontSize1,
                        fontWeight: aMainStyle.xAxisLabelWeight                            
                    },
                    rotation : -90,
                    y : -5
                }
            },
            {
                categories : aYears,
                gridLineWidth : 0,
                lineColor : aMainStyle.xAxisBottomLineColor,
                lineWidth: aMainStyle.xAxisBottomLineWidth,          
                linkedTo : 0,          
                tickWidth : aMainStyle.xAxisBottomTickWidth,
                labels : {
                    enabled : false
                },
                zIndex: 4             
            }
            ],

            yAxis : [
            {
                gridLineWidth : 0,
                labels : {
                    align: "right",
                    format: '{value}'+aWords[4],
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                    x: -5 
                },
                lineColor : aMainStyle.yAxisLeftLineColor, 
                lineWidth: aMainStyle.yAxisLeftLineWidth,    
                plotLines: [{ 
                    id: "avPER",
                    label: {
                        style: {
                            color: "#C155FF",
                            fontWeight: "bold"
                        },
                        text: ""
                    },
                    value: 0
                }],     
                tickPixelInterval : 40,    
                tickWidth : aMainStyle.yAxisLeftTickWidth,   
                title : {
                    style: {
                        fontSize: aMainStyle.fontSize1,
                        color: aMainStyle.yAxisLabelColor
                    },
                    text : aWords[2]
                },
                type: "logarithmic" 
            }
            ]
        };

        var chart = new Highcharts.Chart(options);

        if(isAsync)
            chart.showLoading();

        var seriesPER = {
            type : 'column',
            yAxis : 0,
            color : "#898989",
            data : aData,
            name : aWords[2],
            id : 'per',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.2f}'+aWords[4]+'</b></td></tr>'
            }                      
        };   

        chart.addSeries(seriesPER,true,isAsync);
        
        var moyenne = 0;
        var count = 0;
        var nbHisto = 0;
        
        $.each(aYears,function(index,value){
            if(value.indexOf('e')==-1)
            {
                if(aData[index] && aData[index]['y']>0)
                {
                    moyenne += parseFloat(aData[index]['y']);
                    count++;
                }
                nbHisto++;
            }
        });
        moyenne = moyenne / count;
        
        var yToPixels = chart.yAxis[0].toPixels(moyenne);
        var catWidth = chart.plotBox.width / aYears.length;
       
        //line for average PER on the past years interval 
        chart.renderer.path(['M', chart.plotBox.x, yToPixels, 'L', catWidth*nbHisto+chart.plotBox.x-1, yToPixels])
        .attr({
            'stroke-width': 2,
            stroke: '#C155FF',
            zIndex: 5
        })
        .add();
        
        //completion of the average PER line on the estimated years
        chart.renderer.path(['M', catWidth*nbHisto+chart.plotBox.x+1, yToPixels, 'L', chart.plotBox.width+chart.plotBox.x, yToPixels])
        .attr({
            'stroke-width': 2,
            stroke: '#C155FF',
            'stroke-dasharray': "5, 5",
            zIndex: 5
        })
        .add();
                     
        chart.yAxis[0].update({
            plotLines: [{
                value: moyenne,
                id: "avPER",     
                label: { 
                    style: {
                        color: "#C155FF",
                        fontWeight: "bold",
                        textOutline: "rgba(255,255,255,.5)"
                    },
                    text: aWords[3].replace("%duree%",count)+" : "+moyenne.toFixed(1)+aWords[4]
                },       
                zIndex: 3
            }]    
        });           

        chart.hideLoading();  

    });   
}


function drawGraphBnaDiv(codeZB,nomSoc,inDiv,aWords,isAsync,bIsMobile)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;

    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : 'bnadiv', iLang: iLang},
        type : 'GET'
    })
    .done(function(data){

        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }  
        var aData = dataChart[0];
        var aYears = new Array();
        $.each(dataChart[1], function(index,indYear)
            {
                aYears.push(indYear);        
        });
        var sCurrency = dataChart[2];

        var size1, size2, size1r, size2r, lBorder, sHeight, rotation, sBottom, mBottom, sTop, mTop, sLeft, sRight, yMargin, labelMargin;

        if($('#'+inDiv).height()<=250)
        {
            //Chart styles
            sBottom = 15;
            mBottom = 55;
            sTop = 0;
            mTop = 30;
            sLeft = 0;
            sRight = 0;

            //Title styles
            xTitle = 10;

            //legend styles
            lBorder = 1;
            sHeight = 8;

            //texts styles
            size1 = "10px";
            size2 = "8px";
            size1r = "12px";
            size2r = "10px";

            //axis styles
            yMargin = 8;
            labelMargin = 6;
        }
        else
        {
            //Chart styles
            sBottom = 25;
            mBottom = null;
            sTop = 0;
            mTop = 50;
            sLeft = null;
            sRight = 0;

            //Title styles
            xTitle = 0;

            //legend styles
            lBorder = 2;
            sHeight = 12;

            //texts styles
            size1 = "12px";
            size2 = "12px";
            size1r = "14px";
            size2r = "14px";

            //axis styles
            yMargin = 10;
            labelMargin = 10;
        }
        
        aSkinOptions = {
            greenCol : '#5AB400',
            lightGreenCol: "#76FF03",
            darkBrownLin: "#666666",
            margins: [mTop,mBottom],
            spacings: [sTop,sBottom]
        };                                                              

        //Define the initial, basic options.
        var options = {
            chart: {
                alignThresholds: true,
                alignTicks:false,
                backgroundColor : aMainStyle.backgroundColor,           
                marginBottom : aSkinOptions.margins[1],
                marginTop : aSkinOptions.margins[0],      
                renderTo : inDiv,       
                spacingBottom: aMainStyle.spacingBottom,        
                spacingLeft: aMainStyle.spacingLeft,
                spacingRight: aMainStyle.spacingRight, 
                spacingTop : aSkinOptions.spacings[0]  
            },

            credits : {
                enabled : true,                                                                                            
                href : null,
                position: {
                    align: aMainStyle.legendAlign,
                    x: 0
                },
                style : {
                    fontSize : aMainStyle.fontSize1               
                },
                text : '\u00A9'+aWords[0]+' - S&P Global Market Intelligence' 
            },

            exporting : {
                enabled : false
            },

            legend : {
                borderWidth : 0,
                itemStyle :{
                    fontSize : aMainStyle.fontSize1,
                    fontWeight: "normal"
                },
                margin: aMainStyle.legendMargin,
                symbolHeight : aMainStyle.symbolHeight
            },            

            loading: {
                hideDuration : 250,
                style : {
                    backgroundColor : 'gray'
                },
                labelStyle : {
                    color : 'white',
                    top: '45%'                             
                }
            },

            plotOptions: {
                column : {
                    borderWidth : 0,
                    pointPadding: 0.01,
                    shadow : false
                },
                line : {
                    marker : {
                        fillColor: 'black',    
                        radius: 3,
                        symbol: "circle"                     
                    },
                    shadow : true,
                },
                series: {
                    animation: isAsync
                }       
            },
            
            responsive: {
                rules : [{
                    chartOptions: {
                        chart:{
                            spacingBottom: aMainStyle.spacingBottom-3        
                        },
                        legend : {
                            margin: aMainStyle.legendMargin-3
                        }    
                    },
                    condition: {
                        maxHeight: 350 
                    }
                }]
            },
            
            title : {           
                align : 'left',
                style :{
                    color : '#6e6e6e',
                    fontSize : aMainStyle.fontSize1,                           
                    fontWeight: 'bold'
                },
                text : nomSoc,
                x : 0
            }, 

            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                shared : true,
                headerFormat: '<span style="font-size:12px;">'+aWords[4]+' : <b>{point.key}</b></span><br><table style="min-width:150px;font-size:12px;">',
                footerFormat: '</table>',
                useHTML: true
            },

            xAxis : [
            {
                categories : aYears,
                opposite : true,
                gridLineDashStyle: aMainStyle.xAxisgridLineDashStyle,
                gridLineWidth : aMainStyle.xAxisgridLineWidth,
                gridLineColor : aMainStyle.xAxisgridLineColor,
                lineWidth : aMainStyle.xAxisTopLineWidth,
                tickWidth : aMainStyle.xAxisTopTickWidth, 
                labels : {
                    style : {
                        color: aMainStyle.xAxisLabelColor,
                        fontSize: aMainStyle.fontSize1,
                        fontWeight: aMainStyle.xAxisLabelWeight                            
                    },
                    rotation : -45,
                    y : -5
                }
            },
            {
                categories : aYears,
                gridLineWidth : 0,
                lineColor : aMainStyle.xAxisBottomLineColor,
                lineWidth: aMainStyle.xAxisBottomLineWidth,          
                linkedTo : 0,          
                tickWidth : aMainStyle.xAxisBottomTickWidth,
                labels : {
                    enabled : false
                },
                zIndex: 4             
            }
            ],

            yAxis : [
            {
                gridLineWidth : 0,      
                labels: {         
                    align: "right",
                    formatter: function(){
                        if(Math.abs(this.value)<10)
                            return Highcharts.numberFormat(this.value,2);
                        else if(this.value<100)
                            return Highcharts.numberFormat(this.value,1);
                        else
                            return Highcharts.numberFormat(this.value);
                    },
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                    x: -5 
                },
                lineColor : aMainStyle.yAxisLeftLineColor,
                lineWidth: aMainStyle.yAxisLeftLineWidth,   
                tickWidth : aMainStyle.yAxisLeftTickWidth,  
                title: {
                    style: {
                        fontSize: aMainStyle.fontSize1,
                        color: aMainStyle.yAxisLabelColor
                    },
                    text: aWords[1]+" "+(sCurrency||'')
                }                                      
            },
            {
                gridLineWidth : 0,
                labels :{         
                    align: "left", 
                    format: '{value:.0f}%',
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                    x : 5
                },
                lineWidth: aMainStyle.yAxisRightLineWidth,   
                opposite : true,  
                tickWidth : aMainStyle.yAxisRightTickWidth,
                title : {
                    text : null
                }                            
            }] 
        };

        var chart = new Highcharts.Chart(options);

        if(isAsync)
            chart.showLoading();
        
      
        var seriesBNA = {
            type : 'column',
            yAxis : 0,
            color : aSkinOptions.greenCol,
            data : aData[0],
            name : aWords[2],
            id : 'bna',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.2f}&nbsp;'+(sCurrency||'')+'</b></td></tr>'
            }                
        };
            
        var seriesDiv = {
            type : 'column',
            yAxis : 0,
            color : aSkinOptions.lightGreenCol,
            data : aData[1],
            name : aWords[3],
            id : 'div',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.2f}&nbsp;'+(sCurrency||'')+'</b></td></tr>'
            }            
        };

        var seriesRVD = {
            type : 'line',
            yAxis : 1,
            color : aSkinOptions.darkBrownLin,
            data : aData[2],
            name : aWords[1],
            id : 'rvd',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.2f}&nbsp;%</b></td></tr>'
            }             
        };

        chart.addSeries(seriesBNA,false,isAsync);
        chart.addSeries(seriesDiv,false,isAsync);
        chart.addSeries(seriesRVD,true,isAsync);    //redraw chart after adding the last series

        chart.hideLoading(); 
    }); 
}


function drawGraphAgenda(codeZB,nomSoc,inDiv,aWords,isAsync,bIsMobile,periode,subT)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    periode = (typeof periode === "undefined") ? "A" : periode;
    subT = (typeof subT === "undefined") ? "ca" : subT;

    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : 'taux_surprise', sub_t : subT, p : periode, iLang: iLang},
        type : 'GET'
    })
    .done(function(data){

        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }      
        var aData = dataChart[0];
        var aYears = new Array();
        $.each(dataChart[1], function(index,indYear)
            {
                aYears.push(indYear);        
        });
        var sCurrency = dataChart[2];
        var iNbDec = (subT == "bna") ? 2 : 0;
        var sScale = (subT == "bna") ? "" : "&nbsp;M";

        var size1, size2, size1r, size2r, lBorder, sHeight, rotation, sBottom, mBottom, sTop, mTop, sLeft, sRight, yMargin, labelMargin;
        var redrawing = false;

        if($('#'+inDiv).height()<=250)
        {
            //Chart styles
            sBottom = 15;
            mBottom = 45;
            sTop = 0;
            mTop = 45;
            sLeft = 0;
            sRight = 10;

            //Title styles
            xTitle = 10;
                             
            //legend styles
            lBorder = 1;
            sHeight = 8;

            //texts styles
            size1 = "10px";
            size2 = "8px";
            sizeScatter = "8px";
            size1r = "12px";
            size2r = "10px";

            //axis styles
            yMargin = 8;
            labelMargin = 6;
        }
        else
        {
            //Chart styles
            sBottom = 25;
            mBottom = null;
            sTop = 0;
            mTop = 45;
            sLeft = null;
            sRight = 20;

            //Title styles
            xTitle = 0;

            //legend styles
            lBorder = 2;
            sHeight = 12;

            //texts styles
            size1 = "12px";
            size2 = "12px";
            sizeScatter = "10px";
            size1r = "14px";
            size2r = "14px";

            //axis styles
            yMargin = null;
            labelMargin = 10; 
        }
       
        {
            aSkinOptions = {
                chartStyleColor: "black",
                backgroundColor: 'white',
                legendBorderWidth: 0,
                tickmarckPosition : "between",
                pointPosition: "on",
                estimatesColor: '#999999',
                realColor: '#333333',
                xAxisLabelOpposite: true,
                xAxisGridWidth: 1,
                xAxisLabelY: -5,
                xAxisTick: 0,
                secondXAxisVisibility: false,
                yAxisTickWidth: 0,
                yAxisLineWidth: 2,
                yAxisLabelAlign: null,
                yAxisLabelY: null,
                yAxisLabelX: labelMargin,
                yAxisTitle: aWords[1]+" "+(sCurrency||''),
                secondYAxisVisibility: false,
                axisColor: "black",
                columnShadow: false,
                columnMaxWidth: null,
                redrawFunction: null,
                tooltipBGColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                tooltipBorderColor: 'gray',
                tooltipTextColor: null,
                tooltipBorderWidth: 1,
                tooltipBorderRadius: 5,
                scatterLabelsY: -18,
                scatterLabelsYr: -14,
                creditColor: "black"
            };    
        }                                                               

        (function(H) {
            H.wrap(H.seriesTypes.bubble.prototype, 'alignDataLabel', function(p, point, dataLabel, options, alignTo, isNew) {            
                alignTo = alignTo || {x: 0, y: 0, width: 0, height: 0};   
                alignTo.x = point.plotX - dataLabel.padding;
                alignTo.y = point.plotY;
                alignTo.width = dataLabel.width;
                           
                H.Series.prototype.alignDataLabel.call(this, point, dataLabel, options, alignTo, isNew);
            });
        }(Highcharts))
        //Define the initial, basic options.
        var options = {
            chart: {
                animation: isAsync,  
                backgroundColor : aMainStyle.backgroundColor,  
                marginBottom : mBottom,
                marginTop : mTop,   
                renderTo : inDiv,   
                spacingBottom: aMainStyle.spacingBottom,   
                spacingLeft: aMainStyle.spacingLeft,
                spacingRight: aMainStyle.spacingRight, 
                spacingTop : sTop,
            },   

            credits : {
                enabled : true,                                                                                            
                href : null,
                position: {
                    align: aMainStyle.legendAlign,
                    x: 0
                },
                style : {
                    fontSize : aMainStyle.fontSize1               
                },
                text : '\u00A9'+aWords[0]+' - S&P Global Market Intelligence' 
            },

            exporting : {
                enabled : false
            },

            legend : {
                borderWidth : 0,
                itemStyle :{
                    fontSize : aMainStyle.fontSize1,
                    fontWeight: "normal"
                },
                symbolHeight : aMainStyle.symbolHeight
            },       

            loading: {
                hideDuration : 250,
                style : {
                    backgroundColor : 'gray'
                },
                labelStyle : {
                    color : 'white',
                    top: '45%'                             
                }
            },  
            
            plotOptions: {
                column : {
                    borderWidth : 0,
                    pointPadding: 0.01,
                    shadow : false
                },
                series: {
                    animation: isAsync,
                    tooltip : {
                        pointFormat : '<tr><td style="height: auto; padding:0px;">{series.name}: </td><td style="height: auto; padding:0px;text-align : right;"><b>{point.y:.'+iNbDec+'f}'+sScale+'&nbsp;'+(sCurrency||'')+'</b></td></tr>'
                    } 
                },
                scatter: {
                    dataLabels: { 
                        allowOverlap: true,                   
                        crop: false,       
                        overflow: "none",
                        align: 'left',          
                        y: aSkinOptions.scatterLabelsY,
                        enabled: true,
                        style: {
                            'text-anchor': 'middle',
                            color : aSkinOptions.chartStyleColor,
                            fontSize: sizeScatter
                        },
                        padding: 0
                    }
                }
            },    
            
            responsive: {
                rules : [{
                    chartOptions: {
                        chart:{
                            spacingRight: periode=="Q" ? aMainStyle.spacingRight+25 : aMainStyle.spacingRight+15
                        },

                        xAxis : [
                        {
                            labels: {
                                rotation: -45
                            }
                        }]    
                    },
                    condition: {
                        maxWidth: 380 
                    }
                },
                {
                    chartOptions: {
                        chart:{
                            spacingBottom: aMainStyle.spacingBottom-3        
                        },
                        legend : {
                            margin: aMainStyle.legendMargin-3
                        },
                        yAxis : [
                        {
                            maxPadding: 0.11,
                            tickPixelInterval: 40
                        }]    
                    },
                    condition: {
                        maxHeight: 430 
                    }    
                }]
            },

            title : {           
                align : 'left',
                style :{
                    color : '#6e6e6e',
                    fontSize : aMainStyle.fontSize1,                           
                    fontWeight: 'bold'
                },
                text : nomSoc,
                x : 0
            }, 

            tooltip: {     
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                style: {
                    color: null
                },
                shared : true,
                headerFormat: '<table style="min-width:150px;font-size:12px;"><tr><td style="padding-bottom: 5px;">'+aWords[4]+' : </td><td style="text-align: right;padding-bottom: 5px;"><b>{point.key}</b></td></tr>',
                footerFormat: '</table>',
                useHTML: true
            },

            xAxis : [
            {
                categories : aYears,   
                gridLineColor : aMainStyle.xAxisgridLineColor, 
                gridLineDashStyle: aMainStyle.xAxisgridLineDashStyle,
                gridLineWidth : aMainStyle.xAxisgridLineWidth,   
                labels : {
                    autoRotation : [0, -45],
                    style : {
                        color: aMainStyle.xAxisLabelColor,
                        fontSize: aMainStyle.fontSize1,
                        fontWeight: aMainStyle.xAxisLabelWeight                            
                    },
                    y : -5
                },
                lineWidth : aMainStyle.xAxisTopLineWidth,
                opposite : true, 
                tickWidth : aMainStyle.xAxisTopTickWidth,
                type : "category"
            },
            {
                categories : aYears,
                gridLineWidth : 0,
                labels : {
                    enabled : false
                },
                lineColor : aMainStyle.xAxisBottomLineColor,
                lineWidth: aMainStyle.xAxisBottomLineWidth,          
                linkedTo : 0,          
                tickWidth : aMainStyle.xAxisBottomTickWidth,
                type : "category",
                zIndex: 4             
            }
            ],

            yAxis : [
            {
                labels: {         
                    align: "right",
                    formatter: function () {
                        if(Math.abs(this.value)>=100)
                            return Highcharts.numberFormat(this.value,0);
                        else if(Math.abs(this.value)>=10)
                            return Highcharts.numberFormat(this.value,1);
                        else 
                            return Highcharts.numberFormat(this.value,2);
                    },
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                    x: -5 
                },
                lineColor : aMainStyle.yAxisLeftLineColor,
                lineWidth: aMainStyle.yAxisLeftLineWidth,  
                tickWidth : aMainStyle.yAxisLeftTickWidth,  
                title: {
                    style: {
                        fontSize: aMainStyle.fontSize1,
                        color: aMainStyle.yAxisLabelColor
                    },
                    text: aWords[1]+" "+(sCurrency||'')
                }                                      
            }
            ],            
            
            series: [{
                type : 'column',
                yAxis : 0,
                color : aSkinOptions.realColor,
                data : aData[1],
                name : aWords[3],
                id : 'car'
            },{
                type : 'column',
                yAxis : 0,
                color : {
                    pattern: {
                        "path": 'M 0 5 L 5 0 M -0.5 0.5 L 0.5 -0.5 M 4.5 5.5 L 5.5 4.5',
                        "color": "#999999", 
                        "width": 5,
                        "height": 5
                    }
                },
                data : aData[0],
                name : aWords[2],
                id : 'cae'          
            },{
                type : 'scatter',
                yAxis : 0,
                showInLegend : false,
                enableMouseTracking: false ,
                data : aData[2],
                name : 'Surprise',
                id : 'surpr'          
            }]
        };          

        var chart = new Highcharts.Chart(options);    
    });
}   


function drawGraphRevision(codeZB,nomSoc,t,sub_t,inDiv,aWords,isAsync,bIsMobile)
{
    //Retrieve language
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;

    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : t , sub_t : sub_t},
        type : 'GET'
    })
    .done(function(data){
        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
        var aData = dataChart[0];
        var aYears = dataChart[1];
        var sCurrency = dataChart[2];
        var rightTitle = dataChart[3];
                    
        if(sCurrency)
        {
            if(dataChart[4]&&(dataChart[4].toLowerCase()!='u'))
                rightTitle += '('+dataChart[4]+' '+sCurrency+')';
            else
                rightTitle += '('+sCurrency+')';
        }                     
        
        var size1, size2, size1r, size2r, lBorder, sHeight, legendWidth, legendItemWidth, xLengend, yLegend, rotation, sBottom, mBottom, sTop, mTop, sLeft, sRight, yMargin, labelMargin, markerSize;

        if($('#'+inDiv).height()<=250)
        {
            //Chart styles
            sBottom = 0;
            mBottom = 60;
            sTop = 0;
            mTop = 45;
            sLeft = 0;
            sRight = 5;

            //Title styles
            xTitle = 10;

            //legend styles
            lBorder = 1;
            sHeight = 8;
            legendWidth = 400;
            legendWidthR = 800;
            legendItemWidth = 200;
            legendItemWidthR = 250;
            xLegend = 10;

            //texts styles
            size1 = "10px";
            size2 = "8px";
            size1r = "12px";
            size2r = "10px";

            //axis styles
            yMargin = 8;
            labelMargin = 6;
            
            //marker style
            markerSize = 2;
        }
        else
        {
            //Chart styles
            sBottom = 5;
            mBottom = 80;
            sTop = 0;
            mTop = 65;
            sLeft = null;
            sRight = null;              

            //Title styles
            xTitle = 0;

            //legend styles
            lBorder = 2;
            sHeight = 12;
            legendWidth = 600;
            legendWidthR = 800;
            legendItemWidth = 300;
            legendItemWidthR = 400;
            xLegend = 50;

            //texts styles
            size1 = "12px";
            size2 = "12px";
            size1r = "14px";
            size2r = "14px";

            //axis styles
            yMargin = null;
            labelMargin = 10;
            
            //marker style
            markerSize = 4; 
        } 
        
        if(iLang==3)
        {
            legendWidth += 40;    
            legendItemWidth += 20;    
        }                                                                 
        
        var iNbDec = (sub_t=="bna"||t=="evobjcourt") ? 2 : 0;       
                        
        var sTooltipSuffix = "";
        if(dataChart[4]&&(dataChart[4].toLowerCase()!='u'))
            sTooltipSuffix += '&nbsp;'+dataChart[4];
        if(sCurrency)
            sTooltipSuffix += '&nbsp;'+sCurrency;

        //Define the initial, basic options.
        var options = 
        {
            chart: {
                backgroundColor : aMainStyle.backgroundColor,  
                marginTop : 50,     
                renderTo : inDiv, 
                spacingBottom: aMainStyle.spacingBottom,       
                spacingLeft: aMainStyle.spacingLeft,
                spacingRight: aMainStyle.spacingRight
            },    

            credits : {
                enabled : true,                                                                                            
                href : null,
                position: {
                    align: aMainStyle.legendAlign,
                    x: 0
                },
                style : {
                    fontSize : aMainStyle.fontSize1               
                },
                text : '\u00A9Zonebourse - S&P Global Market Intelligence' 
            },

            exporting : {
                enabled : false
            }, 

            legend : {
                borderWidth : 0,
                itemStyle :{
                    fontSize : aMainStyle.fontSize1,
                    fontWeight: "normal"
                },
                margin: aMainStyle.legendMargin,
                symbolHeight: aMainStyle.symbolHeight 
            }, 

            loading: {
                hideDuration : 250,
                style : {
                    backgroundColor : 'gray'
                },
                labelStyle : {
                    color : 'white',
                    top: '45%'                             
                }
            },
            
            navigator:
            {
                enabled: false
            },

            plotOptions: { 
                arearange : { 
                    lineWidth: 1,  
                    tooltip : {
                        pointFormat : '<tr><td style="padding:0;">'+aWords[5]+': </td><td style="padding:0;text-align:right;"><b>{point.high:.'+(iNbDec)+'f}'+sTooltipSuffix+'</b></td></tr><tr><td style="padding:0;">'+aWords[7]+': </td><td style="padding:0;text-align:right;"><b>{point.low:.'+(iNbDec)+'f}'+sTooltipSuffix+'</b></td></tr>'
                    }
                },
                area : {
                    lineWidth: 0,
                    stacking: 'normal',
                    step: true,
                    tooltip : {
                        pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.0f}</b></td></tr>'
                    }
                },   
                line : {
                    marker : {
                        lineColor: 'white',
                        lineWidth: 1.5,
                        symbol: "circle",
                        radius : markerSize                     
                    },
                    tooltip : {
                        pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.'+(iNbDec)+'f}'+sTooltipSuffix+'</b></td></tr>'
                    }
                },
                series: {
                    animation: isAsync,
                    dataGrouping: {
                        dateTimeLabelFormats: {
                            day : [dateFormatDay],
                            week: [dateFormatWeek]
                        },
                        forced: true,
                        units: [["day",[1]]]
                    },
                    states: {
                        hover: {
                            lineWidthPlus: 0   
                        }
                    }
                }
            },    
            
            rangeSelector:
            {
                enabled: false
            },  
            
            responsive: {
                rules: [{
                    chartOptions: {
                        tooltip: {
                            headerFormat: '<span style="font-size:12px;">Periode : <b>{point.key}</b></span><br><table style="width:250px;font-size:12px;white-space:break-spaces;">',
                        }
                    },
                    condition: {
                        maxWidth: 400    
                    }
                }]    
            },   
            
            scrollbar:
            {
                enabled: false
            },

            title : { 
                text : nomSoc,
                align : 'left',
                style :{
                    fontSize : size1,                           
                    fontWeight: 'bold',
                    color : '#6e6e6e'
                },
                x : xTitle 
            },

            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5, 
                headerFormat: '<span style="font-size:12px;">Periode : <b>{point.key}</b></span><br><table style="min-width:150px;font-size:12px;white-space:nowrap;">',
                footerFormat: '</table>',
                shared : true,
                split: false,                           
                useHTML: true,
                xDateFormat: dateFormatDay
            },
            
            xAxis : [
            { 
                endOnTick: false,
                gridLineColor : aMainStyle.xAxisgridLineColor, 
                gridLineDashStyle: aMainStyle.xAxisgridLineDashStyle,
                gridLineWidth : aMainStyle.xAxisgridLineWidth,
                labels: {
                    formatter: function(){
                        return this.chart.time.dateFormat("%b %y",this.value);
                    },   
                    rotation: -45,
                    step: 1,
                    style : {
                        color: aMainStyle.xAxisLabelColor,
                        fontSize: aMainStyle.fontSize1,
                        fontWeight: aMainStyle.xAxisLabelWeight
                    },
                    y : -5
                },
                lineWidth : aMainStyle.xAxisTopLineWidth,
                max: aData[1][aData[1].length-1].x+30*24*3600*1000,
                opposite : true,  
                tickWidth : aMainStyle.xAxisTopTickWidth,                  
                type : 'datetime'
            },   
            {
                lineColor : aMainStyle.xAxisBottomLineColor,
                lineWidth: aMainStyle.xAxisBottomLineWidth, 
                title : null,
                zIndex: 5
            }],                                                         

            yAxis : [
            {
                gridLineColor : aMainStyle.yAxisgridLineColor, 
                gridLineDashStyle: aMainStyle.yAxisgridLineDashStyle,
                gridLineWidth : aMainStyle.yAxisgridLineWidth,
                height: "70%",
                labels: {  
                    align: "left",
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                    x: 5 
                },           
                lineColor : aMainStyle.yAxisLeftLineColor,
                lineWidth: aMainStyle.yAxisLeftLineWidth,
                maxPadding: 0.05,
                minPadding: 0.05, 
                opposite : true,   
                resize: {
                    enabled: true,
                    lineColor: "black",
                    lineDashStyle:"Dash",
                    lineWidth: 1
                },  
                showFirstLabel: false,
                title : {
                    text : rightTitle,
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                },
                zIndex: 5           
            },
            {
                allowDecimals : false,
                endOnTick: false,
                gridLineColor : aMainStyle.yAxisgridLineColor, 
                gridLineDashStyle: aMainStyle.yAxisgridLineDashStyle,
                gridLineWidth : aMainStyle.yAxisgridLineWidth,
                height: "30%",
                labels: {  
                    align: "left",
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                    x: 5 
                },
                lineColor : aMainStyle.yAxisLeftLineColor,
                lineWidth: aMainStyle.yAxisLeftLineWidth,  
                maxPadding: 0.05, 
                offset: 0,    
                opposite : true,  
                tickWidth : aMainStyle.yAxisLeftTickWidth,
                title : {
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                    text : aWords[1]
                }, 
                top: "70%",
                zIndex: 5                                 
            }]
        };  

        var chart = new Highcharts.chart(options);

        if(isAsync)
            chart.showLoading(); 
         
        var lastData = aData[1][aData[1].length - 1];
        lastData = {
            x: lastData.x,
            y: lastData.y,
            dataLabels : {
                format : '{y:.2f}', 
                enabled : true,
                style : {
                    fontWeight : 'bold', 
                    color : 'black'
                },
                y : -2    
            }
        };
        aData[1][aData[1].length - 1] = lastData;
        
        switch(t)
        {
            case "evobjcourt" :
                seriesColor = "#C155FF";
                break;
            
            case "eec" :               
                seriesColor = (sub_t=="bna") ? "#004000" : "#187faf";
                break;   
            
            case "es" :               
                seriesColor = (sub_t=="bna") ? "#00A000" : "#16a8ec";
                break;  
                
            default:
                seriesColor = "black";
                break; 
        };
        
        var seriesValMoyenne = {
            type : 'line',
            yAxis : 0,                  
            data : aData[1],
            name : aWords[6],
            id : 'valmy',
            color : seriesColor,
            legendIndex: 4,
            lineWidth: 2,
            zIndex: 4, 
        }; 
        
        dataRange = [];
        
        $.each(aData[2],function(index,val){
            dataRange[index] = [val.x,val.y]; 
        });
        
        $.each(aData[0],function(index,val){
            dataRange[index][2] = val.y; 
        });  
        
        var seriesValRange = {
            data : dataRange,
            fillColor: "rgba(222,254,254,0.5)",
            lineColor: "#7c7c7c",
            linkedTo : "valmy", 
            type: 'arearange',
            yAxis : 0,
            zIndex: 3  
        };   
        
        var seriesEstHt = {
            type : 'area',
            yAxis : 1,                  
            data : aData[3],
            name : aWords[4],
            id : 'estRevHt',   
            color : '#2CD254',
            legendIndex: 1                   
        };

        var seriesEstStable = {
            type : 'area',
            yAxis : 1,                  
            data : aData[4],
            name : aWords[3],
            id : 'estStable',  
            color : 'rgba(214,214,214,0.75)'
            ,
            legendIndex: 2                   
        };

        var seriesEstBs = {
            type : 'area',
            yAxis : 1,                  
            data : aData[5],
            name : aWords[2],
            id : 'estRevBs', 
            color : '#FF0000',
            legendIndex: 3                            
        };                   

        chart.addSeries(seriesEstHt,false,isAsync);
        chart.addSeries(seriesEstStable,false,isAsync);
        chart.addSeries(seriesEstBs,false,isAsync);
        chart.addSeries(seriesValMoyenne,false,isAsync);     
        chart.addSeries(seriesValRange,true,isAsync);     //redraw chart after adding the last series    

        chart.hideLoading();

    });      
}


function drawGraphMiniRevision(codeZB,nomSoc,t,sub_t,inDiv,aWords,isAsync,bIsMobile)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    
    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : t , sub_t : sub_t, iLang: iLang},
        type : 'GET'
    })
    .done(function(data){

        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
        var aData = dataChart[0];  
        var sCurrency = dataChart[1];
        var sSeriesName = dataChart[2];
        
        //exc�ption pour limiter taille text dans Highchart (abr�v. peu courrante en allemand)   
        sSeriesName = jQuery.map(sSeriesName, function(name){return name.replace("Gewinn pro Aktie","GpA");}); 
        
        //Define the initial, basic options.
        var options = {

            chart: {
                backgroundColor : aMainStyle.backgroundColor, 
                marginTop : 50,   
                renderTo : inDiv,
                spacingBottom: 25,
                spacingLeft: aMainStyle.spacingLeft,
                spacingRight: aMainStyle.spacingRight   
            }, 

            credits : {
                enabled : true,                                                                                            
                href : null,
                position: {
                    align: aMainStyle.legendAlign,
                    x: 0
                },
                style : {
                    fontSize : aMainStyle.fontSize1               
                },
                text : '\u00A9'+aWords[0]+' - S&P Global Market Intelligence' 
            },

            exporting : {
                enabled : false
            }, 

            legend : {         
                borderWidth : 0,
                enabled: true,
                itemStyle :{
                    fontSize : aMainStyle.fontSize1,
                    fontWeight: "normal"
                },
                margin: aMainStyle.legendMargin,
                symbolHeight : aMainStyle.symbolHeight
            },  

            loading: {
                hideDuration : 250,
                style : {
                    backgroundColor : 'gray'
                },
                labelStyle : {
                    color : 'white',
                    top: '45%'                             
                }
            },
            
            navigator:
            {
                enabled: false
            },

            plotOptions: {
                line : {
                    marker : {
                        fillColor : "#636363",
                        lineColor: 'white',
                        lineWidth: 1.5,
                        symbol: "circle"                     
                    }
                },
                series: {
                    animation: isAsync,
                    dataGrouping: {
                        dateTimeLabelFormats: {
                            day : [dateFormatDay],
                            week: [dateFormatWeek]
                        },
                        forced: true,
                        units: [["day",[1]],["month",[1]]]
                    }
                }
            },
            
            rangeSelector:
            {
                enabled: false
            },  
            
            responsive: {
                rules : [{
                    chartOptions: {
                        chart:{
                            marginTop: 25
                        },
                        xAxis : [
                        {
                            showFirstLabel: false,
                            labels: {
                                rotation: 0
                            }
                        }]    
                    },
                    condition: {
                        minWidth: 400 
                    }
                },
                {
                    chartOptions: {
                        chart:{
                            spacingBottom: aMainStyle.spacingBottom-3        
                        },
                        legend : {
                            margin: aMainStyle.legendMargin-3
                        },
                        yAxis: [{          
                            tickPixelInterval : 30    
                        }]    
                    },
                    condition: {
                        maxHeight: 350 
                    }
                }]    
            },             
            
            scrollbar:
            {
                enabled: false
            },

            title : {           
                align : 'left',
                style :{
                    color : '#6e6e6e',
                    fontSize : aMainStyle.fontSize1,                           
                    fontWeight: 'bold'
                },
                text : nomSoc,
                x : 0
            }, 

            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                shared : true,
                split: false,
                headerFormat: '<span style="font-size:12px;">'+aWords[2]+' : <b>{point.key}</b></span><br><table style="min-width:150px;font-size:12px;width:100%;">',
                footerFormat: '</table>',
                useHTML: true
            },

            xAxis : [
            {
                showFirstLabel : true,
                gridLineColor : aMainStyle.xAxisgridLineColor, 
                gridLineDashStyle: aMainStyle.xAxisgridLineDashStyle,
                gridLineWidth : aMainStyle.xAxisgridLineWidth,
                labels: {
                    rotation : -45,
                    step: 1,
                    style : {
                        color: aMainStyle.xAxisLabelColor,
                        fontSize: "12px",
                        fontWeight: "bold"
                    },
                    y : -5
                },
                lineColor : aMainStyle.xAxisTopLineColor,
                lineWidth: aMainStyle.xAxisTopLineWidth,       
                maxPadding: 0.1,
                opposite : true,
                ordinal: false,
                //units: [["month",[2]]], 
                tickWidth : 0
            },
            {
                lineColor : aMainStyle.xAxisBottomLineColor,
                lineWidth: aMainStyle.xAxisBottomLineWidth,
                title : null
            }
            ],

            yAxis : [
            {       
                gridLineColor : aMainStyle.yAxisgridLineColor, 
                gridLineDashStyle: aMainStyle.yAxisgridLineDashStyle,
                gridLineWidth : aMainStyle.xAxisgridLineWidth,           
                labels : {
                    align: "left",
                    style : {
                        color: "#818181"
                    },
                    x: 8,
                    y: 3
                },
                lineColor : aMainStyle.yAxisLeftLineColor,
                lineWidth: aMainStyle.yAxisLeftLineWidth,           
                showLastLabel:true,           
                tickWidth : 0, 
                title : {
                    text : sCurrency,
                    rotation : 270,
                    x : 10,
                    style : {
                        fontSize : "12px",
                        fontWeight : 'normal',
                        color: "#818181"
                    }
                }
            }]
        };

        var chart = new Highcharts.StockChart(options);

        if(isAsync)
            chart.showLoading();
        
        if(sub_t=="bna")
            aColor = ["#004000","#00A000","#00ff00"];
        else
            aColor = ["#187faf","#16a8ec","#6DE9FF"]; 


        var seriesActual = {
            type : 'line',                  
            data : aData[0],
            name : sSeriesName[0],
            id : 'dataAct', 
            color : aColor[0], 
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.2f}&nbsp;'+sCurrency+'</b></td></tr>'
            }                
        };

        var seriesEstimated = {
            type : 'line',                  
            data : aData[1],  
            name : sSeriesName[1],
            id : 'dataEst1', 
            color : aColor[1],
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.2f}&nbsp;'+sCurrency+'</b></td></tr>'
            }                
        }; 

        var seriesEstimated2 = {
            type : 'line',                  
            data : aData[2],  
            name : sSeriesName[2],
            id : 'dataEst2', 
            color : aColor[2],
            tooltip : {                                                                                                        
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.2f}&nbsp;'+sCurrency+'</b></td></tr>'
            }                
        };                  

        chart.addSeries(seriesActual,false,isAsync);
        chart.addSeries(seriesEstimated,false,isAsync);
        chart.addSeries(seriesEstimated2,true,isAsync);      //redraw chart after adding the last series

        chart.hideLoading();  
    });    
}


function drawGraphMiniRevisionCombine(codeZB,nomSoc,inDiv,aWords,isAsync,bIsMobile)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    
    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : 'rev' , sub_t : 'bna', iLang: iLang},
        type : 'GET'
    })
    .done(function(data){

        try{
            dataChart1 = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
        
        $.ajax({url : URL_SERVEUR+'afDataFeed.php',
            context : document.body,
            async : isAsync,
            data : {codeZB : codeZB, t : 'rev' , sub_t : 'ca'},
            type : 'GET'
        })
        .done(function(data){

            try{
                dataChart2 = JSON.parse(data)    
            } catch(e){
                $('#'+inDiv).css('display','none');
                console.log("erreur JSON parse : "+e);
                console.log("data received : "+data);
                return;
            }
            
            var aData1 = dataChart1[0];
            var aData2 = dataChart2[0];
            var sCurrency = dataChart1[1];
            var aSeriesName1 = dataChart1[2];
            var aSeriesName2 = dataChart2[2];
            
            //exc�ption pour limiter taille text dans Highchart (abr�v. peu courrante en allemand)   
            aSeriesName1 = jQuery.map(aSeriesName1, function(name){return name.replace("Gewinn pro Aktie","GpA");});
            
            //exc�ption pour limiter taille text dans Highchart (abr�v. peu courrante en allemand)   
            aSeriesName2 = jQuery.map(aSeriesName2, function(name){return name.replace("Gewinn pro Aktie","GpA");});
            
            var options = {

                chart: {
                    alignTicks:true,
                    backgroundColor : aMainStyle.backgroundColor, 
                    marginTop : 50,   
                    renderTo : inDiv,
                    spacingBottom: 25,
                    spacingLeft: aMainStyle.spacingLeft,
                    spacingRight: aMainStyle.spacingRight
                }, 

                credits : {
                    enabled : true,                                                                                            
                    href : null,
                    position: {
                        align: aMainStyle.legendAlign,
                        x: 0
                    },
                    style : {
                        fontSize : aMainStyle.fontSize1               
                    },
                    text : '\u00A9'+aWords[0]+' - S&P Global Market Intelligence' 
                }, 

                exporting : {
                    enabled : false
                }, 

                legend : {         
                    borderWidth : 0,
                    enabled: true,
                    itemStyle :{
                        fontSize : aMainStyle.fontSize1,
                        fontWeight: "normal"
                    },
                    margin: aMainStyle.legendMargin,
                    symbolHeight : aMainStyle.symbolHeight
                },

                loading: {
                    hideDuration : 250,
                    style : {
                        backgroundColor : 'gray'
                    },
                    labelStyle : {
                        color : 'white',
                        top: '45%'                             
                    }
                },
                
                navigator:
                {
                    enabled: false
                },

                plotOptions: {
                    line : {
                        marker : {
                            fillColor : "#636363",
                            lineColor: 'white',
                            lineWidth: 1.5,
                            symbol: "circle"                     
                        }
                    },
                    series: {
                        animation: isAsync,
                        dataGrouping: {
                            dateTimeLabelFormats: {
                                day : [dateFormatDay],
                                week: [dateFormatWeek]
                            },
                            forced: true,
                            units: [["day",[1]],["month",[1]]]
                        }
                    }
                },
                
                rangeSelector:
                {
                    enabled: false
                },

                responsive: {
                    rules : [{
                        chartOptions: {
                            xAxis : [
                            {
                                labels: {
                                    rotation: 0
                                }
                            }]    
                        },
                        condition: {
                            minWidth: 380 
                        }
                    },
                    {
                        chartOptions: {
                            chart:{
                                spacingBottom: aMainStyle.spacingBottom-3        
                            },
                            legend : {
                                margin: aMainStyle.legendMargin-3
                            },
                            yAxis: [{          
                                tickPixelInterval : 30    
                            }]    
                        },
                        condition: {
                            maxHeight: 350 
                        }
                    },
                    {
                        chartOptions: { 
                            legend : {
                                width: 250
                            }
                        },
                        condition: {
                            maxWidth: 400 
                        }
                    }]    
                }, 
                
                scrollbar:
                {
                    enabled: false
                },

                title : {           
                    align : 'left',
                    style :{
                        color : '#6e6e6e',
                        fontSize : aMainStyle.fontSize1,                           
                        fontWeight: 'bold'
                    },
                    text : nomSoc,
                    x : 0
                },

                tooltip: {
                    backgroundColor: {
                        linearGradient: {
                            x1: 0,
                            y1: 0,
                            x2: 0,
                            y2: 1
                        },
                        stops: [
                            [0, 'white'],
                            [1, '#EEE']
                        ]
                    },
                    borderColor: 'gray',
                    borderWidth: 1,
                    borderRadius: 5,
                    shared : true,
                    split: false,
                    headerFormat: '<span style="font-size:12px;">'+aWords[2]+' : <b>{point.key}</b></span><br><table style="min-width:150px;font-size:12px;">',
                    footerFormat: '</table>',
                    useHTML: true
                },

                xAxis : [
                {
                    gridLineColor : aMainStyle.xAxisgridLineColor, 
                    gridLineDashStyle: aMainStyle.xAxisgridLineDashStyle,
                    gridLineWidth : aMainStyle.xAxisgridLineWidth,
                    labels: {
                        rotation : -45,
                        step: 1,
                        style : {
                            fontSize: "12px",
                            fontWeight: "bold"
                        },
                        y : -5
                    },
                    lineColor : aMainStyle.xAxisTopLineColor,
                    lineWidth: aMainStyle.xAxisTopLineWidth,       
                    maxPadding: 0.1,
                    opposite : true,
                    ordinal: false,
                    units: [["month",[2]]], 
                    tickWidth : 0
                },
                {
                    lineColor : aMainStyle.xAxisBottomLineColor,
                    lineWidth: aMainStyle.xAxisBottomLineWidth,
                    title : null
                }
                ],

                yAxis : [
                {       
                    gridLineColor : aMainStyle.yAxisgridLineColor, 
                    gridLineDashStyle: aMainStyle.yAxisgridLineDashStyle,
                    gridLineWidth : aMainStyle.xAxisgridLineWidth,           
                    labels : {
                        align: "left",
                        style : {
                            color: "#818181"
                        },
                        x: 8,
                        y: 3
                    },
                    lineColor : aMainStyle.yAxisLeftLineColor,
                    lineWidth: aMainStyle.yAxisLeftLineWidth,           
                    showLastLabel:true,           
                    tickWidth : 0, 
                    title : {
                        text : aWords[1]+" "+sCurrency,
                        rotation : 270,
                        x : 10,
                        style : {
                            fontSize : "12px",
                            fontWeight : 'normal',
                            color: "#818181"
                        }
                    }
                },
                {        
                    gridLineWidth : 0,                                              
                    labels : {
                        align: "right",
                        style : {
                            color: "#818181"
                        },
                        x: -8,
                        y: 3
                    },
                    lineColor : aMainStyle.yAxisLeftLineColor,
                    lineWidth: aMainStyle.yAxisLeftLineWidth, 
                    opposite : false,         
                    showLastLabel:true,              
                    tickWidth : 0, 
                    title : {
                        text : aWords[2]+" "+sCurrency,
                        rotation : 270,
                        style : {
                            fontSize : "12px",
                            fontWeight : 'normal',
                            color: "#818181"
                        }
                    }
                }]
            };

            var chart = new Highcharts.StockChart(options);

            if(isAsync)
                chart.showLoading();

            var sFormat1 = '{point.y:.2f}&nbsp;'+sCurrency, //bna
                sFormat2 = '{point.y:.0f}&nbsp;M&nbsp;'+sCurrency; //ca

            var seriesActualBNA = {
                type : 'line',                  
                data : aData1[0],
                name : aSeriesName1[0],
                id : 'dataActBNA', 
                color : "#004000", 
                tooltip : {
                    pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>'+sFormat1+'</b></td></tr>'
                },
                yAxis: 0,
                legendIndex: 0                
            };

            var seriesEstimatedBNA = {
                type : 'line',                  
                data : aData1[1],  
                name : aSeriesName1[1],
                id : 'dataEstBNA', 
                color : "#00A000",
                tooltip : {
                    pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>'+sFormat1+'</b></td></tr>'
                },
                yAxis: 0,
                legendIndex: 2                
            };
            
            var seriesActualCA = {
                type : 'line',                  
                data : aData2[0],
                name : aSeriesName2[0],
                id : 'dataActCA', 
                color : "#187faf", 
                tooltip : {
                    pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>'+sFormat2+'</b></td></tr>'
                },
                yAxis: 1,
                legendIndex: 1                
            };

            var seriesEstimatedCA = {
                type : 'line',                  
                data : aData2[1],  
                name : aSeriesName2[1],
                id : 'dataEstCA', 
                color : "#16a8ec",
                tooltip : {
                    pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>'+sFormat2+'</b></td></tr>'
                },
                yAxis: 1,
                legendIndex: 3                
            };                  

            chart.addSeries(seriesActualBNA,false,isAsync);
            chart.addSeries(seriesEstimatedBNA,false,isAsync);
            chart.addSeries(seriesActualCA,false,isAsync);
            chart.addSeries(seriesEstimatedCA,true,isAsync);      //redraw chart after adding the last series

            chart.hideLoading();
        });
    });   
}


function drawGraphDetailAlanystes(codeZB,nomSoc,inDiv,aWords,isAsync,bIsMobile,iSkin)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    iSkin = (typeof iSkin == "undefined") ? SKIN_ZB : iSkin;

    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : 'dcons', iLang: iLang},
        type : 'GET'
    })
    .done(function(data){

        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        } 
        var aData = dataChart[0];
        var aYears = dataChart[1];                                                                 
        
        //Define the initial, basic options.
        var options = {

            chart: {
                backgroundColor : aMainStyle.backgroundColor,             
                marginBottom: 25,   
                marginTop : 8,       
                renderTo : inDiv,           
                spacingLeft : aMainStyle.spacingLeft,
                spacingRight: aMainStyle.spacingRight,       
                type: 'bar'
            },

            credits : {
                enabled : true,                                                                                            
                href : null,
                position: {
                    align: aMainStyle.legendAlign,
                    x: 0
                },
                style : {
                    fontSize : aMainStyle.fontSize1               
                },
                text : '\u00A9'+aWords[0]+' - S&P Global Market Intelligence' 
            },

            exporting : {
                enabled : false
            },       

            legend : {
                enabled: false
            },  

            loading: {
                hideDuration : 250,
                style : {
                    backgroundColor : 'gray'
                },
                labelStyle : {
                    color : 'white',
                    top: '45%'                             
                }
            },

            plotOptions: {
                bar : {
                    borderWidth : 0,
                    stacking: 'normal',
                    pointWidth: 19,
                    dataLabels: {
                        enabled: true,
                        color: 'black',
                        borderColor : "#c0c0c0",
                        borderWidth : 1,
                        backgroundColor  : "white",                    
                        style: {
                            fontSize: aMainStyle.fontSize1,    
                            fontWeight: 'bold',  
                        },
                        inside:true,
                        align : 'left',
                        x : 10,
                        useHTML: true,
                        formatter: function(){
                            return '<span style="text-align: center;">'+this.y+'</span>';
                        }
                    }
                },
                series: {
                    animation: isAsync
                }
            },  

            title : {           
                align : 'left',
                style :{
                    color : '#6e6e6e',
                    fontSize : aMainStyle.fontSize1,                           
                    fontWeight: 'bold'
                },
                text : nomSoc,
                x : 0
            }, 

            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                headerFormat: '<table style="font-size:12px;">',
                pointFormat: '<tr><td style="padding:0;">{point.name}: </td>' +
                '<td style="padding:0;"><b>{point.y}</b></td></tr>',
                footerFormat: '</table>',
                useHTML: true
            },

            xAxis : [{
                categories: aYears,
                gridLineDashStyle: aMainStyle.xAxisgridLineDashStyle,  
                gridLineWidth : aMainStyle.xAxisgridLineWidth,         
                lineColor : aMainStyle.xAxisBottomLineColor, 
                lineWidth: aMainStyle.xAxisBottomLineWidth,  
                tickWidth : 0,
                title : null,        
                labels: {
                    //enabled : false
                } ,
                zIndex: 4               
            }],

            yAxis : [{            
                gridLineWidth : 0,
                labels: {
                    enabled : false
                },
                lineColor : aMainStyle.yAxisLeftLineColor,
                lineWidth : aMainStyle.yAxisLeftLineWidth,   
                tickWidth : aMainStyle.yAxisLeftTickWidth,
                tickInterval : 1,
                title : null
            }]
        };


        var chart = new Highcharts.Chart(options);

        if(isAsync)
            chart.showLoading(); 

            

        var seriesOpinions = {
            name : "",
            id : "opinions",
            type : "bar",
            data : aData,     
        };
        
        chart.addSeries(seriesOpinions,true,isAsync);

        chart.hideLoading();

    });
}


function drawGraphEvolConsensus(codeZB,nomSoc,inDiv,aWords,isAsync,bIsMobile,iSkin)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    iSkin = (typeof iSkin == "undefined") ? SKIN_ZB : iSkin;

    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : 'evcons', iLang: iLang},
        type : 'GET'
    })
    .done(function(data){

        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }  
        var aData = dataChart[0];        
        var aYears = dataChart[1];   
        
        var size1, size1r;
        
        columnSizeR = 25;
        
        if(bIsMobile)
        {
            size1 = '10px';  
            size1r = '12px';  
        }
        else
        {
            size1 = '12px';  
            size1r = '14px';
        }
        
        aConsColor = ["#009900","#00CC00","#EEF200","#FFAE00","#FF0000","#434343"];

        //Define the initial, basic options.
        var options = {

            chart: {                
                backgroundColor : aMainStyle.backgroundColor, 
                marginTop : 60,
                spacingBottom: aMainStyle.spacingBottom,       
                spacingLeft: aMainStyle.spacingLeft,
                spacingRight: aMainStyle.spacingRight,
                renderTo : inDiv
            },

            credits : {
                enabled : true,                                                                                            
                href : null,
                position: {
                    align: aMainStyle.legendAlign,
                    x: 0
                },
                style : {
                    fontSize : aMainStyle.fontSize1               
                },
                text : '\u00A9'+aWords[0]+' - S&P Global Market Intelligence' 
            }, 

            exporting : {
                enabled : false
            },      

            legend : {
                borderWidth : 0,
                itemStyle :{
                    fontSize : aMainStyle.fontSize1,
                    fontWeight: "normal"
                },
                margin: aMainStyle.legendMargin,
                symbolHeight: aMainStyle.symbolHeight 
            },

            loading: {
                hideDuration : 250,
                style : {
                    backgroundColor : 'gray'
                },
                labelStyle : {
                    color : 'white',
                    top: '45%'                             
                }
            },
            
            navigator:
            {
                enabled: false
            },

            plotOptions: {
                area: {
                    lineWidth: 0,
                    step: true
                },
                series: {
                    animation: isAsync,
                    dataGrouping: {
                        dateTimeLabelFormats: {
                            day : [dateFormatDay],
                            week: [dateFormatWeek]
                        },
                        forced: true,
                        units: [["day",[1]]]
                    },
                    stacking: 'normal'
                }
            },
            
            rangeSelector:
            {
                enabled: false
            },     
            
            responsive: {
                rules : [{
                    chartOptions: {
                        xAxis : [
                        {
                            labels: {
                                rotation: -90
                            }
                        }]    
                    },
                    condition: {
                        maxWidth: 650 
                    }
                },
                {
                    chartOptions: {
                        chart:{
                            spacingBottom: aMainStyle.spacingBottom-3        
                        },
                        legend : {
                            margin: aMainStyle.legendMargin-3
                        }    
                    },
                    condition: {
                        maxHeight: 350 
                    }
                }]
            },    
            
            scrollbar: {
                enabled: false
            },

            title : {           
                align : 'left',
                style :{
                    color : '#6e6e6e',
                    fontSize : aMainStyle.fontSize1,                           
                    fontWeight: 'bold'
                },
                text : nomSoc,
                x : 0
            },   

            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                followPointer: true, 
                formatter: function(){
                    var sReturn = '<span style="font-size:12px;">'+aWords[8]+' : <b>'+this.points[0].point.t+'</b></span><br><table style="min-width:150px;">';
                      
                    $.each(this.points,function(index,point){
                        sReturn += '<tr><td style="padding:0;font-size:12px">'+point.series.name+': </td><td style="padding:0;font-size:12px; text-align : right;"><b>'+point.y.toFixed(0)+'</b></td></tr>';    
                    });
                    sReturn += '</table>';
                    return sReturn;
                },
                shared : true,
                split: false,                                                                                                                
                useHTML: true
            },

            xAxis : [
            {   
                categories: aYears,                    
                gridLineColor : aMainStyle.xAxisgridLineColor, 
                gridLineDashStyle: aMainStyle.xAxisgridLineDashStyle,
                gridLineWidth : aMainStyle.xAxisgridLineWidth,
                labels: { 
                    formatter: function(){
                        return this.chart.time.dateFormat("%b %y",Date.parse(this.value));
                    },
                    rotation: -45,
                    style : {
                        color: aMainStyle.xAxisLabelColor,
                        fontSize: aMainStyle.fontSize1,
                        fontWeight: aMainStyle.xAxisLabelWeight                            
                    },
                },          
                lineWidth : aMainStyle.xAxisTopLineWidth,
                opposite : true,     
                tickPositioner : function(){
                    var positions = [];
                    for(i =1; i<aYears.length; i++)
                    {
                        if(aYears[i-1].substr(5,2) != aYears[i].substr(5,2))
                        {
                            positions.push(i);
                        }
                    }
                    return positions;
                }, 
                tickWidth : aMainStyle.xAxisTopTickWidth,
                units: [["month",[1]]]
            },
            {
                categories : aYears,
                gridLineWidth : 0,
                labels : {
                    enabled : false
                },
                lineColor : aMainStyle.xAxisBottomLineColor,
                lineWidth: aMainStyle.xAxisBottomLineWidth,          
                linkedTo : 0,          
                tickWidth : aMainStyle.xAxisBottomTickWidth,
                zIndex: 4           
            }],

            yAxis : [
            {
                endOnTick: true,
                gridLineWidth : aMainStyle.yAxisLeftGridLineWidth,           
                labels : {
                    align: "right",
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                    x: -5 
                },                                                    
                lineColor : aMainStyle.yAxisLeftLineColor,
                lineWidth: aMainStyle.yAxisLeftLineWidth,
                maxPadding: 0.05,                      
                opposite : false,
                tickWidth : aMainStyle.yAxisLeftTickWidth,     
                title: {
                    style: {
                        fontSize: aMainStyle.fontSize1,
                        color: aMainStyle.yAxisLabelColor
                    },
                    text: aWords[1]
                },   
                showLastLabel: true, 
                zIndex: 5   
            }
            ]
        };           

        var chart = new Highcharts.chart(options);

        if(isAsync)
            chart.showLoading(); 
            
        for(i=2;i<=6;i++)
        {
            aWords[i] = aWords[i].toLowerCase();
            aWords[i] = aWords[i][0].toUpperCase() + aWords[i].slice(1);
        }

        var seriesAcheter = {
            name :  aWords[2],
            type : "area",
            data : aData[0],    
            color : aConsColor[0]            
        };

        var seriesAccumuler = {
            name :  aWords[3],
            type : "area",
            data : aData[1],  
            color : aConsColor[1]      
        };

        var seriesConserver = {
            name :  aWords[4],
            id : "conserver",
            type : "area",
            data : aData[2],  
            color : aConsColor[2]      
        };

        var seriesAlleger = {
            name :  aWords[5],
            id : "alleger",
            type : "area",
            data : aData[3], 
            color : aConsColor[3]        
        };

        var seriesVendre = {
            name :  aWords[6],
            id : "vendre",
            type : "area",
            data : aData[4],                                                                                     
            color : aConsColor[4]        
        };

        iSumSO = 0;
        for(i=0; i<aData[5].length; i++)
        {
            iSumSO += aData[5][i]["y"];
        }
        
        bHasSoSeries = false;
        if(iSumSO > 0)
        {
            var seriesSO = {
                name :  aWords[7],
                id : "so",
                type : "area",
                data : aData[5],   
                color : aConsColor[5]
            };
            bHasSoSeries = true;  
        } 

        chart.addSeries(seriesAcheter,false,isAsync);
        chart.addSeries(seriesAccumuler,false,isAsync);
        chart.addSeries(seriesConserver,false,isAsync);
        chart.addSeries(seriesAlleger,false,isAsync);
        chart.addSeries(seriesVendre,!bHasSoSeries,isAsync);
        
        if(bHasSoSeries)
            chart.addSeries(seriesSO,true,isAsync);         //redraw chart after adding the last series

        var maxY = chart.yAxis[0].max;
        var spacing = 5;  

        if(maxY < 10)
        {
            spacing = 1;        
        }
        else if(maxY < 20)
        {
            spacing = 2;
        }

        chart.yAxis[0].update({
            tickInterval : spacing
        });

        chart.hideLoading(); 

    });   
}


function drawGraphEvolObjMoy(codeZB,nomSoc,inDiv,aWords,isAsync,bIsMobile)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;      
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;      

    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : 'evobjmoyen', iLang: iLang},
        type : 'GET'
    })
    .done(function(data){
        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }                                
            
        var size1, size2, size1r, size2r, lBorder, sHeight, rotation, sBottom, mBottom, sTop, mTop, sLeft, sRight, yMargin, labelMargin;
        
        if($('#'+inDiv).height()<=300)
        {
            //Chart styles
            sBottom = 15;
            mBottom = 40;
            sTop = 0;
            mTop = 50;
            sLeft = 5;
            sRight = 30;

            //Title styles
            xTitle = 10;

            //legend styles
            lBorder = 1;
            sHeight = 8;

            //texts styles
            size1 = "10px";
            size2 = "8px";
            size1r = "12px";
            size2r = "10px";

            //axis styles
            yMargin = 3;
            labelMargin = 6;
        }
        else
        {
            //Chart styles
            sBottom = 25;
            mBottom = null;
            sTop = 0;
            mTop = 50;
            sLeft = null;
            sRight = 50;      

            //Title styles
            xTitle = 0;

            //legend styles
            lBorder = 2;
            sHeight = 12;

            //texts styles
            size1 = "12px";
            size2 = "12px";
            size1r = "14px";
            size2r = "14px";

            //axis styles
            yMargin = null;
            labelMargin = 10; 
        }                                                               
       
        //Define the initial, basic options.                                       -
        var options = {
            chart: {                  
                alignTicks:false,       
                backgroundColor : aMainStyle.backgroundColor,
                marginBottom : mBottom,
                marginTop : mTop,
                renderTo : inDiv, 
                spacingBottom: aMainStyle.spacingBottom,   
                spacingLeft: aMainStyle.spacingLeft,     
                spacingRight: aMainStyle.spacingRight+10,
                spacingTop : sTop
            },

            credits : {
                enabled : true,                                                                                            
                href : null,
                position: {
                    align: aMainStyle.legendAlign,
                    x: 0
                },
                style : {
                    fontSize : aMainStyle.fontSize1               
                },
                text : '\u00A9'+aWords[0]+' - S&P Global Market Intelligence' 
            },

            exporting : {
                enabled : false
            },    

            legend : {
                borderWidth : 0,
                itemStyle :{
                    fontSize : aMainStyle.fontSize1,
                    fontWeight: "normal"
                },
                margin: aMainStyle.legendMargin,
                symbolHeight: aMainStyle.symbolHeight 
            },              

            loading: {
                hideDuration : 250,
                style : {
                    backgroundColor : 'gray'
                },
                labelStyle : {
                    color : 'white',
                    top: '45%'                             
                }
            },  

            plotOptions : { 
                series: {
                    animation: isAsync,
                    dataGrouping: {
                        enabled: true,
                        forced: true,
                        dateTimeLabelFormats :{
                            day: [dateFormatDay],
                            week: [dateFormatWeek]
                        },
                        units: [['day',[1]]]
                    },      
                    marker: {
                        symbol: "circle"    
                    },
                    states: {
                        hover: {
                            lineWidthPlus: 0
                        }
                    }
                }
            },        

            responsive: {
                rules : [{
                    chartOptions: {
                        chart:{
                            spacingBottom: aMainStyle.spacingBottom-3        
                        },
                        legend : {
                            margin: aMainStyle.legendMargin-3
                        }    
                    },
                    condition: {
                        maxHeight: 350 
                    }
                }]
            },
            
            title : {           
                align : 'left',
                style :{
                    color : '#6e6e6e',
                    fontSize : aMainStyle.fontSize1,                           
                    fontWeight: 'bold'
                },
                text : nomSoc,
                x : 0
            },
            
            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                shared : true,
                headerFormat: '<span style="font-size:12px;"><b>{point.key}</b></span><br><table style="min-width:150px;font-size:12px;">',
                footerFormat: '</table>',
                useHTML: true
            },

            xAxis : [
            {                       
                gridLineColor : aMainStyle.xAxisgridLineColor, 
                gridLineDashStyle: aMainStyle.xAxisgridLineDashStyle,
                gridLineWidth : aMainStyle.xAxisgridLineWidth,
                
                labels: {          
                    formatter: function(){
                        return this.chart.time.dateFormat("%b %y",this.value);
                    },
                    rotation: -45,
                    style : {
                        color: aMainStyle.xAxisLabelColor,
                        fontSize: aMainStyle.fontSize1,
                        fontWeight: aMainStyle.xAxisLabelWeight                            
                    }             
                },         
                lineWidth : aMainStyle.xAxisTopLineWidth,        
                maxPadding: 0.02,    
                opposite : true,
                ordinal: false,          
                startOnTick : false,
                showLastLabel: true,      
                tickInterval : 91*24*3600*1000,
                tickWidth : aMainStyle.xAxisTopTickWidth,                  
                type : 'datetime'
            },
            {                              
                gridLineWidth : 0,       
                labels : {
                    enabled : false
                },  
                lineColor : aMainStyle.xAxisBottomLineColor,
                lineWidth: aMainStyle.xAxisBottomLineWidth,          
                linkedTo : 0,          
                tickWidth : aMainStyle.xAxisBottomTickWidth,                  
                type : 'datetime'
            }
            ],
             
            yAxis : [
            {
                allowDecimals : false,      
                gridLineColor : aMainStyle.xAxisgridLineColor, 
                gridLineDashStyle: aMainStyle.xAxisgridLineDashStyle,
                gridLineWidth : aMainStyle.xAxisgridLineWidth,
                labels: {  
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    },
                    x: 5 
                }, 
                lineColor : aMainStyle.yAxisLeftLineColor,
                lineWidth: aMainStyle.yAxisLeftLineWidth,   
                opposite : true,
                tickWidth : aMainStyle.yAxisLeftTickWidth,
                tickColor : '#A5A5A5',
                title : {               
                    style: {
                        fontSize: aMainStyle.fontSize1,
                        color: aMainStyle.yAxisLabelColor
                    },
                    text : dataChart[3]
                }                                 
            }, {
                max: 1,
                min: 0, 
                tickPositions: [],
                title: ''
            }]
        };

        var chart = new Highcharts.Chart(options);

        if(isAsync)
            chart.showLoading(); 

        var seriesObjCours = {
            color : "#C155FF",
            data : dataChart[1],
            id : "objCours1",      
            marker : {
                enabled: false                     
            },       
            name : aWords[1],            
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.2f} '+dataChart[3]+'</b></td></tr>'
            },      
            type : "line",        
            yAxis : 0,
            zIndex : 2             
        };     

        var seriesCours = {
            color : "black",
            data : dataChart[0],
            id : "cours",        
            marker : {
                enabled : false
            },  
            name : aWords[2],  
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b>{point.y:.2f} '+dataChart[3]+'</b></td></tr>'   
            },              
            type : "line", 
            yAxis : 0,
            zIndex : 1             
        };

        var seriesEcart = {
            color: "#009900",
            data : dataChart[2],
            id : "ecart",    
            lineWidth: 0,   
            marker : {
                enabled : false
            },  
            name : aWords[3], 
            negativeColor: "#CC0000", 
            showInLegend: false,
            tooltip : {
                pointFormat : '<tr><td style="padding:0;">{series.name}: </td><td style="padding:0;text-align:right;"><b><span style="color: {point.color};">{point.y:-.2f}%</span></b></td></tr>'   
            },              
            type : "line", 
            yAxis : 1,
            zIndex : 1             
        };   

        chart.addSeries(seriesObjCours,dataChart[0].length==0,isAsync);  
        if(dataChart[0].length>0)                      
            chart.addSeries(seriesCours,true,isAsync); 
        if(dataChart[2].length>0)                      
            chart.addSeries(seriesEcart,true,isAsync);

        chart.hideLoading(); 

    });   
}


function drawGraphSecteur(codeZB,inDiv,aWords,bIsMobile,bExporting)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    bExporting = (typeof bExporting === "undefined") ? false : bExporting;

    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : false,
        data : {repNo : null , codeZB : codeZB, t : 'sector', iLang: iLang},
        type : 'GET'
    })
    .done(function(data)
    {
        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }  

        var aCodeZB = dataChart[0];
        var aNomSoc = dataChart[1];                                        

        var options = {
            chart : {
                renderTo : inDiv,
                marginTop : 10,
                spacingTop : 0,
                spacingBottom: 20, 
                spacingRight : 40, 
                spacingLeft : 40,             
                backgroundColor : "#EEEEEE",             
            },

            colors : ["#ff3000","#F2943E","#ffae00","#33d251","#16a8ec","#9644c5","#81F7BE"],

            exporting : {
                enabled : false //actuellement utilis� uniquement dans pdf report
            },

            credits : {
                enabled : true,
                href : null,
                text : '\u00A9'+aWords[0],
                style : {
                    fontSize : '12px'               
                } 
            },

            title : {
                floating : true,
                text : ''
            },                

            legend : {
                enabled : true
            },

            navigator : { 
                enabled: false
            },

            scrollbar : {
                enabled : false
            },

            rangeSelector:{
                enabled:false
            },

            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                shared : true,
                headerFormat: '<span style="font-size:12px">'+aWords[7]+' : <b>{point.key}</b></span><br><table style="min-width:150px;">',
                footerFormat: '</table>',
                useHTML: true                            
            },

            xAxis : [
            {
                labels : {   
                    align : 'center',
                    style: {
                        color : 'black'
                    }
                },
                tickWidth : 1,
                tickLength : 5,
                tickColor : 'black',       
                title : null, 
                lineColor : 'black',
                showFirstLabel: true,
                range: 1000*3600*24*365  
            }, 
            {
                lineWidth : 1,
                lineColor : 'black',
                opposite : true,
                labels : {
                    enabled : false
                },
                title: {
                    enabled: false
                },
                range: 1000*3600*24*365     
            }], 

            yAxis : [{
                lineWidth : 1,   
                alternateGridColor : "#FFFFFF",
                gridLineColor : "#DFE7F0",
                title : "variation",                    
                opposite : false, 
                lineColor : 'black',
                tickWidth : 1,
                tickLength : 5,
                tickColor : 'black',
                labels: {
                    align: 'left',
                    x: -35,
                    format : '{value}%',
                    style: {
                        color: "black"
                    }
                }                       
                },
                {
                    lineWidth : 1,   
                    alternateGridColor : "#FFFFFF",
                    gridLineColor : "#DFE7F0",
                    title : "variation",  
                    lineColor : 'black',
                    tickWidth : 1,
                    tickLength : 5,
                    tickColor : 'black',
                    linkedTo : 0,
                    labels: {
                        align: 'right',
                        x: 35,
                        format : '{value}%',
                        style: {
                            color: "black"
                        }
                    }                        
            }],

            plotOptions : {
                series: {
                    animation: false,
                    compare : 'percent',
                    dataGrouping: {
                        dateTimeLabelFormats :{
                            day: [dateFormatDay],
                            week: [dateFormatWeek]
                        }
                    },
                    turboThreshold: 0
                },
                line: {
                    lineWidth : 2
                }
            }                
        };
                   
        var chart = new Highcharts.StockChart(options);

        recursiveAddValuesInChart(aCodeZB,aNomSoc,chart);
    });
   
}

        
function drawGraphMulti(aCodeZB,aNomSoc,inDiv,decimalsToDisplay,aWords,animated,bIsMobile)
{                 
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    animated = (typeof animated === "undefined") ? false : animated;
        
    var options = {
        chart : {
            renderTo : inDiv,
            marginTop : 10,
            spacingTop : 10,
            spacingBottom: 20, 
            events: {
                load: function(){   
                    if(this.chartHeight < 500)
                        return;
                                              
                    var imageHeight = 25;
                    var imageWidth = 240;
                    
                    this.renderer.image("/images/pdf_Report/"+aWords[0].capitalize()+".png",60,55,imageWidth,imageHeight).css({opacity: 0.5}).attr({zIndex: 2}).add();
                }
            }            
        },
        
        colors: ["#1a324a",'#F34348','#90ed7d','#f7a35c','#8085e9','#612332','#e4d354','#3480de','#28bd48','#91e8e1'], 

        exporting : {
            enabled : true,
            buttons: {
                contextButton: {
                    theme: {
                        fill: "#004EFF",
                        states: {
                            hover: {
                                fill: '#004EFF'
                            },
                            select: {
                                fill: '#004EFF'
                            }
                        }                                                
                    },
                    symbolStroke: "white",
                    symbolStrokeWidth: 2,
                    menuItems: [{
                        textKey: "printChart",
                        onclick: function (){this.print()}
                    },
                    {
                        separator: true
                    },
                    {
                        textKey: "downloadPNG",
                        onclick: function (){this.exportChart()}   
                    },
                    {
                        textKey: "downloadJPEG",
                        onclick: function (){this.exportChart({type:"image/jpeg"})}   
                    },
                    {
                        textKey: "downloadSVG",
                        onclick: function (){this.exportChart({type:"image/svg+xml"})}   
                    }]
                }
            }
        },

        credits : {
            enabled : true,
            href : null,
            text : '\u00A9'+aWords[0],
            style : {
                fontSize : '12px'               
            } 
        },               

        legend : {
            enabled : true
        },

        tooltip: {
            backgroundColor: {
                linearGradient: {
                    x1: 0,
                    y1: 0,
                    x2: 0,
                    y2: 1
                },
                stops: [
                    [0, 'white'],
                    [1, '#EEE']
                ]
            },
            borderColor: 'gray',
            borderWidth: 1,
            borderRadius: 5,
            shared : true,
            split: false,
            headerFormat: '<span style="font-size:12px">'+aWords[1]+' : <b>{point.key}</b></span><br><table style="min-width:150px;">',
            footerFormat: '</table>',
            useHTML: true                          
        },
        
        rangeSelector : configSelectorLong,
        
        responsive: {
            rules:[{
                chartOptions: {
                    chart: {
                        spacingBottom: null,
                        marginBottom: 35,
                        
                    },
                    navigator: {
                        enabled: false
                    },
                    rangeSelector: {
                        inputEnabled: false
                    }
                    ,
                    scrollbar: {
                        enabled: false
                    }
                },
                condition: {
                    maxHeight: 500
                }
            }]    
        },
        
        navigator : { 
            xAxis : {  
                labels: {
                    style : {
                        color: "black"
                    }
                }
            },
            baseSeries: aCodeZB[0]
        }, 

        xAxis : [
        {
            labels : {   
                align : 'center',
                style : {
                    color: "black"
                },                         
            },
            lineWidth : 1,
            lineColor : 'black',
            gridLineColor : "#ededed",
            gridLineWidth: 1,
            tickLength : 5,
            tickColor : 'black',       
            title : null,
            showFirstLabel: true,
            range: 1000*3600*24*365  
        }, 
        {
            lineWidth : 1,
            lineColor : 'black',
            linkedTo: 0,       
            opposite : true,
            labels : {
                enabled : false
            },
            title: null,
            tickLength : 0    
        }], 

        yAxis : [{
            id: 'leftAxis',
            lineWidth : 1,   
            gridLineColor : "#ededed",
            title : "variation",                    
            opposite : false, 
            lineColor : 'black',
            tickWidth : 1,
            tickLength : 5,
            tickColor : 'black',
            labels : {    
                format : '{value}%',
                verticalAlign : 'middle',
                style : {
                    color: "black"
                }          
            },                       
        },
        {
            id: 'rightAxis',
            lineWidth : 1,   
            gridLineColor : "#ededed",
            title : "variation",  
            lineColor : 'black',
            tickWidth : 1,
            tickLength : 5,
            tickColor : 'black',
            linkedTo : 0,
            labels : {    
                format : '{value}%',
                verticalAlign : 'middle',
                style : {
                    color: "black"
                }          
            },
            offset : 20                       
        }],   

        plotOptions : {
            series: {
                turboThreshold: 0,
                compare: 'percent',
                dataGrouping: {
                    dateTimeLabelFormats :{
                        day: [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                },
                states: {
                    hover: {
                        lineWidth: 2
                    }
                }       
            },
            line: {
                lineWidth : 2
            }
        }                
    };
    
    $("#"+inDiv).height()<500
    {
        options.exporting.enabled = false;
    }
    
    var chart = new Highcharts.StockChart(options);
        
    if(animated)
        chart.showLoading();

    if(aCodeZB.length>0)
        recursiveAddValuesInChart(aCodeZB,aNomSoc,chart,decimalsToDisplay,animated,bIsMobile);            
}


function drawGraphRatio(aCodeZB,aNomSoc,inDiv,nbDecimals,aWords,animated,bIsMobile)
{
    var aDataVal1 = [];
    var aDataVal2 = [];
    
    animated = (typeof animated === "undefined") ? false : animated;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;

    var options = {
        chart : {
            renderTo : inDiv,
            marginTop : 10,
            spacingTop : 0,
            spacingBottom: 25, 
            marginBottom: 60, 
            backgroundColor : "#FFFFFF",   
            events: {
                load: function(){                         
                    var imageHeight = 25;
                    var imageWidth = 240;
                    
                    this.renderer.image("/images/pdf_Report/"+aWords[0].capitalize()+".png",90,55,imageWidth,imageHeight).css({opacity: 0.5}).attr({zIndex: 2}).add();
                }
            }            
        },
        
        colors: ["#1a324a",'#000000','#5ab400'],
        
        navigator : { 
            xAxis : {  
                labels: {
                    style : {
                        color: "black"
                    }
                }
            }
        }, 

        exporting : {
            enabled : true,
            buttons: {
                contextButton: {
                    theme: {
                        fill: "#004EFF",
                        states: {
                            hover: {
                                fill: '#004EFF'
                            },
                            select: {
                                fill: '#004EFF'
                            }
                        }                                                
                    },
                    symbolStroke: "white",
                    symbolStrokeWidth: 2,
                    menuItems: [{
                        textKey: "printChart",
                        onclick: function (){this.print()}
                    },
                    {
                        separator: true
                    },
                    {
                        textKey: "downloadPNG",
                        onclick: function (){this.exportChart()}   
                    },
                    {
                        textKey: "downloadJPEG",
                        onclick: function (){this.exportChart({type:"image/jpeg"})}   
                    },
                    {
                        textKey: "downloadSVG",
                        onclick: function (){this.exportChart({type:"image/svg+xml"})}   
                    }]
                }
            }
        },

        rangeSelector : configSelectorLong,
        
        credits : {
            enabled : true,
            href : null,
            text : '\u00A9'+aWords[0],
            style : {
                fontSize : '12px'               
            } 
        },               

        legend : {
            enabled : true
        },   

        tooltip: {
            backgroundColor: {
                linearGradient: {
                    x1: 0,
                    y1: 0,
                    x2: 0,
                    y2: 1
                },
                stops: [
                    [0, 'white'],
                    [1, '#EEE']
                ]
            },
            borderColor: 'gray',
            borderWidth: 1,
            borderRadius: 5,
            shared : true,
            split: false,
            headerFormat: '<span style="font-size:12px">'+aWords[1]+' : <b>{point.key}</b></span><br><table style="min-width:150px;">',
            footerFormat: '</table>',
            useHTML: true                            
        },

        xAxis : [
        {
            labels : {   
                align : 'center',
                style : {
                    color: "black"
                }
            },
            lineWidth : 1,
            gridLineColor : "#ededed",
            gridLineWidth: 1,       
            title : null,
            showFirstLabel: true,
            lineColor : 'black',
            tickWidth : 1,
            tickLength : 5,
            tickColor : 'black'
        }, 
        {
            lineWidth : 1,
            opposite : true,
            labels : {
                enabled : false
            },
            title: {
                enabled: false
            },
            lineColor : 'black',
            tickWidth : 1,
            tickLength : 5,
            tickColor : 'black'
        }], 

        yAxis : [
        {
            lineWidth : 1,   
            gridLineColor : "#ededed",
            title : {
                text: "variation",
                style: {
                    fontSize: '14px',
                    color: "black"    
                }
            },                    
            opposite : false, 
            lineColor : 'black',
            tickWidth : 1,
            tickLength : 5,
            tickColor : 'black',
            labels : {    
                format : '{value}%',
                verticalAlign : 'middle',
                style: {
                    color: 'black'   
                }          
            }
        },
        {
            lineWidth : 1,   
            gridLineColor : "#ededed",
            title : {
                text: "ratio",
                rotation: 270,
                style:{
                    fontSize: "14px",
                    color: 'black'    
                },
                margin: 20    
            },  
            lineColor : 'black',
            tickWidth : 1,
            tickLength : 5,
            tickColor : 'black',
            labels : {    
                verticalAlign : 'middle',
                style : {
                    color: "black"
                }          
            },
            offset: 20
        }],

        plotOptions : {    
            line: {
                lineWidth : 2
            },                                                                     
            series: {
                dataGrouping: {
                    dateTimeLabelFormats :{
                        day: [dateFormatDay],
                        week: [dateFormatWeek]
                    }
                },
                states: {
                    hover: {
                        lineWidthPlus: 0
                    }
                }
            }
        }                
    };

    var chart = new Highcharts.StockChart(options);
    chart.showLoading();
    
    $.ajax({url : URL_SERVEUR+'atDataFeed.php',  
        data : {codeZB : aCodeZB[0], type : "chart", fields : "Date,Close"},
        type : 'GET'
    })
    .done(function(data)
    {    
        try
        {
            aDataVal1 = JSON.parse(data)    
        }
        catch(e)
        {
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        } 


        if(aCodeZB[1])
        {
            $.ajax({url : URL_SERVEUR+'atDataFeed.php',
                context : document.body,
                async : false,
                data : {codeZB : aCodeZB[1], type : "chart", fields : "Date,Close"},
                type : 'GET'
            })
            .done(function(data)
            {    
                try
                {
                    aDataVal2 = JSON.parse(data)    
                }
                catch(e)
                {
                    $('#'+inDiv).css('display','none');
                    console.log("erreur JSON parse : "+e);
                    console.log("data received : "+data);
                    return;
                }                             
            });        
        }


        var primarySeries = {                          
            type : 'line',
            name : aNomSoc[0],   
            data : [],
            id : "val1",
            yAxis: 0,
            tooltip : {
                pointFormat : '<tr><td nowrap style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.'+nbDecimals+'f}({point.change}%)</b></td></tr>'
            },
            compare: 'percent'              
        };

        var comparingSeries = {                          
            type : 'line',
            name : aNomSoc[1] || "N/D",   
            data : [],
            id : "val2",
            yAxis: 0,
            tooltip : {
                pointFormat : '<tr><td nowrap style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.'+nbDecimals+'f}({point.change}%)</b></td></tr>'
            },
            compare: 'percent'             
        };

        var sRatio = (aNomSoc[1]) ? "Ratio "+aNomSoc[0]+" / "+aNomSoc[1] : "Ratio";
        var seriesRatio = {                          
            type : 'line',
            name : sRatio,   
            data : [],
            id : "seriesRatio",
            yAxis: 1,
            tooltip : {
                pointFormat : '<tr><td nowrap style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.2f}</b></td></tr>'
            }              
        };

        var comparingList = {};
        var lastDate = (aCodeZB[1]) ? aDataVal2[aDataVal2.length-1][0] : 0;
        for(var i=aDataVal2.length-1; i>=0; i--)
        {
            if((lastDate-aDataVal2[i][0])>1000*3600*24*356*nbAnneeHisto)
                break;
            comparingSeries.data.unshift(aDataVal2[i]);
            comparingList[aDataVal2[i][0]]=aDataVal2[i][1];
        }

        lastDate = aDataVal1[aDataVal1.length-1][0];
        for(var i=aDataVal1.length-1; i>=0; i--)
        {
            if((lastDate-aDataVal1[i][0])>1000*3600*24*356*nbAnneeHisto)
                break;
            primarySeries.data.unshift(aDataVal1[i]);
            if(comparingList[aDataVal1[i][0]])
                seriesRatio.data.unshift([aDataVal1[i][0],aDataVal1[i][1]/comparingList[aDataVal1[i][0]]]);    
        }

        seriesRatio.visible = (Object.keys(comparingList).length>0);        

        chart.addSeries(primarySeries,false,false);
        chart.addSeries(comparingSeries,false,false);
        chart.addSeries(seriesRatio,true,animated);
        chart.hideLoading();
    });
}


function addValueInChart(value,name,chart,decimalsToDisplay,animated,bIsMobile)
{
    if((typeof chart === "undefined"))
        return;
        
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    animated = (typeof animated === "undefined") ? false : animated;
     
    if((typeof chart)==="string")
        var chart = $("#"+chart).highcharts();
        
    if(animated&&chart)
        chart.showLoading();
    
    recursiveAddValuesInChart([value],[name],chart,decimalsToDisplay,animated,bIsMobile);    
}


function addForexInChart(aForex,chart,animated,bIsMobile)
{
    if((typeof chart === "undefined"))
        return;
     
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    animated = (typeof animated === "undefined") ? false : animated;
     
    if((typeof chart)==="string")
        var chart = $("#"+chart).highcharts();
    
    var currentForex = aForex.shift();
        
    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        context : document.body,
        async : animated,
        data : {type : "forex", currencies: currentForex},
        type : 'GET'
    })
    .done(function(data)
    {    
        try
        {
            aDataQuote = JSON.parse(data)    
        }
        catch(e)
        {                                        
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
               
        var chartSeries = {                          
            type : 'line',
            name : currentForex[0]+"/"+currentForex[1],   
            data : aDataQuote,
            id : currentForex[0]+"/"+currentForex[1],
            yAxis: 0,
            tooltip : {
                pointFormat : '<tr><td nowrap style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.4f}({point.change}%)</b></td></tr>'
            }            
        };                                   

        // Update the chart                              
        chart.addSeries(chartSeries,false,false);
        
        if(aForex.length>0)
            addForexInChart(aForex,chart,animated,bIsMobile)
        else
        {
            chart.redraw();
            chart.hideLoading();
            chart.rangeSelector.clickButton(6,true);   
        }
    });
}


function removeValueInChart(codezb,chart,bIsMobile)
{
    if((typeof chart === "undefined"))
        return;
    
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
     
    if((typeof chart)==="string")
        var chart = $("#"+chart).highcharts();
        
    chart.get(codezb).remove();
}


function recursiveAddValuesInChart(aValues,aNames,chart,decimalsToDisplay,animated,bIsMobile)
{
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;
    animated = (typeof animated === "undefined") ? false : animated;
                                                 
    var currentCodeZB = aValues.shift();      
    var currentName = aNames.shift();
            
    $.ajax({url : URL_SERVEUR+'atDataFeed.php',
        context : document.body,
        async : animated,
        data : {codeZB : currentCodeZB, type : "chart", fields : "Date,Close"},
        type : 'GET'
    })
    .done(function(data)
    {    
        try
        {
            aDataQuote = JSON.parse(data)    
        }
        catch(e)
        {                                        
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
                
        var chartSeries = {                          
            type : 'line',
            name : currentName,   
            data : aDataQuote,
            id : currentCodeZB,
            yAxis: 0,
            //zIndex : aValues.length,
            tooltip : {
                pointFormat : '<tr><td nowrap style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.'+decimalsToDisplay+'f}({point.change}%)</b></td></tr>'
            }            
        };  
        
        // Update the chart                              
        chart.addSeries(chartSeries,true,animated);
        
        //Selectionne 6m pour graph r�f�rence (responsive) 
        if((chart.userOptions.navigator.baseSeries == currentCodeZB) && ($(chart.renderTo).height()<500))
            chart.rangeSelector.buttons[2].element.onclick()    

        if(aValues.length)      
            recursiveAddValuesInChart(aValues,aNames,chart,decimalsToDisplay,animated,bIsMobile);   
        else
        {
            chart.redraw();
            chart.hideLoading();
        }
    });
}


function drawGraphDividendrendement(codeZB,nomSoc,inDiv,aWords,isAsync,bIsMobile)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    bIsMobile = (typeof bIsMobile === "undefined") ? false : bIsMobile;

    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : 'divrend', iLang: iLang},
        type : 'GET'
    })
    .done(function(data){

        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }  
        
        var aData = dataChart[0];
        var aYears = new Array();
        $.each(dataChart[1], function(index,indYear)
            {
                aYears.push(indYear);        
        });
        var sCurrency = dataChart[2];

        var size1, size2, lBorder, sHeight, rotation, yMargin, labelMargin;

        if($('#'+inDiv).height()<=250)
        {
            //Title styles
            xTitle = 10;

            //legend styles
            lBorder = 1;
            sHeight = 8;

            //texts styles
            size1 = "10px";
            size2 = "8px";

            //axis styles
            yMargin = 8;
            labelMargin = 6;
        }
        else
        {
            //Title styles
            xTitle = 0;

            //legend styles
            lBorder = 2;
            sHeight = 12;

            //texts styles
            size1 = "12px";
            size2 = "12px";

            //axis styles
            yMargin = 10;
            labelMargin = 10; 
        }
            
        aSkinOptions = {
            background: "white",
            greenCol: "#34c242",
            darkBrown: "#433935",
            margins: [25,60],
            spacings: [0,0,20,0]
        };                                                              

        //Define the initial, basic options.
        var options = {

            chart: {
                renderTo : inDiv,
                backgroundColor : aSkinOptions.background,  
                alignThresholds: true,
                marginTop : aSkinOptions.margins[0],
                marginBottom : aSkinOptions.margins[1],
                spacingTop : aSkinOptions.spacings[0],
                spacingRight: aSkinOptions.spacings[1],
                spacingBottom: aSkinOptions.spacings[2],
                spacingLeft: aSkinOptions.spacings[3],
                alignTicks:false
            },

            exporting : {
                enabled : false
            },

            title : { 
                text : nomSoc,
                align : 'left',
                style :{
                    fontSize : size1,                           
                    fontWeight: 'bold',
                    color : '#6e6e6e'
                },
                x : xTitle
            },

            legend : {
                backgroundColor: 'white',
                borderWidth: lBorder,
                borderRadius: 3,
                itemStyle: {
                    fontSize : size2
                },
                symbolHeight: sHeight
            },

            credits : {
                enabled : true,
                href : null,
                text : '\u00A9'+aWords[0]+' - S&P Global Market Intelligence',
                style : {
                    fontSize : size2
                } 
            }, 

            loading: {
                hideDuration : 250,
                style : {
                    backgroundColor : 'gray'
                },
                labelStyle : {
                    color : 'white',
                    top: '45%'                             
                }
            },

            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                shared : true,
                headerFormat: '<span style="font-size:12px">'+aWords[3]+' : <b>{point.key}</b></span><br><table style="min-width:150px;">',
                footerFormat: '</table>',
                useHTML: true
            },

            xAxis : [{
                categories : aYears,
                opposite : true,
                gridLineDashStyle: 'Dash',
                gridLineWidth : 1,
                lineWidth : 2,
                lineColor : '#A5A5A5',
                tickWidth : 0,
                labels : {
                    style : {
                        fontWeight : 'bold',
                        fontSize: size2
                    },
                    y : -5                        
                }
                },
                {
                    categories : aYears,
                    linkedTo : 0,             
                    gridLineWidth : 0,
                    lineWidth: 2,
                    lineColor : '#A5A5A5',
                    tickWidth : 2,
                    tickLength : 5,
                    tickColor : '#A5A5A5',
                    labels : {
                        enabled : false
                    }            
            }],

            yAxis : [{
                title : {
                    text : (sCurrency||''),
                    style : {
                        fontSize : size1,
                        fontWeight : 'bold',
                        color : "#434343"
                    },
                    margin : yMargin
                },
                alternateGridColor: "white",
                gridLineColor : "#E3E3E3",
                lineWidth: 2,
                tickLength : 5, 
                lineColor : '#A5A5A5',
                tickWidth : 2,
                tickLength : 5,
                tickColor : '#A5A5A5',
                labels : {
                    style : {
                        fontWeight : 'bold',
                        fontSize: size2,
                    }, 
                    formatter: function(){
                        if((Number(this.value.toFixed(2))-this.value)!==0)
                            return Highcharts.numberFormat(this.value.toFixed(2));
                        else
                            return Highcharts.numberFormat(this.value);
                    },
                    x : -labelMargin
                },
                tickPixelInterval: 30  

                },
                {
                title : {
                    text : aWords[1],
                    style : {
                        fontSize : size1,
                        fontWeight : 'bold',
                        color : "#434343"
                    },
                    rotation : 270,
                    margin : yMargin+5
                },
                lineWidth: 2,
                lineColor : '#A5A5A5',
                gridLineWidth : 0,
                tickWidth : 2,
                tickLength : 5,
                tickColor : '#A5A5A5',
                labels :{
                    format: '{value:.1f}%',
                    style : {
                        fontWeight : 'bold',
                        fontSize: size2
                    },
                    x : labelMargin
                },
                opposite : true                  
            }],

            plotOptions: {
                column : {
                    borderWidth : 0,
                    //pointPadding: 0.01,
                    shadow : true
                },
                line : {
                    marker : {
                        fillColor: aSkinOptions.b,
                        lineColor: 'white',
                        lineWidth: 2,
                        symbol: "circle"                     
                    },
                    shadow : true,
                },
                series: {
                    animation: isAsync
                }       
            } 
        };

        var chart = new Highcharts.Chart(options);

        if(isAsync)
            chart.showLoading();

        var seriesDiv = {
            type : 'column',
            yAxis : 0,
            color : aSkinOptions.greenCol,
            data : aData[0],
            name : aWords[2],
            id : 'div',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.2f}&nbsp;'+(sCurrency||'')+'</b></td></tr>'
            }            
        };

        var seriesDivRend = {
            type : 'line',
            yAxis : 1,
            color : aSkinOptions.darkBrown,
            data : aData[1],
            name : aWords[1],
            id : 'divrend',
            tooltip : {
                pointFormat : '<tr><td style="padding:0;font-size:12px">{series.name}: </td><td style="padding:0;font-size:12px; text-align : right;"><b>{point.y:.2f}&nbsp;%</b></td></tr>'
            }             
        };

        chart.addSeries(seriesDiv,false,isAsync);
        chart.addSeries(seriesDivRend,true,isAsync);    //redraw chart after adding the last series

        chart.hideLoading(); 
    }); 
}


function drawGraphNotation(aCodeZB,comparaison,inDiv,aWords,ponderation,isAsync)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    
    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {aCodeZB : aCodeZB, comparaison : comparaison, t : 'notation', p : ponderation, iLang: iLang},
        type : 'GET'
    })
    .done(function(data){

        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
        
        var options = {

            chart: {
                renderTo : inDiv,
                polar: true
            },

            title: {
                text: ''
            },
            
            exporting: {
                enabled: false
            },
            
            credits: {
                enabled: false
            },
            
            legend: {
                enabled: true
            },
            
            pane: {
                size: "90%",
                center: ['50%','52%']
            },
            
            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                useHTML: true,
                shared: true
            },
            
            xAxis: [{
                categories: [aWords[0],aWords[1],aWords[2],aWords[3],aWords[4],aWords[5],aWords[6],aWords[7],aWords[8],aWords[9],aWords[10],aWords[11]],
                tickmarkPlacement: 'on',
                lineWidth: 0,
                reversed: true,
                labels: {
                    distance: 15
                }
            }],
            
            yAxis: [{
                min: 0,
                max: 100,
                gridLineInterpolation: 'polygon',
                lineWidth: 0,
                showLastLabel: true,
                tickInterval: 20,
                labels: {
                    format: '{value}%',
                    y: 5
                }
            }],
            
            plotOptions: {
                line: {
                    tooltip:{
                        valueDecimals: 0,
                        valueSuffix: "%"
                    },
                    states:{
                        hover:{
                            lineWidthPlus: 0
                        }
                    }
                }
            },
            
            series: [{
                type: 'line',
                lineWidth: 3,
                name: aWords[12],
                marker: {
                    enabled: false
                },
                pointPlacement: "on",
                data: dataChart[0],
                //zIndex: 4
            }]
        };  
        
        if((comparaison != 0) && (dataChart[1].length > 0))
        options.series.push({
            type: 'line',
            lineWidth: 2,
            name: aWords[13],          
            marker: {
                enabled: false
            },
            pointPlacement: "on",
            data: dataChart[1],
            //zIndex: 3
        });
        
        var chart = new Highcharts.Chart(options); 
        
        $.each(chart.yAxis[0].ticks, function(index,tick){
                if(index!=0)
                {
                    var x = chart.yAxis[0].ticks[index].label.xy.x - chart.yAxis[0].ticks[index].label.textPxLength -2,
                        y = chart.yAxis[0].ticks[index].label.xy.y + ((chart.yAxis[0].ticks[0].label.xy.y - chart.yAxis[0].ticks[index].label.xy.y) * 2);
                    chart.renderer.label(index+"%",x,y,'rect',null,null,false,true)
                    .attr({
                        zIndex: 4
                    })
                    .css({
                        fontSize: '11px',
                        color: "#606060"
                    })
                    .add();    
                }    
            });
    });
}


function drawGraphRepSect(aCodeZB,inDiv,ponderation,isAsync)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    
    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {aCodeZB : aCodeZB, t : 'rep_sect', p : ponderation, iLang: iLang},
        type : 'GET'
    })
    .done(function(data){

        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
        
        var categories = dataChart[0],  
            data = dataChart[1],
            sectData = [],
            subSectData = [],   
            i,
            j, 
            dataLen = data.length,
            drillDataLen,  
            brightness;       
            
        // Build the data arrays
        for (i = 0; i < dataLen; i += 1) {

            // add browser data
            sectData.push({
                name: categories[i],
                y: data[i].y,
                color: data[i].color
            });

            // add sub-sector data
            drillDataLen = data[i].drilldown.data.length;
            for (j = 0; j < drillDataLen; j += 1) {
                brightness = 0.2 - (j / drillDataLen) / 5;
                subSectData.push({
                    name: data[i].drilldown.categories[j],
                    y: data[i].drilldown.data[j],
                    color: Highcharts.Color(data[i].color).brighten(brightness).get()
                });
                 
            }  
        }
            
        options = {
            chart: {
                marginTop: 0,
                marginBottom: 0,
                renderTo: inDiv
            },
            
            title: {
                text: ''
            },
            
            credits: {
                enabled: false
            },
            
            exporting: {
                enabled: false
            },
            
            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5         
                
            }, 
            
            plotOptions: {
                pie : {
                    tooltip: {
                        valueDecimals: 2,
                        valueSuffix: '%'    
                    }
                }
            },  
            
            series: [{
                type: "pie",
                name: dataChart[2],
                dataLabels: {      
                    color: "#ffffff",
                    style: {
                        width: '100px'
                    },
                    distance: -1,                    
                    connectorWidth: 0                           
                },
                data: sectData,
                size: '90%' 
            },{
                type: "pie",
                name: dataChart[3],
                dataLabels: {      
                    enabled: false                    
                },
                data: sectData,
                size: '50%' 
            },{
                type: "pie",
                name: dataChart[4],     
                dataLabels: {
                    enabled: false
                },
                data: subSectData,
                size: '100%',
                innerSize: '51%' 
            }]
        };
        
        var chart = new Highcharts.Chart(options);
        
    });    
}


function drawGraphCompNota(aCodeZB,inDiv,aWords,isAsync)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    
    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {aCodeZB : aCodeZB, t : 'comp_nota', iLang: iLang},
        type : 'GET'
    })
    .done(function(data){

        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
        
        if($('#'+inDiv).height()<=250)
        {           
            //texts styles
            size1 = "10px";
            size2 = "8px";    
        }
        else
        {
            //texts styles
            size1 = "12px";
            size2 = "12px";    
        }
        
        var options = {

            chart: {
                renderTo : inDiv,
                polar: true
            },

            title: {
                text: ''
            },
            
            exporting: {
                enabled: false
            },
            
            credits : {
                enabled : true,                                                                                            
                href : null,
                text : '\u00A9'+aWords[0]+' - S&P Global Market Intelligence',
                style : {
                    fontSize : size2               
                } 
            },
            
            legend: {
                enabled: true
            },
            
            pane: {
                size: "90%",
                center: ['50%','52%']
            },
            
            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                useHTML: true,
                shared: true
            },
            
            xAxis: [{
                categories: [aWords[1],aWords[2],aWords[3],aWords[4],aWords[5],aWords[6],aWords[7],aWords[8],aWords[9],aWords[10],aWords[11],aWords[12]],
                tickmarkPlacement: 'on',
                lineWidth: 0,
                reversed: true,
                labels: {
                    distance: 15
                }
            }],
            
            yAxis: [{
                min: 0,
                max: 100,
                gridLineInterpolation: 'polygon',
                lineWidth: 0,
                showLastLabel: true,
                tickInterval: 20,
                labels: {
                    format: '{value}%',
                    y: 5
                }
            }],
            
            plotOptions: {
                line: {
                    tooltip:{
                        valueDecimals: 0,
                        valueSuffix: "%"
                    },
                    states:{
                        hover:{
                            lineWidthPlus: 0
                        }
                    }
                }
            },
            
            series: []
        };
        
        $.each(dataChart,function(index,aData){
            options.series.push({
                type: 'line',
                lineWidth: (index==0) ? 3 : 2,
                name: dataChart[index][0],
                marker: {
                    enabled: false
                },
                pointPlacement: "on",
                data: dataChart[index][1],
                //zIndex: dataChart.length - index
            });    
        });
          
        
        var chart = new Highcharts.Chart(options); 
        
        $.each(chart.yAxis[0].ticks, function(index,tick){
            if(index!=0)
            {
                var x = chart.yAxis[0].ticks[index].label.xy.x - chart.yAxis[0].ticks[index].label.textPxLength - 3,
                    y = chart.yAxis[0].ticks[index].label.xy.y + ((chart.yAxis[0].ticks[0].label.xy.y - chart.yAxis[0].ticks[index].label.xy.y) * 2);
                chart.renderer.label(index+"%",x,y,'rect',null,null,false,true)
                .attr({
                    zIndex: 4
                })
                .css({
                    fontSize: '11px',
                    color: "#606060"
                })
                .add();    
            }    
        });
        
        /*$.each(chart.yAxis[0].ticks, function(index,tick){
            if(index!=0)
            {
                var x = chart.yAxis[0].ticks[index].label.xy.x - chart.yAxis[0].ticks[index].labelLength -2,
                    y = chart.yAxis[0].ticks[index].label.xy.y + ((chart.yAxis[0].ticks[0].label.xy.y - chart.yAxis[0].ticks[index].label.xy.y) * 2);
                chart.renderer.label(index+"%",x,y,'rect',null,null,false,true)
                .attr({
                    zIndex: 4
                })
                .css({
                    fontSize: '11px',
                    color: "#606060"
                })
                .add();    
            }    
        });*/
    });
}


function drawGraphNotaValPaysSect(codeZB,inDiv,aWords,isSmall,isAsync)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    isSmall = (typeof isSmall === "undefined") ? false : isSmall;
    
    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : 'nota_val_pays_sect', iLang: iLang},
        type : 'GET'
    })
    .done(function(data){
        
        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
        
        
        if($('#'+inDiv).height()<=250)
        {           
            //texts styles
            size1 = "10px";
            size2 = "8px";    
        }
        else
        {
            //texts styles
            size1 = "12px";
            size2 = "12px";    
        }
        
        var options = {

            chart: {
                renderTo : inDiv,
                polar: true
            },
            
            credits : {
                enabled : !isSmall,                                                                                            
                href : null,
                text : '\u00A9'+aWords[0]+' - S&P Global Market Intelligence',
                style : {
                    fontSize : size2               
                } 
            },
            
            exporting: {
                enabled: false
            },       
            
            legend: {
                enabled: !isSmall
            },
            
            pane: {
                size: isSmall ? "100%" : "90%",
                center: ['50%','52%']
            },
            
            plotOptions: {
                line: {
                    tooltip:{
                        valueDecimals: 0,
                        valueSuffix: "%"
                    },
                    states:{
                        hover:{
                            lineWidthPlus: 0
                        }
                    }
                }
            },
            
            responsive: {
                rules: [{
                    chartOptions: {
                        pane: {
                            size: "75%"
                        }     
                    },
                    condition: {
                        maxWidth: 320
                    }
                }]
            },
            
            series: [{
                type: 'line',
                lineWidth: 3,
                name: dataChart[0][0],
                marker: {
                    enabled: false
                },
                pointPlacement: "on",
                data: dataChart[1],
                //zIndex: 5
            },{
                type: 'line',
                lineWidth: 2,
                name: dataChart[0][1],          
                marker: {
                    enabled: false
                },
                pointPlacement: "on",
                data: dataChart[2],
                //zIndex: 4
            },{
                type: 'line',
                lineWidth: 2,
                name: dataChart[0][2],          
                marker: {
                    enabled: false
                },
                pointPlacement: "on",
                data: dataChart[3],
                //zIndex: 3
            }],

            title: {
                text: ''
            }, 
            
            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                useHTML: true,
                shared: true
            },
            
            xAxis: [{
                categories: [aWords[1],aWords[2],aWords[3],aWords[4],aWords[5],aWords[6],aWords[7],aWords[8],aWords[9],aWords[10],aWords[11],aWords[12]],
                tickmarkPlacement: 'on',
                lineWidth: 0,
                reversed: true,
                labels: {
                    enabled: !isSmall,
                    distance: 15
                }
            }],
            
            yAxis: [{
                min: 0,
                max: 100,
                gridLineInterpolation: 'polygon',
                lineWidth: 0,
                showLastLabel: true,
                tickInterval: 20,
                labels: {
                    format: '{value}%',
                    y: 5
                }
            }] 
        };  
        
        var chart = new Highcharts.Chart(options); 
        
        //Draw opposite labels
        if(!isSmall)
        {
            $.each(chart.yAxis[0].ticks, function(index,tick){
                if(index!=0)
                {
                    var x = chart.yAxis[0].ticks[index].label.xy.x - chart.yAxis[0].ticks[index].label.textPxLength - 3,
                        y = chart.yAxis[0].ticks[index].label.xy.y + ((chart.yAxis[0].ticks[0].label.xy.y - chart.yAxis[0].ticks[index].label.xy.y) * 2);
                    chart.renderer.label(index+"%",x,y,'rect',null,null,false,true)
                    .attr({
                        zIndex: 4
                    })
                    .css({
                        fontSize: '11px',
                        color: "#606060"
                    })
                    .add();    
                }    
            });
        }  
    });
}  


function toRadians(angle) 
{
  return angle * (Math.PI / 180);
}


function noteToColor(note)    
{
    if(note<10)
        return "#FF0000";
    else if(note<20)
        return "#FF4210";
    else if(note<30)
        return "#FF781E";
    else if(note<40)
        return "#FFA228";
    else if(note<50)
        return "#FFC830";
    else if(note<60)
        return "#E9D32F";
    else if(note<70)
        return "#C0CE28";
    else if(note<80)
        return "#7DB71B";
    else if(note<90)
        return "#4AA110";
    else
        return "#008200";
} 


function addRadialLevels(inChart,series,color,type) 
{
    var aPath = [],
        iDecalage = 0,
        iNbNotes = series.length,
        iCenterX = inChart.yAxis[0].getLinePath()[1],
        iCenterY = inChart.yAxis[0].getLinePath()[2],
        iRadius = Math.sqrt(Math.pow(inChart.yAxis[0].getLinePath()[1]-inChart.yAxis[0].getLinePath()[4],2)+ Math.pow(inChart.yAxis[0].getLinePath()[2]-inChart.yAxis[0].getLinePath()[5],2));
    
    if(typeof(inChart.userOptions.pane)!=="undefined")
        iDecalage = inChart.userOptions.pane.startAngle;
        
    $.each(series,function(index,value){
        inChart.renderer.arc(iCenterX,iCenterY,iRadius*value[1]/100,iRadius*value[1]/100,(-Math.PI/2)+toRadians(iDecalage)+(index*(2*Math.PI/iNbNotes)),(-Math.PI/2)+toRadians(iDecalage)+((index+1)*(2*Math.PI/iNbNotes)))
        .attr({
            "class": type+"_level",
            stroke: color,
            'stroke-width': 2,
            zIndex: 5
        })
        .add();
    });
}


function drawGraphNota25(codeZB,inDiv,aTrads,isAsync)
{
    (function(H) {
        H.wrap(H.Legend.prototype, 'colorizeItem', function(proceed, item, visible) {
            var color = item.color;
            item.color = item.options.legendColor;
            proceed.apply(this, Array.prototype.slice.call(arguments, 1));
            item.color = color;
        });
    }(Highcharts));

    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    
    var chart25;
    
    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : 'nota_25'},
        type : 'GET'
    })
    .done(function(data){  
        try{
            dataChart = JSON.parse(data)    
        } catch(e){                              
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
        
        dataVal = [];
        $.each(dataChart[0][1],function(index,val)
        {             
            dataVal.push({name: val[0],y: val[1], color: noteToColor(val[1])})
        });
        
        var options = {       
            chart: {   
                marginLeft: 40,
                marginRight: 40,
                marginTop: 40,
                marginBottom: 50,
                polar: true,
                type: 'column',
                spacingBottom: 0
            },
            
            credits: {
                enabled: false
            },
            
            legend: {
                itemStyle: {
                    fontWeight: "normal"
                }
            }, 
            
            pane: {
                startAngle: -36 
            },
            
            plotOptions: {
                column: {
                    grouping: false,
                    groupPadding: 0,
                    pointPadding: 0
                }    
            }, 
            
            responsive : {
                rules: [{
                    chartOptions: {
                        chart: {
                            marginBottom : 80
                        }
                    },
                    condition: {
                        maxWidth: 560
                    }    
                }]       
            }, 

            series: [{  
                name: dataChart[0][0], 
                color: "grey", 
                data : dataVal,
                zIndex: 1,
                tooltip: {
                    pointFormat: "<tspan style='color:{series.color};'>&#9679;</tspan> {series.name}: <b>{point.y}</b><br>"
                },
            }],
            
            title: {
                text: ""
            }, 
            
            tooltip: {
                shared: true,
                split: false,
                valueDecimals: 2,
                valueSuffix: "%",
                useHTML: true   
            },
            
            xAxis: {
                gridZIndex: 5,  
                labels: {
                    align: "center",
                    distance: 30,
                    style:{
                        color: "black",
                        fontSize: "9px",
                        textShadow: "white"
                    }
                }, 
                lineColor: "black",
                type: "category",
                zIndex: 6               
            },

            yAxis: {
                endOnTick: true,
                gridZIndex: 5,
                labels: {
                    enabled: false
                },        
                lineWidth: 0,
                max: 100,
                min: 0, 
                showLastLabel: true,   
                tickInterval: 10,
                zIndex: 4
            }  
        };    
        
        chart25 = Highcharts.chart(inDiv,options);      
                
        var centerX = chart25.plotBox.x+(chart25.plotBox.width/2),
            centerY = chart25.plotBox.y+(chart25.plotBox.height/2),
            length = centerY-chart25.plotBox.y;
        
        chart25.renderer.path(
            ['M', centerX, centerY,
            "l", length*Math.cos(toRadians(54)), -length*Math.sin(toRadians(54)), 
            'M', centerX, centerY,
            "l", length*Math.cos(toRadians(126)), -length*Math.sin(toRadians(126)),
            'M', centerX, centerY,
            "l", length*Math.cos(toRadians(198)), -length*Math.sin(toRadians(198)),
            'M', centerX, centerY,
            "l", length*Math.cos(toRadians(270)), -length*Math.sin(toRadians(270)),
            'M', centerX, centerY,
            "l", length*Math.cos(toRadians(342)), -length*Math.sin(toRadians(342))]
        ).attr({ 
            'stroke-width': 2,
            stroke: 'black',
            zIndex: 6}
        ).add();
         
        chart25.renderer.text(
            aTrads[0],
            centerX+(1.08*length*Math.cos(toRadians(90))),
            centerY-(1.08*length*Math.sin(toRadians(90)))
        )
        .attr({
            align: "center",
            style: "font-weight: bold; font-size: 12px;"
        })
        .add();
        
        chart25.renderer.text(
            aTrads[1],
            centerX+(1.1*length*Math.cos(toRadians(18))),
            centerY-(1.1*length*Math.sin(toRadians(18)))
        )
        .attr({
            rotation: 72,
            align: "center",
            style: "font-weight: bold; font-size: 12px;"
        })
        .add();
        
        chart25.renderer.text(
            aTrads[2],
            centerX+(1.15*length*Math.cos(toRadians(306))),
            centerY-(1.15*length*Math.sin(toRadians(306)))
        )
        .attr({
            rotation: -36,
            align: "center",
            style: "font-weight: bold; font-size: 12px;"
        })
        .add();
        
        chart25.renderer.text(
            aTrads[3],
            centerX+(1.15*length*Math.cos(toRadians(234))),
            centerY-(1.15*length*Math.sin(toRadians(234)))
        )
        .attr({
            rotation: 36,
            align: "center",
            style: "font-weight: bold; font-size: 12px;"
        })
        .add();
        
        chart25.renderer.text(
            aTrads[4],
            centerX+(1.1*length*Math.cos(toRadians(162))),
            centerY-(1.1*length*Math.sin(toRadians(162)))
        )
        .attr({
            rotation: -72,
            align: "center",
            style: "font-weight: bold; font-size: 12px;"
        })
        .add();
        
        if(dataChart[1].length>0)
        {
            chart25.addSeries(
            {   
                colorByPoint: true,
                colors: ["transparent"],  
                data: dataChart[1][1],
                events: {
                    legendItemClick: function(){
                        var styleCSS = this.visible ? "none" : "";
                        $.each($(".secteur_level"),function(index,item){ 
                            $(item).css("display",styleCSS);    
                        });
                    }  
                },
                legendColor: "#004EFF",
                name: dataChart[1][0],
                tooltip: {
                    pointFormat: "<tspan style='color:#004EFF;'>&#9679;</tspan> {series.name}: <b>{point.y}</b><br>"
                },
                zIndex: 3 
            });
            addRadialLevels(chart25,dataChart[1][1],"#004EFF","secteur");
        }
        
        if(dataChart[2].length>0)
        {
            chart25.addSeries({   
                colorByPoint: true,
                colors: ["transparent"], 
                data: dataChart[2][1],
                events: {
                    legendItemClick: function(){
                        var styleCSS = this.visible ? "none" : "";
                        $.each($(".pays_level"),function(index,item){ 
                            $(item).css("display",styleCSS);    
                        });
                    }  
                },
                legendColor: "#B12CFF",
                name: dataChart[2][0], 
                tooltip: {
                    pointFormat: "<tspan style='color:#B12CFF;'>&#9679;</tspan> {series.name}: <b>{point.y}</b><br>"
                },
                zIndex: 3 
            });                                                         
            addRadialLevels(chart25,dataChart[2][1],"#B12CFF","pays");
        }                                                                            
    });    
} 


function drawGraphCompNota25(aCodeZB,inDiv,aTrads,isAsync)
{
    //Retrieve language
    iLang = (typeof iLang === "undefined") ? null : iLang;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    
    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {aCodeZB : aCodeZB, t : 'comp_nota_25', iLang: iLang},
        type : 'GET'
    })
    .done(function(data){

        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }     
        
        var options = {
            chart: {          
                marginTop: 40,
                polar: true,
                spacingLeft: 20,
                spacingRight: 20
            }, 
            
            colors : ["#ff3000","#F2943E","#ffae00","#33d251","#16a8ec","#9644c5","#81F7BE"],
            
            credits: {
                enabled: false
            },
            
            legend: {
                enabled: true,
                layout: "vertical"
            },     
            
            pane: {               
                startAngle: -28.8     
            },
            
            plotOptions: {
                line: {
                    tooltip:{
                        valueDecimals: 0,
                        valueSuffix: "%"
                    },
                    states:{
                        hover:{
                            lineWidthPlus: 0
                        }
                    }
                }
            },  
            
            series: [],

            title: {
                text: ''
            },  
            
            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                footerFormat: "</table>",
                headerFormat: "<table style='min-width: 220px; white-space: nowrap;'><tr><td colspan='2'><b>{point.key}</b></td></tr>",
                pointFormat: "<tr><td><span style=\"color:{series.color}\">&#9679;</span>&nbsp;{series.name} : </td><td style='text-align: right;'>{point.y:.2f}%</td></tr>",
                useHTML: true, 
                shared: true
            },                                                                                                                        
                                        
            xAxis: [{
                gridZIndex: 1,  
                labels: {
                    align: "center",
                    distance: 30,
                    style:{
                        color: "black",
                        fontSize: "9px",
                        textShadow: "white"
                    }
                }, 
                lineColor: "black",
                type: "category",
                zIndex: 2
            }],
            
            yAxis: {
                endOnTick: true,
                gridZIndex: 1,
                labels: {
                    enabled: false
                },        
                lineWidth: 0,
                max: 100,
                min: 0, 
                showLastLabel: true,   
                tickInterval: 10,
                zIndex: 1
            }
        };
        
        $.each(dataChart[0],function(index,dataSeries)
        {
            options.series.push({
                data: dataSeries[1],
                legendIndex: index,
                lineWidth: 2,                     
                marker: {
                    enabled: false
                },
                name: dataSeries[0], 
                pointPlacement: "on",
                type: 'line',         
                zIndex: dataChart[0].length-index
            });
        });      
        
        var chart25 = new Highcharts.Chart(inDiv,options); 
        
        var centerX = chart25.plotBox.x+(chart25.plotBox.width/2),
            centerY = chart25.plotBox.y+(chart25.plotBox.height/2),
            length = centerY-chart25.plotBox.y;
        
        chart25.renderer.path(
            ['M', centerX, centerY,
            "l", length*Math.cos(toRadians(54)), -length*Math.sin(toRadians(54)), 
            'M', centerX, centerY,
            "l", length*Math.cos(toRadians(126)), -length*Math.sin(toRadians(126)),
            'M', centerX, centerY,
            "l", length*Math.cos(toRadians(198)), -length*Math.sin(toRadians(198)),
            'M', centerX, centerY,
            "l", length*Math.cos(toRadians(270)), -length*Math.sin(toRadians(270)),
            'M', centerX, centerY,
            "l", length*Math.cos(toRadians(342)), -length*Math.sin(toRadians(342))]
        ).attr({ 
            'stroke-width': 2,
            stroke: 'black',
            zIndex: 6}
        ).add();
         
        chart25.renderer.text(
            aTrads[0],
            centerX+(1.08*length*Math.cos(toRadians(90))),
            centerY-(1.08*length*Math.sin(toRadians(90)))
        )
        .attr({
            align: "center",
            style: "font-weight: bold; font-size: 12px;"
        })
        .add();
        
        chart25.renderer.text(
            aTrads[1],
            centerX+(1.1*length*Math.cos(toRadians(18))),
            centerY-(1.1*length*Math.sin(toRadians(18)))
        )
        .attr({
            rotation: 72,
            align: "center",
            style: "font-weight: bold; font-size: 12px;"
        })
        .add();
        
        chart25.renderer.text(
            aTrads[2],
            centerX+(1.15*length*Math.cos(toRadians(306))),
            centerY-(1.15*length*Math.sin(toRadians(306)))
        )
        .attr({
            rotation: -36,
            align: "center",
            style: "font-weight: bold; font-size: 12px;"
        })
        .add();
        
        chart25.renderer.text(
            aTrads[3],
            centerX+(1.15*length*Math.cos(toRadians(234))),
            centerY-(1.15*length*Math.sin(toRadians(234)))
        )
        .attr({
            rotation: 36,
            align: "center",
            style: "font-weight: bold; font-size: 12px;"
        })
        .add();
        
        chart25.renderer.text(
            aTrads[4],
            centerX+(1.1*length*Math.cos(toRadians(162))),
            centerY-(1.1*length*Math.sin(toRadians(162)))
        )
        .attr({
            rotation: -72,
            align: "center",
            style: "font-weight: bold; font-size: 12px;"
        })
        .add();
    });
}


function drawGraphNotaESG(codeZB,inDiv,isAsync)
{
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    
    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : 'nota_esg'},
        type : 'GET'
    })
    .done(function(data){  
        try{
            dataChart = JSON.parse(data)    
        } catch(e){                              
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
    });  
    
    var chart = Highcharts.chart(inDiv,
    { 
        credits: {
            enabled: false
        },   
        
        series: [{  
            allowDrillToNode: false,
            borderColor: "white",  
            borderWidth: 3,  
            data: dataChart,
            dataLabels: {                        
                style: {                      
                    color: "black",    
                    strokeWidth: "2",  
                    textOutline: "rgba(255,255,255,.5)", 
                    textOverflow: "wordwrap"
                }

            },
            levels: [
                {
                    dataLabels: {
                        style: {
                            fontSize: "24px"
                        }        
                    },
                    level: 1,
                    levelSize: {
                        unit: 'percentage',
                        value: 28
                    } 
                },{
                    dataLabels: {    
                        style: {
                            fontSize: "14px"
                        }       
                    },
                    level: 2,
                    levelSize: {
                        unit: 'percentage',
                        value: 30
                    }
                },{
                    dataLabels: {             
                        style: {
                            fontSize: "11px"
                        }        
                    },
                    level: 3
                }
            ],
            slicedOffset: 10,
            startAngle: -45,
            states: {
                hover: {
                    enabled: false    
                }
            },
            tooltip: {
                pointFormat : "<b>{point.name}</b> : {point.note} <i>({point.note_value:.2f}%)</i>"  
            },
            type: "sunburst" 
        }],
        
        title: {
            text: ""
        }          
    });   
}


function drawGraphNota25Pond(aCodeZB,aBenchmark,inDiv,ponderation,aWords,isAsync)
{
    ponderation = (typeof ponderation === "undefined") ? 0 : ponderation;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    
    $.ajax({url : URL_SERVEUR+'afDataFeed.php',  
        async : isAsync,
        crossDomain: true,
        data : {aCodeZB : aCodeZB, aComparaison : aBenchmark, t : 'nota_25_pond', p : ponderation},
        type : 'GET'
    })
    .done(function(data){  
        try{
            dataChart = JSON.parse(data)    
        } catch(e){                              
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }  
    
        var options = 
        {
            chart: {          
                marginTop: 40,
                marginBottom: 55,
                polar: true,
                spacingLeft: 0,
                spacingRight: 0
            },
                
            credits: {
                enabled: false
            },
            
            legend: {
                enabled: true
            },
            
            pane: {               
                startAngle: -28.8     
            },
            
            plotOptions: {
                line: {
                    tooltip:{
                        valueDecimals: 0,
                        valueSuffix: "%"
                    },
                    states:{
                        hover:{
                            lineWidthPlus: 0
                        }
                    }
                }
            },   
            
            series: [{
                type: 'line',
                lineWidth: 3,
                name: aWords[0],
                marker: {
                    enabled: false
                },
                pointPlacement: "on",
                data: dataChart[0],
                zIndex: 4
            }],
               
            title: {
                text: ''
            }, 
            
            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,
                footerFormat: "</table>",
                headerFormat: "<table style='min-width: 220px; white-space: nowrap;'><tr><td colspan='2'><b>{point.key}</b></td></tr>",
                pointFormat: "<tr><td><span style=\"color:{series.color}\">&#9679;</span>&nbsp;{series.name} : </td><td style='text-align: right;'>{point.y:.2f}%</td></tr>",
                useHTML: true, 
                shared: true
            },                                                                                                                        
                                        
            xAxis: [{
                categories: aWords[1],
                gridZIndex: 1,  
                labels: {
                    align: "center",
                    distance: 30,
                    style:{
                        color: "black",
                        fontSize: "9px",
                        textShadow: "white"
                    }
                }, 
                lineColor: "black",
                zIndex: 2
            }],
            
            yAxis: {
                endOnTick: true,
                gridZIndex: 1,
                labels: {
                    enabled: false
                },        
                lineWidth: 0,
                max: 100,
                min: 0, 
                showLastLabel: true,   
                tickInterval: 10,
                zIndex: 1
            }
        };
        
        if(dataChart[1].length > 0)
        {
            $.each(dataChart[1],function(index,aCompData){
                options.series.push(
                {
                    type: 'line',
                    lineWidth: 2,
                    name: aCompData[0],
                    marker: {
                        enabled: false
                    },
                    pointPlacement: "on",
                    data: aCompData[1],
                    zIndex: 3    
                });
            })
        }
        
        $("#"+inDiv).highcharts(options);
        
        var chart = $("#"+inDiv).highcharts();
        
        var centerX = chart.plotBox.x+(chart.plotBox.width/2),
            centerY = chart.plotBox.y+(chart.plotBox.height/2),
            length = centerY-chart.plotBox.y;
        
        chart.renderer.path(
            ['M', centerX, centerY,
            "l", length*Math.cos(toRadians(54)), -length*Math.sin(toRadians(54)), 
            'M', centerX, centerY,
            "l", length*Math.cos(toRadians(126)), -length*Math.sin(toRadians(126)),
            'M', centerX, centerY,
            "l", length*Math.cos(toRadians(198)), -length*Math.sin(toRadians(198)),
            'M', centerX, centerY,
            "l", length*Math.cos(toRadians(270)), -length*Math.sin(toRadians(270)),
            'M', centerX, centerY,
            "l", length*Math.cos(toRadians(342)), -length*Math.sin(toRadians(342))]
        ).attr({ 
            'stroke-width': 2,
            stroke: 'black',
            zIndex: 6}
        ).add();
         
        chart.renderer.text(
            aWords[2][0],
            centerX+(1.08*length*Math.cos(toRadians(90))),
            centerY-(1.08*length*Math.sin(toRadians(90)))
        )
        .attr({
            align: "center",
            style: "font-weight: bold; font-size: 12px;"
        })
        .add();
        
        chart.renderer.text(
            aWords[2][1],
            centerX+(1.1*length*Math.cos(toRadians(18))),
            centerY-(1.1*length*Math.sin(toRadians(18)))
        )
        .attr({
            rotation: 72,
            align: "center",
            style: "font-weight: bold; font-size: 12px;"
        })
        .add();
        
        chart.renderer.text(
            aWords[2][2],
            centerX+(1.15*length*Math.cos(toRadians(306))),
            centerY-(1.15*length*Math.sin(toRadians(306)))
        )
        .attr({
            rotation: -36,
            align: "center",
            style: "font-weight: bold; font-size: 12px;"
        })
        .add();
        
        chart.renderer.text(
            aWords[2][3],
            centerX+(1.15*length*Math.cos(toRadians(234))),
            centerY-(1.15*length*Math.sin(toRadians(234)))
        )
        .attr({
            rotation: 36,
            align: "center",
            style: "font-weight: bold; font-size: 12px;"
        })
        .add();
        
        chart.renderer.text(
            aWords[2][4],
            centerX+(1.1*length*Math.cos(toRadians(162))),
            centerY-(1.1*length*Math.sin(toRadians(162)))
        )
        .attr({
            rotation: -72,
            align: "center",
            style: "font-weight: bold; font-size: 12px;"
        })
        .add();  
    });  
}


function drawGraphESGPond(aCodeZB,inDiv,sTooltipTerm,bShowValue,ponderation,isAsync)
{
    ponderation = (typeof ponderation === "undefined") ? 0 : ponderation;
    bShowValue = (typeof bShowValue === "undefined") ? false : bShowValue;
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    
    $.ajax({url : URL_SERVEUR+'afDataFeed.php',  
        async : isAsync,
        crossDomain: true,
        data : {aCodeZB : aCodeZB, t : 'rep_notes_esg_pond', p : ponderation, bShowValue: bShowValue},
        type : 'GET'
    })
    .done(function(data){  
        try{
            dataChart = JSON.parse(data)    
        } catch(e){                              
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }  
        
        $('#'+inDiv).highcharts({
            chart: {
                marginTop: 0,
                marginBottom: 0
            },
            
            title: {
                text: ''
            },
            
            credits: {
                enabled: false
            },
            
            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderRadius: 5    ,
                borderWidth: 1,
                headerFormat: "",
                pointFormatter: function()
                {
                    var sName = "",
                        fPcInvest = 0;
                    
                    if (this.node.level == 1)
                    {
                        sName = this.custom;   
                        fPcInvest = this.pc_invest;
                    }
                    else
                    {
                        sName = this.name;
                        fPcInvest = this.value;
                    }     
                    return "<table style='min-width: 220px; white-space: nowrap;'><tr><td colspan='2'><b>"+sName+"</b></td></tr><tr><td>"+sTooltipTerm+" : </td><td style='text-align: right;'>"+fPcInvest.toFixed(2)+" %</td></tr><tr><td>ESG : </td><td style='text-align: right;'>"+this.rating+"</b></td></tr></table>"
                },
                useHTML: true,
                style: {
                    pointerEvents: 'auto'
                }
            },  
            
            series: [{
                allowDrillToNode: true,
                data: dataChart,      
                levels: [
                    {
                        level: 1,
                        dataLabels: {
                            style: {
                                fontSize: "24px"
                            },   
                        },
                        levelSize: {
                            unit: "percentage",
                            value: bShowValue ? 25 : 40
                        } 
                    },
                    {
                        level: 2,
                        dataLabels: {
                            style: {
                                fontSize: "16px"
                            },   
                        },
                        levelSize: {
                            unit: "percentage",
                            value: bShowValue ? 25 : 60
                        }
                    },
                    {
                        level: 3,  
                        levelSize: {
                            unit: "percentage",
                            value: bShowValue ? 50 : 0
                        } 
                    }
                ],
                type: 'sunburst'
            }]
        }); 
    });  
}

function drawGraphHeatmapPeriod(codeZB,inDiv,aTrads,isAsync)
{
    function getPointCategoryName(point, dimension) {
        var series = point.series,
            isY = dimension === 'y',
            axis = series[isY ? 'yAxis' : 'xAxis'];
        return axis.categories[point[isY ? 'y' : 'x']];
    }
    
    isAsync = (typeof isAsync === "undefined") ? true : isAsync;
    
    $.ajax({url : URL_SERVEUR+'afDataFeed.php',
        context : document.body,
        async : isAsync,
        data : {codeZB : codeZB, t : 'hm_period'},
        type : 'GET'
    })
    .done(function(data)
    {
        try{
            dataChart = JSON.parse(data)    
        } catch(e){
            $('#'+inDiv).css('display','none');
            console.log("erreur JSON parse : "+e);
            console.log("data received : "+data);
            return;
        }
        var aData = dataChart[0];        
        var aYearsCategories = dataChart[1];
        var fValMax = null;
        var sSeriesName = aTrads.shift(); 
        
        $.each(aData,function(i,aPoint){
            if(fValMax == null || aPoint[2]>fValMax)
                fValMax = aPoint[2];       
        });
        fValMax = Math.abs(fValMax);
        fValMin = -fValMax;
        
        var chart = Highcharts.chart(inDiv,
        { 
            chart: {
                inverted: true,
                marginBottom: 1,  
                marginRight: 1,  
                plotBorderColor: "#EEEEEE",
                plotBorderWidth: 1,
                spacingBottom: 0,
                type: 'heatmap'
            },
            
            colorAxis: {
                endOnTick: false,
                labels: {
                    format: '{value}%'
                },
                min: fValMin,
                max: fValMax,
                startOnTick: false,       
                stops: [
                    [0, '#ff0000'],
                    [0.5, '#444444'],
                    [1, '#00ff00']
                ] 
            },
            
            credits: {
                enabled: false
            },
            
            legend: 
            {
                enabled: false
            },    
            
            series : [{
                borderColor: "black",
                borderWidth: 1,
                data: aData        ,
                name : sSeriesName
            }],
            
            title: {
                text: ""
            },
            
            tooltip: {
                backgroundColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, 'white'],
                        [1, '#EEE']
                    ]
                },
                borderColor: 'gray',
                borderWidth: 1,
                borderRadius: 5,  
                formatter: function () {
                    var sColor = this.point.value>0 ? "#008000" : "#CC0000";
                    return '<b>'+this.series.name+'</b><br>'+
                           getPointCategoryName(this.point, 'x')+' '+getPointCategoryName(this.point, 'y')+' : <span style="color:'+sColor+';">'+this.point.value+'%';
                }                           
            },
            
            xAxis:{
                categories: aTrads,
                gridLineColor: "#EEEEEE",
                gridLineWidth: 1,           
                labels: 
                {
                    style : {
                        color: aMainStyle.yAxisLabelColor,
                        fontSize: aMainStyle.fontSize1
                    }    
                },
                lineWidth: 0,
                tickWidth: 0
            }, 
            
            yAxis:{
                categories: aYearsCategories,
                gridLineColor: "#EEEEEE",
                gridLineWidth: 1,          
                labels: 
                {
                    rotation: -90,
                    style : {
                        color: aMainStyle.xAxisLabelColor,
                        fontSize: aMainStyle.fontSize1,
                        fontWeight: aMainStyle.xAxisLabelWeight                            
                    }
                },
                opposite: true,
                reversed: true,       
                title: null
            }
        });     
    });
}