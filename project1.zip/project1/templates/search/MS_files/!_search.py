import os
import codecs

# traverse root directory, and list directories as dirs and files as files
for root, dirs, files in os.walk("."):
    for file in files:
        try:
            fileObj = codecs.open(file, 'rb', 'utf_8_sig')
            text = fileObj.read()
            if text.__contains__('navigateTable'):
                print(file)
            fileObj.close()
        except UnicodeDecodeError as e:
            # print(e)
            # print(file)
            continue
