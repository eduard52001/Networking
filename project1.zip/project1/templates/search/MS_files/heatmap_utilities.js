function calcAverageAndStandardDeviation(aData,field)
{
    if(aData.length==0)
        return [0,0];
        
    //calculer moyenne
    var somme = 0;
    
    $.each(aData,function(i,data)
    {
        somme+=data[field];
    });
    
    var moy = somme/aData.length;
    
    somme = 0;
    
    $.each(aData,function(i,data)
    {
        somme+= Math.pow(data[field]-moy,2);
    });
    
    fEt = Math.sqrt(somme/aData.length);

    return [moy,fEt];
}

function filterByStandardDeviation(series,field,threshold)
{
    var xMin = xMax = null,
        fEt = 0,
        prevfEt = null,
        currentList = [],
        prevList = series.slice();
    
    do
    {
        if(xMin==null) 
            currentList = prevList.slice();
        else
        {
            prevfEt = fEt; 
            prevList = currentList.slice(); 
            currentList = [];
            
            $.each(prevList,function(i,elmnt)
            {
                if(elmnt[field]>=xMin && elmnt[field]<=xMax)
                    currentList.push(elmnt);     
            });    
        }
        
        var aRes = calcAverageAndStandardDeviation(currentList,field),
            fMoy = aRes[0];
        
        fEt = aRes[1];
        xMin = fMoy - 1.96*fEt;
        xMax = fMoy + 1.96*fEt;
    }
    while(currentList.length>2 && (prevfEt==null || (Math.abs(fEt-prevfEt)/prevfEt)>threshold));
    
    return prevList;
}

function calculateHeatmapColorExtrems(series,field)
{
    var significativeList = filterByStandardDeviation(series,field,0.1);
    
    fValMax = null;
        
    $.each(significativeList,function(i,aPoint){   
        if(fValMax == null || Math.abs(aPoint[field])>fValMax)
            fValMax = Math.abs(aPoint[field]);       
    });                 
    fValMin = -fValMax;
    
    return [fValMin,fValMax];
}