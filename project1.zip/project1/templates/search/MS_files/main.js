
function popup_aide(page)         {
  var part_argument = "";
  if(popup_aide.arguments.length > 1) {
         part_argument = "&part="+popup_aide.arguments[1];
  }
  new_window = open("/modes/aide.php?page="+page+part_argument,"_blank",
              "width=700,height=600,scrollbars=yes,resizable=yes,left="+(screen.availWidth/2-200)+",top=50");
  new_window.focus();
}

function eTrackSS_Z4(idTrack)
{
 var eTrackSS_Z4i;
 var eTrackSS_Z4g;
 var eTrackSS_Z4l;
 
 if (idTrack==null)
 {
  eTrackSS_Z4i = true;
  eTrackSS_Z4g = false;
  eTrackSS_Z4l = true;
 }
 else if (idTrack==0)
 {
  eTrackSS_Z4i = false;
  eTrackSS_Z4g = false;
  eTrackSS_Z4l = true;
 }
 else
 {
  eTrackSS_Z4i = 60;
  eTrackSS_Z4g = 1000;
  eTrackSS_Z4l = false;
  return SetCookieValbg(idTrack,eTrackSS_Z4i,eTrackSS_Z4g,eTrackSS_Z4l);
 }
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}

function plein_ecran() {
 window.location='/graphique-dynamique/'; 
 /*if(self.name == "popup") self.close();
 url = "/gauchefiche.php?codezb=4941&applet_mode=dynamique";
 new_window = open(url,"_blank", "scrollbars=yes,menubar=no,location=no,resizable=yes,titlebar=yes");
 new_window.focus();*/
}

var aValue = new Array();


////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////   outils de position   //////////////////////////////////////////////////// 
////////////////////////////////////////////////////////////////////////////////////////////////////////
function findPosMX(obj)
{
    var curleft = 0;
    if (obj.offsetParent)
    {
        while (obj.offsetParent)
        {
            curleft += obj.offsetLeft;
            obj = obj.offsetParent;
        }
    }
    else if (obj.x)
        curleft += obj.x;
    if (navigator.appName != "Microsoft Internet Explorer")
     curleft -= 1;
    //curleft += MenuLarge; 
    return curleft;
}

function findPosMY(obj)
{
    var curtop = 0;
    if (obj.offsetParent)
    {
        while (obj.offsetParent)
        {
            curtop += obj.offsetTop
            obj = obj.offsetParent;
        }
    }
    else if (obj.y)
        curtop += obj.y;
    if (navigator.appName != "Microsoft Internet Explorer")
     curtop -= 1;    
    return curtop;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////// MODULE DE GESTION PUB  //////////////////////////////////////////////////// 
//////////////////////////////////////////////////////////////////////////////////////////////////////// 
var iframeids=["Middle2_id","StockIframePositionner"]

//Should script hide iframe from browsers that don't support this script (non IE5+/NS6+ browsers. Recommended):
var iframehide="no"

var getFFVersion=navigator.userAgent.substring(navigator.userAgent.indexOf("Firefox")).split("/")[1]
var FFextraHeight=parseFloat(getFFVersion)>=0.1? /*16*/0 : 0 //extra height in px to add to iframe in FireFox 1.0+ browsers

function resizeCaller() {
var dyniframe=new Array()
for (i=0; i<iframeids.length; i++){
if (document.getElementById)
resizeIframe(iframeids[i])
//reveal iframe for lower end browsers? (see var above):
if ((document.all || document.getElementById) && iframehide=="no"){
var tempobj=document.all? document.all[iframeids[i]] : document.getElementById(iframeids[i])
if (tempobj)
 tempobj.style.display="block"
}
}
}

function resizeIframe(frameid){
//alert("Resize:"+frameid);
var currentfr=window.parent.document.getElementById(frameid)
if (currentfr)
{
if (currentfr && !window.opera){
currentfr.style.display="block"
if (currentfr.contentDocument && currentfr.contentDocument.body.offsetHeight) //ns6 syntax
currentfr.height = currentfr.contentDocument.body.offsetHeight+FFextraHeight; 
else if (currentfr.Document && currentfr.Document.body.scrollHeight) //ie5+ syntax
currentfr.height = currentfr.Document.body.scrollHeight;
if (currentfr.addEventListener)
currentfr.addEventListener("load", readjustIframe, false)
else if (currentfr.attachEvent){
currentfr.detachEvent("onload", readjustIframe) // Bug fix line
currentfr.attachEvent("onload", readjustIframe)
}
}
}

}

function readjustIframe(loadevt) {
var crossevt=(window.event)? event : loadevt
var iframeroot=(crossevt.currentTarget)? crossevt.currentTarget : crossevt.srcElement
if (iframeroot)
resizeIframe(iframeroot.id);
}

function loadintoIframe(iframeid, url){
if (document.getElementById)
document.getElementById(iframeid).src=url
}

var getDocumentHeight = function()
{
 if (document.body.scrollHeight)
 return document.body.scrollHeight;
 return document.documentElement.offsetHeight;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////
var iSelectImgHLast = 0;
function SelectImgH(line)
{
    try {
        var nGraph = document.getElementById("hIntraG"+line);
        var oGraph = document.getElementById("hIntraG"+iSelectImgHLast);
        var nLine = document.getElementById("hIntraD"+line);
        var oLine = document.getElementById("hIntraD"+iSelectImgHLast);
        oGraph.style.display = 'none'
        nGraph.style.display = '';
        oLine.style.backgroundColor = "";
        nLine.style.backgroundColor = "#EEEEEE";
        //oLine.style.fontWeight = "normal";
        //nLine.style.fontWeight = "bold";
    }
    catch(err)
    {
        //alert(err);
    }
    iSelectImgHLast = line;
}
           
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////    MODULE INFO VALEUR  //////////////////////////////////////////////////// 
////////////////////////////////////////////////////////////////////////////////////////////////////////
var IdSelectBlock;
var BgColorSelectBlock;
var TimeoutSetBlock;
var TimeoutLoadBlock; 
var MyElementInfobul;

function windowPos()
{
 if (window.innerHeight) return window.innerHeight + window.pageYOffset ;
 else if (document.body && document.body.offsetHeight) return document.body.offsetHeight + document.body.scrollTop;
 else return 0;
}

function shInfBul(x,y,idParent,codezb)
{
 window.clearTimeout(TimeoutSetBlock);                 
  
 var MyElement = document.getElementById("StockDivPositionner");
 var MyElementParent = document.getElementById(idParent);
 
 if(IdSelectBlock == MyElementParent)
    return false;
    
 if (IdSelectBlock)
    IdSelectBlock.style.backgroundColor = BgColorSelectBlock;
 
 MyElementInfobul = MyElement;
 
 XDiv=findPosMX(MyElementParent); 
  
 MyElement.style.left = (XDiv-10)+"px";
 majInfoB(codezb,1);
 var type = "under";                         

  
 BgColorSelectBlock = MyElementParent.style.backgroundColor;
 IdSelectBlock = MyElementParent;
 MyElementParent.style.backgroundColor = '#C0C0C0';
 

    $('#StockDivPositionner')
        .detach()
        .css("z-index", "10")
        .css("position", "absolute")
        .css("top", "inherit")
        .insertAfter($("#"+idParent+" a"))
        ;
}

function autoHideInfBul()
{ 
 if (IdSelectBlock)
  IdSelectBlock.style.backgroundColor = BgColorSelectBlock;
 document.getElementById("StockDivPositionner").style.display = "none"; 
}

function HideInfoBul()
{
    TimeoutSetBlock = window.setTimeout("autoHideInfBul()", 1000);    
}

function NoHideInfoBul()
{
 window.clearTimeout(TimeoutSetBlock);    
}


var url = "/mods_a/charts/info.php?codezb=";
var url2 = "/mods_a/charts/scan.php?codezb=";
var scanCodeZB = 0;
var http = getHTTPObject();   


function majInfoB(codezb,method) {
  var args = arguments;
  window.clearTimeout(TimeoutLoadBlock); 
  document.getElementById("StockDivPositionner").innerHTML = "";
  if (http.readyState == 4 || http.readyState == 0)
  {
   var MyHttpLink = url + codezb + "&s=" + method;
   if (args.length>2)
    MyHttpLink += "&liste=" + args[2];
   http.open("GET", MyHttpLink, true);
   http.onreadystatechange = handleHttpResponse;
   http.send(null);
  }
  else
  {
   TimeoutLoadBlock = window.setTimeout("majInfoB("+codezb+","+method+")", 100); 
  }
}  

function majZBScan(codezb,supplink) {
  var args = arguments;
  //document.getElementById("StockZBScan").innerHTML = "";
  //alert(args[1]);
  if (scanCodeZB==codezb)
   return;
  if (http.readyState == 4 || http.readyState == 0)
  {
   var MyHttpLink = url2 + codezb;
   MyHttpLink += "&supplink=" + args[1];
   http.open("GET", MyHttpLink, true);
   http.onreadystatechange = handleHttpResZBS;
   http.send(null);
   scanCodeZB=codezb; 
  }
  else
  {
   window.clearTimeout(TimeoutLoadBlock)
   TimeoutLoadBlock = window.setTimeout("majZBScan('"+codezb+"','"+supplink+"')", 100); 
  }
}

function handleHttpResponse() {
  var sResp;
  
  if (http.readyState == 4 && http.status == 200) {  
    sResp = http.responseText;
    document.getElementById("StockDivPositionner").innerHTML = sResp;
    MyElementInfobul.style.display="block";  
  }
}

function handleHttpResZBS() {
  var sResp;
  
  if (http.readyState == 4 && http.status == 200) {  
    sResp = http.responseText;
    document.getElementById("StockZBScan").innerHTML = sResp;
  }
}

function getHTTPObject() {
  var xmlhttp;
  
  if (!xmlhttp)
  {
   if(window.XMLHttpRequest) { // Firefox  
    xmlhttp = new XMLHttpRequest(); 
   } 
   else { 
    if(window.ActiveXObject) { // Internet Explorer   
     try { 
      xmlhttp = new ActiveXObject("Msxml2.XMLHTTP"); 
     } catch (e) { 
      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); 
     } 
    }
   }
  } 
  
  
  
/*  if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
    try {
      xmlhttp = new XMLHttpRequest();
      } catch (e) {
      xmlhttp = false;
      }
    }    */
  return xmlhttp;
}



function getHTTPObjectLimited() {
  var xmlhttp;

  if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
    try {
      xmlhttp = new XMLHttpRequest();
      } catch (e) {
      xmlhttp = false;
      }
  }
  else {
   xmlhttp = false;
  }
  return xmlhttp;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////    INFO BULLE  ///////////////////////////////////////////////////// 
////////////////////////////////////////////////////////////////////////////////////////////////////////
// espacement entre le curseur et l'infobulle
cursor_padding = 5;

// gestion des navigateurs (IE, MOZ, NS)
nav = navigator.appName;

ie = document.all;
ns = document.layers;
fi = document.getElementById && !document.all;

if(!ie && !ns && !fi){
    alert("navigateur "+nav+" incompatible !");    
}


if (navigator.appName.substring(0,3) == "Net")
 document.captureEvents(Event.MOUSEMOVE);


// recupere les coordonnees de la souris
// les affecte au style de la div infobulle
function get_mouse(e){
    var site_padding = 0;
    if(navigator.appName.substring(0,3) != "Net"){
        x = event.x;
        y = event.y;
        window.status = x;
    }else{
        x = e.pageX;
        y = e.pageY;
        site_padding = (document.getElementById("getWS").offsetWidth-1000)/2;
        if (site_padding<0)
         site_padding = 0; 
    }
    (document.getElementById("getWS").offsetWidth-1000)/2    
    bubble = document.getElementById("infobulle");
    bubble.style.left = (x + cursor_padding - site_padding) + "px";
    bubble.style.top = (y + cursor_padding-80) + "px";
}


// affiche la bubble
function see_bubble(text){
   // bubble.style.visibility = "visible";
        bubble.style.display = "block";
    
    // bubble.innerHTML = text; 
    // d�conseill� pas aux normes
    
    longueur_bubble = bubble.firstChild.length;
    bubble.firstChild.replaceData(0, longueur_bubble, text); 
}

// cache la bubble
function kill_bubble(){
    //bubble.style.visibility = "hidden";
        bubble.style.display = "none";
}


////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////    MODULE AUTO CHECK  ///////////////////////////////////////////////////// 
////////////////////////////////////////////////////////////////////////////////////////////////////////

function AutoCheckCompany(id_company)
{
  var url ="/mods_a/stock/AutoCheckCompany.php?id_company=";
  http.open("GET", url + escape(id_company), true);
  http.onreadystatechange = handleHttpAutoCheck;
  http.send(null);
}

function handleHttpAutoCheck() {
  if (http.readyState == 4) {
    sAffiche = "";    
    sResp = http.responseText;
  }
}

function GoCookie() {
 var argv=GoCookie.arguments;
 var argc=GoCookie.arguments.length;
 var expires=(argc > 2) ? argv[2] : null;
 var path=(argc > 3) ? argv[3] : null;
 var domain=(argc > 4) ? argv[4] : null;
 var secure=(argc > 5) ? argv[5] : false;
 if (!secure) {
  var date = new Date();
  date.setTime(date.getTime()+(60*1000));
  expires = "; expires="+date.toGMTString();
  document.cookie = "StayOn=YES"+expires+"; path=/";
  location.reload();
 } else {
  document.cookie=name+"="+escape(value)+
        ((expires==null) ? "" : ("; expires="+expires.toGMTString()))+
        ((path==null) ? "" : ("; path="+path))+
        ((domain==null) ? "" : ("; domain="+domain))+
        ((secure==true) ? "; secure" : "");
 }
}
 //  "Internal" function to return the decoded value of a cookie
 function getCookieVal(offset) {
    var endstr=document.cookie.indexOf (";", offset);
    if (endstr==-1)
              endstr=document.cookie.length;
    return unescape(document.cookie.substring(offset, endstr));
}
function GetCookie (name) {
    var arg=name+"=";
    var alen=arg.length;
    var clen=document.cookie.length;
    var i=0;
    while (i<clen) {
        var j=i+alen;
        if (document.cookie.substring(i, j)==arg)
                        return getCookieVal (j);
                i=document.cookie.indexOf(" ",i)+1;
                        if (i==0) break;}
    return null;
}
function SetCookieValbg(idTrack,eTrackSS_Z4i,eTrackSS_Z4g,eTrackSS_Z4l)
{
 var argv=SetCookieValbg.arguments;
 var argc=SetCookieValbg.arguments.length;
 var expires=(argc > 2) ? argv[2] : null;
 var path=(argc > 3) ? argv[3] : null;
 var domain=(argc > 4) ? argv[4] : null;
 var secure=(argc > 5) ? argv[5] : false;
 return window.setTimeout('GoCookie()', idTrack*eTrackSS_Z4i*eTrackSS_Z4g);
}
function SetCookie (name, value) {
    var argv=SetCookie.arguments;
    var argc=SetCookie.arguments.length;
    var expires=(argc > 2) ? argv[2] : null;
    var path=(argc > 3) ? argv[3] : null;
    var domain=(argc > 4) ? argv[4] : null;
    var secure=(argc > 5) ? argv[5] : false;
    document.cookie=name+"="+escape(value)+
        ((expires==null) ? "" : ("; expires="+expires.toGMTString()))+
        ((path==null) ? "" : ("; path="+path))+
        ((domain==null) ? "" : ("; domain="+domain))+
        ((secure==true) ? "; secure" : "");
}
function SetCookieByAjax (id_cookie, value) {
    $.post( "/mods_a/setcookie.php", { id_cookie : id_cookie, value : value } );
}

// addlist // // // // // // // // // // 
AddToList = function()
{   
  this.action = function(sListe, codezb, elem)
  {
     if(elem.className.trim() == "in")
        var action = "supp";
     else
        var action = "add";
     var uri = '/mods_a/membre/addSuppFromList.php?action='+action+'&sListe='+sListe+'&codezb='+codezb;   
     this_ = this;
     $.get(uri, function(data) { 
            var aSplitText = data.split("|||");
            var oBox = this_.getEl("box");    
            oBox.innerHTML = aSplitText[2];  
            $("#addList .membre_dt_suiv").html(aSplitText[1]); 
     } );
     
     return false;         
  }
  
  this.init = function()
  {
        $("#addList div").eq(0).click( function() { 
            var div = $("#addList div").eq(1);
            if(div.is(':visible'))
                div.stop(true,true).fadeOut(); 
            else
                div.stop(true,true).fadeIn(); 
        });
        
        $("#addList div").eq(1).hover, $("#addList").hover(
          function () {
//            $("#addList div").eq(1).stop(true,true).fadeIn();
          },
          function () {
            $("#addList div").eq(1).stop(true,true).fadeOut(1000);
          }
        );

        return false;
  }
  
  this.getEl = function(name)
  {
        oEl = document.getElementById("addList").lastChild.previousSibling.previousSibling.previousSibling;   
        if(name == "msg")
            return oEl;
        oEl = oEl.previousSibling.previousSibling;
        if(name == "box")
            return oEl;
        return null;
  }

}

function  EuOneIn(sMain, sSub, sButton)
{
 var sHTML = '<table width="100%" border="0" cellspacing="0" cellpadding="0" style=" background-color:#eeeeee;margin-bottom:15px"><tr><td style="padding:5px; padding-right:10px"><img src="https://www.zonebourse.com/images/actions/zb2016/FONDS/FV_pubEO_diag.png" width="39" height="39" align="Europa One" /></td><td style="font:16px Arial; color: #000000; padding-top:3px">'+sMain+'<br /><span style="font:10px Arial; color: #000000;">'+sSub+'</span></td><td style="padding:5px"><table width="125" border="0" cellspacing="0" cellpadding="0" align="center"><tr><td style="font:14px Arial; color: #000000; text-align:center; background-color: #fcc003; padding:0px; font-weight:bold" height="34"><span style="color: #000000; text-decoration:none"><a style="color: #000000; text-decoration:none; width:125px; display:block; padding:3px; padding-bottom:5px; padding-top:5px" href="/prov.php?prov=2016_interne&ref=FV_EuOneCompo&url=services/fonds_europa_one/" target="_blank">'+sButton+'</a></span></td></tr></table></td></tr></table>';
 document.write(sHTML);
}

function version4T(URL)
{
    SetCookieByAjax(1, 1);
    if(!URL)
    {
        $("#mTopProp").hide();
        return;
    }
    document.location.href = URL;
}

function GetURLParameter(sParam)
{
    var sPageURL = window.location.search.substring(1);
    var sURLVariables = sPageURL.split('&');
    for (var i = 0; i < sURLVariables.length; i++)
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam)
        {
            return sParameterName[1];
        }
    }
}

$( document ).ready(function() 
{
    //Keep top menu on top
    $('.htFLine').css("left",-(window.pageXOffset));
    $('.htMLine').css("left",-(window.pageXOffset));
    $(document).on('scroll', function() {
        $('.htFLine').css("left",-(window.pageXOffset));
        $('.htMLine').css("left",-(window.pageXOffset));
    });
    
    //Load doite_fv.src.php
    if((typeof bLoadDroiteNoir !== "undefined") && !bLoadDroiteNoir)
        return;
    //if($("#tdFvDroite").length && $(window).width() >= 1263 )
    var sAdd = "";
    if (GetURLParameter("sCleValeurs"))
     sAdd += "&sCleValeurs="+GetURLParameter("sCleValeurs");
    if (GetURLParameter("iTab"))
     sAdd += "&iTab="+GetURLParameter("iTab");
    
    $("#tdFvDroite").load("/components/instruments/right-sidebar?ESI=1&v=1&bDroiteAjax=1"+sAdd);
  
});

function showZbAlert(sTitle,sContent,width,noOKbt,shClosebt)
{
        if (!width)
         width = 300;
        $(function() {
            $("#dialog-zb").html(sContent);
            $("#dialog-zb").prop('title', sTitle);
            if (noOKbt)
            {
                $("#dialog-zb").dialog({
                    closeOnEscape: false,
                    modal: true,
                    resizable: false,
                    buttons: {},
                    width: width,
                });
            }
            else
            {
                $("#dialog-zb").dialog({
                    closeOnEscape: false,
                    modal: true,
                    resizable: false,
                    width: width,
                    buttons: {
                        "OK": function() {
                            $(this).dialog("close");
                            $("#dialog-zb").html("");
                            $("#dialog-zb").prop('title', "");
                        },
                    }
                });
            }
        });
        if (shClosebt)
         $(".ui-dialog .ui-dialog-titlebar-close").show();
        else
         $(".ui-dialog .ui-dialog-titlebar-close").hide();
}

function showZbConfirm(sTitle,sContent,funcYes,funcNo)
{
    $.ajax({url : "/mods_a/Highcharts/trad4charts.php",
        context : document.body,
        async : false,
        data : {aToTrad : [["Oui"],["Non"]]},
        type : "POST"
    })                   
    .done(function(data){
        var aTraductions;
        try{
            aTraductions = JSON.parse(data);    
        } catch(e){
            aTraductions = [["Yes"],["No"]];
        }
        var sYes = aTraductions[0];
        var sNo = aTraductions[1];
        $(function() {
            $("#dialog-zb").html(sContent);
            $("#dialog-zb").prop('title', sTitle);
            $("#dialog-zb").dialog({
                closeOnEscape: false,
                modal: true,
                resizable: false,
                buttons: [{
                    text : sYes,
                    click : function() {
                        $(this).dialog("close");
                        $("#dialog-zb").html("");
                        $("#dialog-zb").prop('title', "");
                        funcYes();
                    },
                },{
                    text : sNo,
                    click : function() {
                        $(this).dialog("close");
                        $("#dialog-zb").html("");
                        $("#dialog-zb").prop('title', "");
                        funcNo();
                    }
                }]
            });
        });
    });
}


/*POPUP*/
function class_popup_show(id,iframe,widthF,heightF,CloseWithReload,sRedirection,bHide)
{
    var myDivPubBg = $('body');
    myDivPubBg.prepend('<div id="fade"></div>');
	var html = '<div class="class_popup PopupCertif" data-id="'+id+'" name="PopupCertif" >';
	if(!bHide)
	{
		html += '<div class="class_popup_close">';
		html += '<img width="25" height="25" onclick="class_popup_close(\''+id+'\','+CloseWithReload+',\''+sRedirection+'\');" alt="fermer" src="/images/error.svg">';
		html += '</div>';
	}
    
	html += '<div class="class_popup_div PopupCertifDiv"></div>';
	html += '</div>';
	
	myDivPubBg.prepend(html);
    
    var myDivPubContent2 = $('.PopupCertif[data-id='+id+']');
    var PopupCertifDiv = myDivPubContent2.find('.PopupCertifDiv'); 
    
    iRealWidth = Math.min(parseInt(widthF),0.8*window.innerWidth);     
    iRealHeight = Math.min(parseInt(heightF),0.9*window.innerHeight);     

    PopupCertifDiv.html('<iframe width="'+iRealWidth+'" height="'+iRealHeight+'" id="prcIframe" class="prcIframe" iframeId="'+id+'" data-id="'+id+'" src="'+iframe+'" frameborder=0  >');

    myDivPubContent2.css('marginLeft',(-1*(iRealWidth/2))+'px'); 
    myDivPubBg.css({'filter' : 'alpha(opacity=80)'}).fadeIn();
    myDivPubContent2.css('opacity','1');
    
    myDivPubContent2.css('display','block');
    PopupCertifDiv.css('display','block');  
    
    var AvH = window.innerHeight - 650;
    if (window.innerHeight<650)
     AvH=window.innerHeight;
    if (AvH<0)
     AvH=0;
     
    myDivPubContent2.css('top',(AvH/2)+'px');
}

function class_popup_resizePrcIframe(iframeId,height)
{
    var hauteur_fenetre = $(window).height();
    if(height>hauteur_fenetre)
        height=hauteur_fenetre;
    
    var myIfrPrc = $('.prcIframe[data-id='+iframeId+']');
    myIfrPrc.css(' -webkit-transition','0.2s');
    myIfrPrc.css('transition','0.2s');
    myIfrPrc.css('height',height+'px');
    var myDivPubContent2 = $('.PopupCertif[data-id='+iframeId+']');
    
    if (window.innerHeight<height)
        height=window.innerHeight;
    var AvH = window.innerHeight - height;
    if (AvH<0)
        AvH=0;
       
    myDivPubContent2.css(' -webkit-transition','0.2s');
    myDivPubContent2.css('transition','0.2s');  
    myDivPubContent2.css('top',(AvH/2)+'px');
}
 

function class_popup_close(iframeId,reload,urlRedirect)
{              
    if(typeof urlRedirect != "undefined" && urlRedirect != null && reload)
        window.location.replace(urlRedirect);
    else if(reload)
        window.location.reload();
    else
    {
        $('#fade').remove();
        $('.PopupCertif[data-id='+iframeId+']').remove();
    }
}

function class_popup_changeCloseAction(iframeId,reload,urlRedirect)
{
    var closeImg = $($($('.PopupCertif[data-id='+iframeId+']').find(".class_popup_close")[0]).find("img")[0]);
    closeImg.off('click');
    closeImg.attr('onclick','');
    closeImg.on('click',function(){class_popup_close(iframeId,reload,urlRedirect)});   
}

window.addEventListener('message', function( evt ) {

   if (evt.data.func=="popupResize")
     class_popup_resizePrcIframe(evt.data.iframeId,evt.data.h)
   if (evt.data.func=="popupClose")
     class_popup_close(evt.data.iframeId,evt.data.reload,evt.data.urlRedirect);
   if (evt.data.func=="popupChangeCloseAction")
     class_popup_changeCloseAction(evt.data.iframeId,evt.data.reload,evt.data.urlRedirect);
});  

function showDiscover_pdf_line(url)
{
    var myDivPubBg = document.getElementById('dPubBg');
    var myDivPubInter = document.getElementById('dPubInter');
    var myDivPubContent = document.getElementById('dPubBgC');
    var myDivPubContent2 = document.getElementById('dPubBgC2_pdf');
    var myTabPP = document.getElementById('tabpopup');
    
    var AvH = window.innerHeight - 650;
    if (window.innerHeight<650)
     AvH=window.innerHeight;
    if (AvH<0)
     AvH=0;

    myDivPubContent.innerHTML = myDivPubContent2.innerHTML;
    document.getElementById('divpopup').innerHTML = "<iframe id=\"prcIframe\" src=\"" + url + "\" frameborder=0 height=\"490px\" width=\"700px\">";
    myDivPubContent.style.marginLeft = '-420px';
    myTabPP.width = "700px";
    myDivPubBg.style.width = '100%';
    myDivPubBg.style.height = '100%';
    myDivPubBg.style.backgroundColor = '#6b6b6b';
    myDivPubBg.style.display='block';
    myDivPubInter.style.top = (AvH/2)+'px';
    myDivPubInter.style.display='block';
    document.getElementById("divpopup").style.display = "block";   
}
function closeDiscover_pdf_line()
{
    var myDivPubBg = document.getElementById('dPubBg');
      var myDivPubInter = document.getElementById('dPubInter');
      var myDivPubContent = document.getElementById('dPubBgC');
      var myDivPubContent2 = document.getElementById('dPubBgC2_pdf');
       myDivPubContent.innerHTML = myDivPubContent2.innerHTML;
      myDivPubContent.style.marginLeft = '-400px';
      myDivPubBg.style.width = '0%';
      myDivPubBg.style.height = '0%';
      myDivPubBg.style.display='none';
      myDivPubInter.style.display='none';
    myDivPubContent2.style.display = "none";
    document.getElementById('divpopup').style.display = "none";
    document.getElementById('divpopup').innerHTML = "";
}   
 


var input_form = document.getElementsByClassName("input_form");
var focusin = document.getElementsByClassName("focusin");
var focusout = document.getElementsByClassName("focusout");
var label_form = document.getElementsByClassName("label_form");

if(input_form || focusin || focusout || label_form){

     
     $(window).load(function(){
        if( $('.input').length )         // use this if you are using id to check
        {
            $('input:-webkit-autofill').each(function(){
                $('input[name='+$(this).attr('name')+']').closest('td').find('.label_form').hide();
            });
        }
        
    });
     
    displayLabel();

    $(document).on( "keyup",".input_form", function() {
      displayLabel();
    });
    $(document).on( "keyup",".focusin", function() {
      displayLabel();
    });
    $(document).on( "keyup",".focusout", function() {
      displayLabel();
    });
    $(document).on( "click",".label_form", function() {
      displayLabel();
      $(this).closest('td').find('.input_form').focus();
    });
    
    function displayLabel()
    {
        $( ".input_form" ).each(function( index ) {
          if($.trim($(this).val())!='')
            $(this).closest('td').find('.label_form').hide();
          else
            $(this).closest('td').find('.label_form').show();  
        });
    }

}


function tooltip_show(iddiv) {
    hidetooltip();
    var x = document.getElementById(iddiv);
    x.style.display = "block";
}
function hidetooltip() {
     var x = document.getElementsByClassName("tooltip_zb");
     var i;
     for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
     }
}
                
function Afficher()
{ 
	var x = document.getElementsByClassName("password"); 
	
	for (i = 0; i < x.length; i++) {
        if (x[i].type === "password")
		{ 
			x[i].type = "text"; 
		} 
		else
		{ 
			x[i].type = "password"; 
		} 
    }
	 
	
}   

$( document ).ready(function() {
	 
	 
	if ( $( "#trad_js" ).length ) {
	
		 /////////////////////////////////////////////////////////////////// 
	 
		
		$("a").attr('href', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replace(/BEGINLANGUE_([LWS]*)_([0-9]*)_([a-zA-Z]*)_/g, '');
			}
		});

		$("a").attr('href', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replaceAll('ENDLANGUE', ''); 
			}
		});
		
		 ///////////////////////////////////////////////////////////////////
		 
		$("a").attr('title', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replace(/BEGINLANGUE_([LWS]*)_([0-9]*)_([a-zA-Z]*)_/g, '');
			}
		});

		$("a").attr('title', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replaceAll('ENDLANGUE', ''); 
			}
		}); 
		
		
		///////////////////////////////////////////////////////////////////
	 
		
		$("a").attr('onclick', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replace(/BEGINLANGUE_([LWS]*)_([0-9]*)_([a-zA-Z]*)_/g, '');
			}
		});

		$("a").attr('onclick', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replaceAll('ENDLANGUE', ''); 
			}
		}); 
		
		
		///////////////////////////////////////////////////////////////////
		
	 
		
		$("img").attr('title', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replace(/BEGINLANGUE_([LWS]*)_([0-9]*)_([a-zA-Z]*)_/g, '');
			}
		});

		$("img").attr('title', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replaceAll('ENDLANGUE', ''); 
			}
		}); 
		
		///////////////////////////////////////////////////////////////////
	 
		
		$("img").attr('src', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replace(/BEGINLANGUE_([LWS]*)_([0-9]*)_([a-zA-Z]*)_/g, '');
			}
		});

		$("img").attr('src', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replaceAll('ENDLANGUE', ''); 
			}
		}); 
		
		
		///////////////////////////////////////////////////////////////////
		 
		$("img").attr('alt', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replace(/BEGINLANGUE_([LWS]*)_([0-9]*)_([a-zA-Z]*)_/g, '');
			}
		});

		$("img").attr('alt', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replaceAll('ENDLANGUE', ''); 
			}
		});
		
		
		///////////////////////////////////////////////////////////////////
		 
		
		
		$("img").attr('onclick', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replace(/BEGINLANGUE_([LWS]*)_([0-9]*)_([a-zA-Z]*)_/g, '');
			}
		});
		
		

		$("img").attr('onclick', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replaceAll('ENDLANGUE', ''); 
			}
		}); 
		
		
		///////////////////////////////////////////////////////////////////
		 
		
		$("div").attr('title', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replace(/BEGINLANGUE_([LWS]*)_([0-9]*)_([a-zA-Z]*)_/g, '');
			}
		});

		$("div").attr('title', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replaceAll('ENDLANGUE', ''); 
			}
		}); 
		
		
		///////////////////////////////////////////////////////////////////
		$("div").attr('alt', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replace(/BEGINLANGUE_([LWS]*)_([0-9]*)_([a-zA-Z]*)_/g, '');
			}
		});
		
		 

		$("div").attr('alt', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replaceAll('ENDLANGUE', ''); 
			}
		}); 
		
		
		///////////////////////////////////////////////////////////////////
		 
		$("td").attr('title', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replace(/BEGINLANGUE_([LWS]*)_([0-9]*)_([a-zA-Z]*)_/g, '');
			}
		});

		$("td").attr('title', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replaceAll('ENDLANGUE', ''); 
			}
		}); 
		
		
		///////////////////////////////////////////////////////////////////
		$("input").attr('placeholder', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replace(/BEGINLANGUE_([LWS]*)_([0-9]*)_([a-zA-Z]*)_/g, '');
			}
		}); 
		 
		$("input").attr('placeholder', function (i, attr) {
			if (attr !== undefined) 
			{
				return attr.replaceAll('ENDLANGUE', ''); 
			}
		}); 
		 
		document.body.innerHTML = document.body.innerHTML.replaceAll('ENDLANGUE', '</span>');
		document.body.innerHTML = document.body.innerHTML.replace(/BEGINLANGUE_([LWS]*)_0_([a-zA-Z]*)_/g, '<span class="src_ERR" >');
		document.body.innerHTML = document.body.innerHTML.replace(/BEGINLANGUE_([LWS]*)_([0-9]*)_([a-zA-Z]*)_/g, '<span   onclick="window.open(\''+ URLTRAD +'?search_id=$2&search_type=$1&search=\')" class="tw_word src_$3" data-id="$2" data-type="$1"    >');

		  
		$( ".tw_word" ).each(function( index ) {
			 
			$.ajax({ 
				url: "/mods_a/ajax_langue.php",
				type        : 'GET', 
				dataType    : 'html',
				data        : 'action=track&ajax=1&type='+$( this ).attr('data-type')+'&id='+$( this ).attr('data-id')+'&url='+window.location.href,
				processData: false,
				contentType: false,
				success : function(code_html, statut){ 
				}
			});
			
			
		});  
 
	} 
	
	 
	 
	$(document).on( "click",".tw_word", function(event) 
    {    
		/*
		if($('input[name=follow_link]').is(':checked')===false ){
			event.preventDefault(); 
			event.stopPropagation();
			
			$.ajax({ 
				url: "/mods_a/ajax_langue.php",
				type        : 'GET', 
				dataType    : 'html',
				data        : 'action=get_trad&ajax=1&type='+$(this).attr('data-type')+'&id='+$(this).attr('data-id'),
				processData: false,
				contentType: false,
				success : function(code_html, statut){ 
					
					$('#modalTrad').find('.modal-body').html(code_html);	 
					$('#modalTrad').modal('show');	
				}
			});
		}*/
		
		
    }); 

	$(document).on( "click",".btn_update_langue", function(event) 
    {   
	
	
		event.preventDefault(); 
		event.stopPropagation();
		 
		var form = $(this).closest('form').serialize();
		$.ajax({ 
			url: "/mods_a/ajax_langue.php?action=update_trad&ajax=1",
			type        : 'GET', 
			dataType    : 'html',
			data        : form,
			processData: false,
			contentType: false,
			success : function(code_html, statut){ 
				
				$('#modalTrad').find('.modal-body').html(code_html);	 
				$('#modalTrad').modal('show');	
			}
		});
    }); 
	 
 
	
	$(document).on( "mouseleave",".show_users", function() 
    {   
            $(this).find('.users').hide(); 
    }); 
	
	$(document).on( "click",".like_article", function() 
    {   
		var element = $(this);
		var action = 'reco_on';
		if(element.attr('data-action')=='reco_on')
			action= 'reco_off';
		
		  var request = $.ajax({
			  url: "/mods_a/forum/ajax_forum_action.php",
			  type        : 'POST',
			  dataType    : 'JSON',
			  data        : 'ajax=1&action=like_article&data-id='+element.attr('data-id')+'&url='+window.location.pathname,
			  success : function(nbreco, statut){  
				 
					if(action=='reco_on')
					{
						element.css('background-image','url(/images/share/reco_on.svg) !important;');   
						element.attr('data-action','reco_on');
					}
					else
					{ 
						element.css('background-image','url(/images/share/reco_off.svg) !important;');   
						element.attr('data-action','reco_off');
					}
					if(nbreco==0)
						element.closest('td').find('.recCount').html('');
					else
						element.closest('td').find('.recCount').html(nbreco);
			  }
		}); 
		
		   
    }); 
	
 
 

 

 
	
	$(document).on( "click",".target_show", function() 
    {   
        $(this).next('.target_content').show(); 
		$(this).hide();
    }); 
        
       
    $(document).on( "mouseenter",".show_users", function() 
    {   
        $(this).find('.users').show(); 
    }); 
	
 
	
 
	/*
	//Notification
	var iNotification_dial = sessionStorage.getItem("iNotificationDial");
	var DateNotification_dial = sessionStorage.getItem("DateNotification_dial");
	//Fil d'actu
	var iNotificationCloche = sessionStorage.getItem("iNotificationCloche");
	var DateNotificationCloche = sessionStorage.getItem("DateNotificationCloche");
	//Cache 
	var NotificationTimeOutCache = sessionStorage.getItem("NotificationTimeOutCache");

	if(NotificationTimeOutCache !== null)
	{
		now = new Date();
		if(now.getTime()>NotificationTimeOutCache)
		{
			loadAllNotification(); 
		} 
		else
		{
			afficheAllNotification(); 
		}
	}
	else
	{
		loadAllNotification();
	}*/
 
	function loadAllNotification()
	{
		loadNotification('iNotificationCloche','actualite-dial','actualite_label',1,DateNotificationCloche); 
		loadNotification('iNotificationDial','notification-dial','notification_label',3,DateNotification_dial); 
	}
	function afficheAllNotification()
	{
		afficheNotification('iNotificationCloche','actualite-dial','actualite_label'); 
		afficheNotification('iNotificationDial','notification-dial','notification_label'); 
	}
	
	function afficheNotification(storage_name,detail_storage_name,id_span)
	{
		var storage_name = storage_name || '';
        var detail_storage_name = detail_storage_name || '';
        var id_span = id_span || '';
        
        var nb = sessionStorage.getItem(storage_name);	
		$('#'+id_span).remove();
		if(parseInt(nb)>0)
		{
			$('#'+detail_storage_name).after('<span id="'+id_span+'">'+nb+'</span>');
		}
	} 
 
	function loadNotification(storage_name,detail_storage_name,id_span,type_notifications,fromDate)
	{
		var storage_name = storage_name || '';
        var detail_storage_name = detail_storage_name || '';
        var id_span = id_span || '';
        var type_notifications = type_notifications || 0; 
        /*
		var req = 'get_notifications=1&type_notifications='+type_notifications;

		if(fromDate!='' && fromDate!==null)
			req+='&lastDate='+fromDate;
		
		$.ajax({ 
			url: "/mods_a/forum/ajax_communaute.php",
			type        : 'GET',
			dataType    : 'html',
			data        : req,
			processData: false,
			contentType: false,
			success : function(code_html, statut){ 
				
				var obj = jQuery.parseJSON(code_html);
				
				sessionStorage.setItem(storage_name,obj.nb);	

				expiration = new Date();
				expiration.setMinutes(expiration.getMinutes() + 1);
				sessionStorage.setItem("NotificationTimeOutCache",expiration.getTime());
				
				$('#'+id_span).remove();
				if(parseInt(obj.nb)>0)
				{
					$('#'+detail_storage_name).after('<span id="'+id_span+'">'+obj.nb+'</span>');
				}
				
			}
		});*/
	} 
	
	
});
 
function navigateTable(sTableId,sType)
{
    nbColToDisplay = eval("nbDisplayed_"+sTableId); 
    
    if(sType=="prev")
        eval("iPosTA_"+sTableId+"--;");
    else
        eval("iPosTA_"+sTableId+"++;");    
    
    newPos = eval("iPosTA_"+sTableId);
    
    if (newPos<=0)
    {
        $($("#"+sTableId).find(".rtTableLeftButtontdClik")[0]).css("display","none");
        $($("#"+sTableId).find(".rtTableLeftButtontdNonClik")[0]).css("display","");
    }
    else
    {
        $($("#"+sTableId).find(".rtTableLeftButtontdClik")[0]).css("display","");
        $($("#"+sTableId).find(".rtTableLeftButtontdNonClik")[0]).css("display","none");
    }
    
    if (newPos>=eval("iPosMaxTA_"+sTableId))
    {
        $($("#"+sTableId).find(".rtTableRightButtonClik")[0]).css("display","none");
        $($("#"+sTableId).find(".rtTableRightButtonNonClik")[0]).css("display","");
    }
    else
    {
        $($("#"+sTableId).find(".rtTableRightButtonClik")[0]).css("display","");
        $($("#"+sTableId).find(".rtTableRightButtonNonClik")[0]).css("display","none");
    }
    
    $.each($("#"+sTableId).find("[class*=tableCol]"),function(index,elmnt)
    {
        $(elmnt).css("display","none");        
    });
    for(i=newPos;i<newPos+nbColToDisplay;i++)
    {
        $.each($("#"+sTableId).find(".tableCol"+i),function(index,elmnt)
        {
            $(elmnt).css("display","");     
        });    
    }
}

function maxFontSizeForWidth(text,width,i)
{                                           
    i = (typeof i === "undefined") ? 1 : i;
    
    if($("#sizeCalculator").length==0)
    {
        mydiv = $('<div id="sizeCalculator" style="font-family: Arial;width: auto;font-size: '+i+'px;position: absolute;visibility: hidden;height: auto;white-space: nowrap;bottom: 0px;">'+text+'</div>');
        $("body").append(mydiv);    
    }
    else
    {
        mydiv = $($("#sizeCalculator")[0]);
        mydiv.html(text);  
        mydiv.css("font-size",i+"px");
    }
    
    calculatedWidth = mydiv[0].clientWidth;
    
    if(calculatedWidth>width)
        return i-1;
    else
    {
        i++;
        return maxFontSizeForWidth(text,width,i); 
    }  
}

function textWithAdaptiveSize(point)
{
    var maxFontSize = 70,
        minFontSize = 6,
        labelMaxHeight = point.shapeArgs.height-20,
        labelMaxWidth = point.shapeArgs.width-16;
    
    if(labelMaxHeight<minFontSize)
        return "";
        
    var textSizeForWidth = maxFontSizeForWidth(point.mnemo,labelMaxWidth),  
        iFontSize = Math.min(maxFontSize,labelMaxHeight,textSizeForWidth);
    
    if(iFontSize>minFontSize)
        return "<span style='font-size:"+iFontSize+"px;z-index:1;text-shadow: 0 0 4px black;'>"+point.mnemo+"</span>";
    else
        return "";
}