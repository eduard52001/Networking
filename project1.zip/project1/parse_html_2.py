from bs4 import BeautifulSoup


with open('search_res.html', 'r') as f:
    soup = BeautifulSoup(f, 'html.parser')
    search_results = soup.find('table', {'class': 'table--medium'})

    res_file = open('search_table.html', 'w')
    res_file.write(search_results.__str__())
    res_file.close()
