from bs4 import BeautifulSoup


with open('tie.html', 'r') as f:
    soup = BeautifulSoup(f, 'html.parser')
    # scripts = soup.find_all('script')
    body = soup.find('body')
    # for par in body.parents:
    #     print(par)
    # for p in body.parents:
    #     print(type(p.name))


    tables = body.findChildren('table')
    tables_file = open('tables2.html', 'w')
    for table in tables:
        table_parents = table.parents
        for parent in table.parents:
            if parent.name == 'table':
                break
        else:
            tables_file.write(table.__str__())
    # tables_file.close()



    # table_file = open('table1.html', 'a')
    # for script in scripts:
    #     table_file.write(script.__str__())
    # table_file.close()

